import { DieConfig, NotchOrientation, WaferConfig } from '../types';

export interface IngestionProductPreset {
  id: string;
  technology: string;
  dieWidthMm: number;
  dieHeightMm: number;
  scribeMm: number;
  reticleCols: number;
  reticleRows: number;
}

export const INGESTION_PRODUCT_PRESETS: IngestionProductPreset[] = [
  { id: 'AP-ULTRA-X9', technology: 'N7 FinFET', dieWidthMm: 8.5, dieHeightMm: 10.2, scribeMm: 0.08, reticleCols: 3, reticleRows: 2 },
  { id: 'AI-ACCEL-T5', technology: 'N5 EUV', dieWidthMm: 12, dieHeightMm: 14.5, scribeMm: 0.1, reticleCols: 2, reticleRows: 2 },
  { id: 'GPU-TENSOR-G3', technology: 'N3 GAA', dieWidthMm: 24, dieHeightMm: 20, scribeMm: 0.12, reticleCols: 1, reticleRows: 1 },
  { id: 'MEM-HBM3E-V2', technology: '1-beta DRAM', dieWidthMm: 2.6, dieHeightMm: 7.8, scribeMm: 0.04, reticleCols: 4, reticleRows: 3 },
  { id: 'AUTO-MCU-N16', technology: '16nm FinFET', dieWidthMm: 5.8, dieHeightMm: 5.2, scribeMm: 0.08, reticleCols: 4, reticleRows: 4 },
  { id: 'HD-MICRO-100K', technology: 'High-density micro-array', dieWidthMm: 0.8, dieHeightMm: 0.8, scribeMm: 0.01, reticleCols: 10, reticleRows: 10 },
];

export function getIngestionPreset(id: string): IngestionProductPreset {
  return INGESTION_PRODUCT_PRESETS.find(preset => preset.id === id) ?? INGESTION_PRODUCT_PRESETS[0];
}

export function configurationsFromPreset(preset: IngestionProductPreset, lotId: string, waferId: string): { waferConfig: WaferConfig; dieConfig: DieConfig } {
  const matrix = Array.from({ length: preset.reticleRows }, (_, row) => Array.from({ length: preset.reticleCols }, (_, col) => (row + col) % 5 === 2 ? 'SRAM_CACHE' : (row + col) % 5 === 3 ? 'IO_PHY' : 'LOGIC_CORE'));
  return {
    waferConfig: { wafer_id: waferId, lot_id: lotId, product_id: preset.id, diameter_mm: 300, edge_exclusion_mm: 3, notch_angle_deg: 270 as NotchOrientation, center_offset_x_mm: 0, center_offset_y_mm: 0 },
    dieConfig: { width_mm: preset.dieWidthMm, height_mm: preset.dieHeightMm, scribe_x_mm: preset.scribeMm, scribe_y_mm: preset.scribeMm, reticle_cols: preset.reticleCols, reticle_rows: preset.reticleRows, die_type_matrix: matrix },
  };
}
