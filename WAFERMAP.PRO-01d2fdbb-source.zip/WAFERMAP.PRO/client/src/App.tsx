import React, { useState, useEffect } from 'react';
import {
  WaferConfig,
  DieConfig,
  DefectPatternType,
  ViewDisplayMode,
  ColormapMode,
  DieInstance,
  ShotInstance,
  WaferLayoutResponse,
  SpatialAnalytics,
  ShotOptimizationResult,
  NotchOrientation,
  IngestedWaferData,
  IngestedDataType,
} from './types';
import {
  generateClientWaferLayout,
  calculateClientSpatialAnalytics,
} from './utils/waferGeometry';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { WaferCanvas } from './components/WaferCanvas';
import { configurationsFromPreset, getIngestionPreset, IngestionProductPreset } from './data/productPresets';

const ReticleStudio = React.lazy(() => import('./components/ReticleStudio').then(({ ReticleStudio }) => ({ default: ReticleStudio })));
const ShotOptimizerModal = React.lazy(() => import('./components/ShotOptimizerModal').then(({ ShotOptimizerModal }) => ({ default: ShotOptimizerModal })));
const SpatialAnalyticsModal = React.lazy(() => import('./components/SpatialAnalyticsModal').then(({ SpatialAnalyticsModal }) => ({ default: SpatialAnalyticsModal })));
const ExportModal = React.lazy(() => import('./components/ExportModal').then(({ ExportModal }) => ({ default: ExportModal })));
const DieInspectorDrawer = React.lazy(() => import('./components/DieInspectorDrawer').then(({ DieInspectorDrawer }) => ({ default: DieInspectorDrawer })));
const DataIngestionStudio = React.lazy(() => import('./components/DataIngestionStudio').then(({ DataIngestionStudio }) => ({ default: DataIngestionStudio })));
const DatasetLibrary = React.lazy(() => import('./components/DatasetLibrary').then(({ DatasetLibrary }) => ({ default: DatasetLibrary })));
const CPAnalysisStudio = React.lazy(() => import('./components/CPAnalysisStudio').then(({ CPAnalysisStudio }) => ({ default: CPAnalysisStudio })));
const DataCriteriaExplorer = React.lazy(() => import('./components/DataCriteriaExplorer').then(({ DataCriteriaExplorer }) => ({ default: DataCriteriaExplorer })));

export default function App() {
  // 1. Wafer Configuration State (300mm default standard)
  const [waferConfig, setWaferConfig] = useState<WaferConfig>({
    wafer_id: 'W300-PROD-202608-01',
    lot_id: 'LOT-7NM-A88',
    product_id: 'AP-ULTRA-X9',
    diameter_mm: 300,
    edge_exclusion_mm: 3.0,
    notch_angle_deg: 270 as NotchOrientation,
    center_offset_x_mm: 0,
    center_offset_y_mm: 0,
  });

  // 2. Die & Reticle Configuration State
  const [dieConfig, setDieConfig] = useState<DieConfig>({
    width_mm: 8.5,
    height_mm: 10.2,
    scribe_x_mm: 0.08,
    scribe_y_mm: 0.08,
    reticle_cols: 3,
    reticle_rows: 2,
    die_type_matrix: [
      ['LOGIC_CORE', 'LOGIC_CORE', 'SRAM_CACHE'],
      ['LOGIC_CORE', 'IO_PHY', 'ANALOG_PLL'],
    ],
  });

  // 3. Defect & Visualization States
  const [defectPattern, setDefectPattern] = useState<DefectPatternType>('random');
  const [viewMode, setViewMode] = useState<ViewDisplayMode>('bin_category');
  const [colormap, setColormap] = useState<ColormapMode>('turbo');

  // 4. Data Layout & Analytics
  const [layoutData, setLayoutData] = useState<WaferLayoutResponse>(() => {
    return generateClientWaferLayout(waferConfig, dieConfig, defectPattern).layout;
  });
  const [spatialData, setSpatialData] = useState<SpatialAnalytics | null>(() => {
    return generateClientWaferLayout(waferConfig, dieConfig, defectPattern).spatial;
  });

  // 5. Selection & Inspection States
  const [selectedDie, setSelectedDie] = useState<DieInstance | null>(null);
  const [selectedShot, setSelectedShot] = useState<ShotInstance | null>(null);
  const [highlightedReticleCell, setHighlightedReticleCell] = useState<{
    row: number;
    col: number;
  } | null>(null);
  const [resetViewTrigger, setResetViewTrigger] = useState<number>(0);

  // 6. Modals
  const [isReticleStudioOpen, setIsReticleStudioOpen] = useState<boolean>(false);
  const [isOptimizerOpen, setIsOptimizerOpen] = useState<boolean>(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [optimizationResult, setOptimizationResult] = useState<ShotOptimizationResult | null>(null);
  const [isSavingSession, setIsSavingSession] = useState<boolean>(false);
  const [sessionStatus, setSessionStatus] = useState<string | null>(null);
  const [isIngestionOpen, setIsIngestionOpen] = useState(false);
  const [isDatasetLibraryOpen, setIsDatasetLibraryOpen] = useState(false);
  const [isCpAnalysisOpen, setIsCpAnalysisOpen] = useState(false);
  const [isDataCriteriaOpen, setIsDataCriteriaOpen] = useState(false);
  const [selectedCpBin, setSelectedCpBin] = useState<number | null>(null);
  const [ingestedData, setIngestedData] = useState<Partial<Record<IngestedDataType, IngestedWaferData>>>({});

  // Real-time calculation effect (combines instant client calculations with backend Python API)
  useEffect(() => {
    // Instant client calculation for silky-smooth 60fps UI
    const { layout, spatial } = generateClientWaferLayout(
      waferConfig,
      dieConfig,
      defectPattern
    );
    setLayoutData(layout);
    setSpatialData(spatial);

    // Debounced server verification avoids recalculating remotely during rapid slider drags.
    const controller = new AbortController();
    const estimatedDieCount = (waferConfig.diameter_mm / (dieConfig.width_mm + dieConfig.scribe_x_mm)) * (waferConfig.diameter_mm / (dieConfig.height_mm + dieConfig.scribe_y_mm));
    // The local engine already provides an immediate layout. Avoid echoing a 100k-die payload through HTTP.
    if (estimatedDieCount > 25_000) {
      return () => controller.abort();
    }
    const debounceTimer = window.setTimeout(() => {
      fetch('/api/wafer/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...waferConfig,
          die_width_mm: dieConfig.width_mm,
          die_height_mm: dieConfig.height_mm,
          scribe_x_mm: dieConfig.scribe_x_mm,
          scribe_y_mm: dieConfig.scribe_y_mm,
          reticle_cols: dieConfig.reticle_cols,
          reticle_rows: dieConfig.reticle_rows,
          die_type_matrix: dieConfig.die_type_matrix,
          defect_pattern: defectPattern,
        }),
        signal: controller.signal,
      })
        .then((res) => res.ok ? res.json() : Promise.reject(new Error('Calculation service unavailable')))
        .then((data) => {
          if (data.layout && data.spatial) {
            setLayoutData(data.layout);
            setSpatialData(data.spatial);
          }
        })
        .catch(() => {
          // Retain instant client-side calculations if the service is unavailable.
        });
    }, 180);

    return () => {
      window.clearTimeout(debounceTimer);
      controller.abort();
    };
  }, [waferConfig, dieConfig, defectPattern]);

  // Handle Stepping Center-Offset Optimization
  const handleRunOptimizer = async () => {
    setIsOptimizerOpen(true);
    setIsOptimizing(true);

    try {
      const res = await fetch('/api/wafer/optimize-shot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...waferConfig,
          die_width_mm: dieConfig.width_mm,
          die_height_mm: dieConfig.height_mm,
          scribe_x_mm: dieConfig.scribe_x_mm,
          scribe_y_mm: dieConfig.scribe_y_mm,
          reticle_cols: dieConfig.reticle_cols,
          reticle_rows: dieConfig.reticle_rows,
          die_type_matrix: dieConfig.die_type_matrix,
          grid_steps: 20,
        }),
      });
      const data = await res.json();
      setOptimizationResult(data);
    } catch (err) {
      // Fallback Client 2D Grid Search
      const reticleW =
        dieConfig.reticle_cols * dieConfig.width_mm +
        (dieConfig.reticle_cols - 1) * dieConfig.scribe_x_mm;
      const reticleH =
        dieConfig.reticle_rows * dieConfig.height_mm +
        (dieConfig.reticle_rows - 1) * dieConfig.scribe_y_mm;
      const pitchX = reticleW + dieConfig.scribe_x_mm;
      const pitchY = reticleH + dieConfig.scribe_y_mm;

      let bestOffset = [0, 0];
      let bestGdpw = -1;
      const gridSteps = 20;
      const heatmap: { dx: number; dy: number; gdpw: number }[][] = [];

      for (let i = 0; i < gridSteps; i++) {
        const dx = (i - gridSteps / 2) * (pitchX / gridSteps);
        const rowData = [];
        for (let j = 0; j < gridSteps; j++) {
          const dy = (j - gridSteps / 2) * (pitchY / gridSteps);
          const tempLayout = generateClientWaferLayout(
            { ...waferConfig, center_offset_x_mm: dx, center_offset_y_mm: dy },
            dieConfig,
            'random'
          );
          const gdpw = tempLayout.layout.metadata.gross_die_count;
          rowData.push({ dx: +dx.toFixed(3), dy: +dy.toFixed(3), gdpw });
          if (gdpw > bestGdpw) {
            bestGdpw = gdpw;
            bestOffset = [dx, dy];
          }
        }
        heatmap.push(rowData);
      }

      setOptimizationResult({
        best_offset_x_mm: +bestOffset[0].toFixed(4),
        best_offset_y_mm: +bestOffset[1].toFixed(4),
        max_gross_die: bestGdpw,
        baseline_gross_die: layoutData.metadata.gross_die_count,
        gain_dies: bestGdpw - layoutData.metadata.gross_die_count,
        heatmap,
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleApplyOptimalOffset = (offsetX: number, offsetY: number) => {
    setWaferConfig((prev) => ({
      ...prev,
      center_offset_x_mm: offsetX,
      center_offset_y_mm: offsetY,
    }));
  };

  const handleSaveSession = async () => {
    setIsSavingSession(true);
    setSessionStatus(null);
    try {
      const res = await fetch('/api/wafer/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...waferConfig,
          die_width_mm: dieConfig.width_mm,
          die_height_mm: dieConfig.height_mm,
          scribe_x_mm: dieConfig.scribe_x_mm,
          scribe_y_mm: dieConfig.scribe_y_mm,
          reticle_cols: dieConfig.reticle_cols,
          reticle_rows: dieConfig.reticle_rows,
          die_type_matrix: dieConfig.die_type_matrix,
          defect_pattern: defectPattern,
          view_mode: viewMode,
          persist: true,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.persistence?.analysis_session_id) {
        throw new Error(data.message || 'Unable to save this analysis session.');
      }
      setSessionStatus(`Session #${data.persistence.analysis_session_id} saved`);
    } catch (error) {
      setSessionStatus(error instanceof Error ? error.message : 'Session save failed.');
    } finally {
      setIsSavingSession(false);
    }
  };

  const handleApplyIngestion = (data: IngestedWaferData, preset: IngestionProductPreset) => {
    const { waferConfig: nextWaferConfig, dieConfig: nextDieConfig } = configurationsFromPreset(
      preset,
      data.dataset.summary.lot_id,
      data.dataset.summary.wafer_id,
    );
    setIngestedData(current => ({ ...current, [data.dataset.source_type]: data }));
    setWaferConfig(nextWaferConfig);
    setDieConfig(nextDieConfig);
    setSelectedDie(null);
    setSelectedShot(null);
    setSelectedCpBin(null);
    setResetViewTrigger(current => current + 1);
    setViewMode(data.dataset.source_type === 'CP' ? 'bin_category' : data.dataset.source_type === 'WAT' ? 'wat_sites' : 'kla_defects');
    setSessionStatus(`${data.dataset.source_type} dataset #${data.dataset.dataset_id} active`);
  };

  const handleOpenPersistedDataset = (data: IngestedWaferData) => {
    handleApplyIngestion(data, getIngestionPreset(data.dataset.summary.product_name));
  };

  const handleClearActiveData = () => {
    setIngestedData({});
    setSelectedCpBin(null);
    setViewMode('bin_category');
    setSessionStatus('Active data overlays cleared');
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#080808] text-[#E5E5E5] font-sans select-none">
      {/* 1. Industrial Top Navigation & Live KPI Toolbar */}
      <Header
        metadata={layoutData.metadata}
        viewMode={viewMode}
        setViewMode={setViewMode}
        colormap={colormap}
        setColormap={setColormap}
        onOpenOptimizer={handleRunOptimizer}
        onOpenAnalytics={() => setIsAnalyticsOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenReticleStudio={() => setIsReticleStudioOpen(true)}
        onOpenIngestion={() => setIsIngestionOpen(true)}
        onOpenDataLibrary={() => setIsDatasetLibraryOpen(true)}
        onOpenCpAnalysis={() => setIsCpAnalysisOpen(true)}
        onOpenDataCriteria={() => setIsDataCriteriaOpen(true)}
        onResetView={() => setResetViewTrigger((t) => t + 1)}
        isOptimizing={isOptimizing}
        onSaveSession={handleSaveSession}
        isSavingSession={isSavingSession}
        sessionStatus={sessionStatus}
        availableDataTypes={Object.keys(ingestedData) as IngestedDataType[]}
        hasCpData={Boolean(ingestedData.CP)}
      />

      {/* 2. Main Workspace Layout */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Left Side: Wafer & Stepping Parameter Controls */}
        <ControlPanel
          waferConfig={waferConfig}
          setWaferConfig={setWaferConfig}
          dieConfig={dieConfig}
          setDieConfig={setDieConfig}
          defectPattern={defectPattern}
          setDefectPattern={setDefectPattern}
          metadata={layoutData.metadata}
          onOpenOptimizer={handleRunOptimizer}
          onOpenReticleStudio={() => setIsReticleStudioOpen(true)}
          activeDatasets={ingestedData}
          onOpenIngestion={() => setIsIngestionOpen(true)}
          onOpenCpAnalysis={() => setIsCpAnalysisOpen(true)}
          onClearActiveData={handleClearActiveData}
        />

        {/* Center: High Performance 300mm Wafer Canvas */}
        <main className="flex-1 min-h-0 min-w-0 relative overflow-hidden bg-[#080808]">
          <WaferCanvas
            metadata={layoutData.metadata}
            dies={layoutData.dies}
            shots={layoutData.shots}
            viewMode={viewMode}
            colormap={colormap}
            selectedDie={selectedDie}
            onSelectDie={setSelectedDie}
            selectedShot={selectedShot}
            onSelectShot={setSelectedShot}
            highlightedReticleCell={highlightedReticleCell}
            resetViewTrigger={resetViewTrigger}
            cpRecords={ingestedData.CP?.cpRecords ?? []}
            watRecords={ingestedData.WAT?.watRecords ?? []}
            klaRecords={ingestedData.KLA?.klaRecords ?? []}
            selectedCpBin={selectedCpBin}
          />
        </main>
      </div>

      <React.Suspense fallback={null}>
        {/* 3. Reticle & Multi-Die Studio Modal */}
        <ReticleStudio
          isOpen={isReticleStudioOpen}
          onClose={() => {
            setIsReticleStudioOpen(false);
            setHighlightedReticleCell(null);
          }}
          dieConfig={dieConfig}
          setDieConfig={setDieConfig}
          metadata={layoutData.metadata}
          spatial={spatialData}
          highlightedCell={highlightedReticleCell}
          onHoverCell={setHighlightedReticleCell}
        />

        {/* 4. Shot Stepping Optimizer Modal */}
        <ShotOptimizerModal
          isOpen={isOptimizerOpen}
          onClose={() => setIsOptimizerOpen(false)}
          optimizationResult={optimizationResult}
          isLoading={isOptimizing}
          onApplyOptimalOffset={handleApplyOptimalOffset}
        />

        {/* 5. Spatial Analytics & Defect Autocorrelation Modal */}
        <SpatialAnalyticsModal
          isOpen={isAnalyticsOpen}
          onClose={() => setIsAnalyticsOpen(false)}
          spatial={spatialData}
          metadata={layoutData.metadata}
        />

        {/* 6. SEMI Standards & File Exporter Modal */}
        <ExportModal
          isOpen={isExportOpen}
          onClose={() => setIsExportOpen(false)}
          layoutData={layoutData}
        />

        {/* 7. Detailed Single-Die & Shot Passport Drawer */}
        <DieInspectorDrawer
          die={selectedDie}
          shot={selectedShot}
          onClose={() => setSelectedDie(null)}
        />

        <DataIngestionStudio
          isOpen={isIngestionOpen}
          onClose={() => setIsIngestionOpen(false)}
          onApply={handleApplyIngestion}
        />

        <DatasetLibrary
          isOpen={isDatasetLibraryOpen}
          onClose={() => setIsDatasetLibraryOpen(false)}
          onOpenIngestion={() => {
            setIsDatasetLibraryOpen(false);
            setIsIngestionOpen(true);
          }}
          onApply={handleOpenPersistedDataset}
        />

        <CPAnalysisStudio
          isOpen={isCpAnalysisOpen}
          onClose={() => setIsCpAnalysisOpen(false)}
          activeDatasets={ingestedData}
          selectedBin={selectedCpBin}
          onFilterBin={setSelectedCpBin}
          onOpenIngestion={() => setIsIngestionOpen(true)}
          onOpenDatasetLibrary={() => setIsDatasetLibraryOpen(true)}
        />

        <DataCriteriaExplorer
          isOpen={isDataCriteriaOpen}
          onClose={() => setIsDataCriteriaOpen(false)}
          onOpenIngestion={() => {
            setIsDataCriteriaOpen(false);
            setIsIngestionOpen(true);
          }}
          onOpenAnalysis={() => {
            setIsDataCriteriaOpen(false);
            setIsCpAnalysisOpen(true);
          }}
          onApply={handleOpenPersistedDataset}
        />
      </React.Suspense>
    </div>
  );
}
