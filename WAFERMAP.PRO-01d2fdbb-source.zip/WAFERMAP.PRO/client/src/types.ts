/**
 * RetiMap 300 - WaferMap & Reticle System Types
 * Defines data structures for Wafer geometry, Reticle layout, Shot map stepping,
 * Die instances, SEMI E142/G85 standards, and Spatial defect analytics.
 */

export type NotchOrientation = 0 | 90 | 180 | 270;

export type DieStatus = 'FULL' | 'PARTIAL' | 'OUTSIDE' | 'SCRIBE' | 'EXCLUDED';

export type BinQuality = 'PASS' | 'FAIL' | 'NULL';

export type DefectPatternType =
  | 'random'
  | 'edge_ring'
  | 'center_cluster'
  | 'scratch'
  | 'repeater'
  | 'donut';

export interface DieTypeConfig {
  id: string;
  name: string;
  code: string;
  color: string;
  description: string;
}

export interface WaferConfig {
  wafer_id: string;
  lot_id: string;
  product_id: string;
  diameter_mm: number; // 300mm default
  edge_exclusion_mm: number; // typically 2-3mm
  notch_angle_deg: NotchOrientation;
  center_offset_x_mm: number;
  center_offset_y_mm: number;
}

export interface DieConfig {
  width_mm: number;
  height_mm: number;
  scribe_x_mm: number;
  scribe_y_mm: number;
  reticle_cols: number;
  reticle_rows: number;
  die_type_matrix: string[][];
}

export interface DieInstance {
  die_uid: string;
  global_x: number;
  global_y: number;
  center_x_mm: number;
  center_y_mm: number;
  width_mm: number;
  height_mm: number;
  shot_row: number;
  shot_col: number;
  reticle_row: number;
  reticle_col: number;
  die_type: string;
  status: DieStatus;
  is_yieldable: boolean;
  bin_code: number;
  bin_name: string;
  bin_quality: BinQuality;
  parametric_val: number; // e.g. Normalized yield score / Vth (0-100)
  test_freq_ghz: number;
  leakage_ua: number;
  defect_count: number;
  radial_dist_mm: number;
  angle_deg: number;
}

export interface ShotInstance {
  shot_id: string;
  shot_row: number;
  shot_col: number;
  center_x_mm: number;
  center_y_mm: number;
  width_mm: number;
  height_mm: number;
  status: 'FULL' | 'PARTIAL' | 'EXCLUDED';
  total_dies: number;
  pass_dies: number;
  fail_dies: number;
  yield_pct: number;
}

export interface WaferMetadata {
  wafer_id: string;
  lot_id: string;
  product_id: string;
  diameter_mm: number;
  edge_exclusion_mm: number;
  usable_radius_mm: number;
  notch_angle_deg: number;
  center_offset_x_mm: number;
  center_offset_y_mm: number;
  theoretical_gdpw: number;
  gross_die_count: number;
  pass_die_count: number;
  fail_die_count: number;
  partial_die_count: number;
  yield_pct: number;
  reticle_field_w_mm: number;
  reticle_field_h_mm: number;
  reticle_rows: number;
  reticle_cols: number;
  shot_pitch_x_mm: number;
  shot_pitch_y_mm: number;
  total_shots: number;
  defect_pattern: DefectPatternType;
}

export interface RadialZoneData {
  zone: string;
  radius_min: number;
  radius_max: number;
  total: number;
  pass: number;
  fail: number;
  yield_pct: number;
  mean_param: number;
}

export interface AngularSectorData {
  sector: string;
  angle_min: number;
  angle_max: number;
  total: number;
  pass: number;
  fail: number;
  yield_pct: number;
}

export interface ReticleRepeaterCell {
  reticle_row: number;
  reticle_col: number;
  total: number;
  pass: number;
  fail: number;
  fail_rate_pct: number;
}

export interface SpatialAnalytics {
  moran_i: number;
  clustering_level: string;
  radial_zones: RadialZoneData[];
  angular_sectors: AngularSectorData[];
  reticle_repeater_matrix: ReticleRepeaterCell[][];
}

export interface WaferLayoutResponse {
  metadata: WaferMetadata;
  dies: DieInstance[];
  shots: ShotInstance[];
}

export interface ShotOptimizationResult {
  best_offset_x_mm: number;
  best_offset_y_mm: number;
  max_gross_die: number;
  baseline_gross_die: number;
  gain_dies: number;
  heatmap: { dx: number; dy: number; gdpw: number }[][];
}

export type ViewDisplayMode =
  | 'bin_category'
  | 'parametric_heatmap'
  | 'shot_yield'
  | 'reticle_local'
  | 'defect_markers'
  | 'die_types'
  | 'wat_sites'
  | 'kla_defects';

export type ColormapMode = 'turbo' | 'viridis' | 'plasma' | 'inferno' | 'coolwarm';

export type IngestedDataType = 'CP' | 'WAT' | 'KLA';

export interface CpDieRecord {
  die_x: number;
  die_y: number;
  x_mm: number;
  y_mm: number;
  bin_code: number;
  bin_name: string;
  bin_quality: BinQuality;
  param_name?: string | null;
  param_value?: number | null;
  param_unit?: string | null;
  test_freq_ghz?: number | null;
  leakage_ua?: number | null;
}

export interface WatMeasurementItem {
  site_id: string;
  die_x: number;
  die_y: number;
  x_mm: number;
  y_mm: number;
  param_name: string;
  value: number;
  unit: string;
  spec_low?: number | null;
  spec_target?: number | null;
  spec_high?: number | null;
  status: 'PASS' | 'WARN' | 'FAIL';
}

export interface KlaDefectItem {
  defect_id: string;
  die_x: number;
  die_y: number;
  x_mm: number;
  y_mm: number;
  size_um: number;
  defect_class: string;
  layer?: string | null;
  cluster_id: number;
  is_repeater: boolean;
}

export interface IngestionSummary {
  data_type: IngestedDataType;
  lot_id: string;
  wafer_id: string;
  product_name: string;
  source_filename: string;
  file_format: 'CSV' | 'EXCEL';
  total_rows: number;
  valid_rows: number;
  error_rows: number;
  parameter_names: string[];
  selected_parameter: string;
  stats: {
    gross_items: number;
    pass_count: number;
    fail_count: number;
    yield_pct: number;
    mean_val: number;
    min_val: number;
    max_val: number;
    std_dev: number;
    defect_count: number;
    defect_density_per_cm2: number;
    repeater_defect_count: number;
  };
  detected_columns: Record<string, string>;
  sample_rows: Record<string, unknown>[];
}

export interface IngestionDatasetResult {
  dataset_id: number;
  source_type: IngestedDataType;
  storage_url: string;
  summary: IngestionSummary;
}

export type IngestionDatasetSummary = IngestionSummary;

export interface IngestedWaferData {
  dataset: IngestionDatasetResult;
  cpRecords?: CpDieRecord[];
  watRecords?: WatMeasurementItem[];
  klaRecords?: KlaDefectItem[];
}

export interface PersistedIngestionDataset {
  id: number;
  source_type: IngestedDataType;
  wafer_id: string;
  lot_id: string;
  product_id: string;
  original_filename: string;
  valid_rows: number;
  error_rows: number;
  created_at: string | null;
}

export interface PersistedDatasetCriteria {
  source_types: IngestedDataType[];
  lot_ids: string[];
  wafer_ids: string[];
  product_ids: string[];
}

export interface PersistedDatasetCatalog {
  datasets: PersistedIngestionDataset[];
  criteria: PersistedDatasetCriteria;
  persistence_available: boolean;
}

export interface CpBinParetoItem {
  bin_code: number;
  bin_name: string;
  count: number;
  percent_of_fails: number;
  cumulative_percent: number;
}

export interface CpParametricSummaryItem {
  param_name: string;
  param_unit: string;
  measured_rows: number;
  mean: number | null;
  std_dev: number | null;
  min: number | null;
  max: number | null;
}

export interface DatasetCompatibility {
  status: 'MATCHED' | 'MISMATCHED' | 'NOT_LOADED';
  message: string | null;
}

export interface WatCapabilityItem {
  param_name: string;
  unit: string;
  count: number;
  mean: number | null;
  std_dev: number | null;
  spec_low: number | null;
  spec_high: number | null;
  cp: number | null;
  cpk: number | null;
  fail_count: number;
}

export interface KlaCorrelationItem {
  defect_class: string;
  total_defects: number;
  affected_dies: number;
  killed_dies: number;
  kill_ratio_pct: number;
  repeater_defects: number;
}

export interface CpRadialZoneSummary {
  zone: string;
  total_dies: number;
  pass_dies: number;
  fail_dies: number;
  yield_pct: number;
}

export interface CpFailureComponent {
  die_count: number;
  dominant_bin: number;
  dominant_bin_name: string;
  dominant_bin_count: number;
  die_x_min: number;
  die_x_max: number;
  die_y_min: number;
  die_y_max: number;
}

export interface CpObservedScenario {
  edge_exclusion_mm: number;
  included_dies: number;
  excluded_dies: number;
  pass_dies: number;
  fail_dies: number;
  yield_pct: number;
}

export interface CpTelemetrySummary {
  name: string;
  unit: string;
  measured_rows: number;
  mean: number | null;
  std_dev: number | null;
  min: number | null;
  max: number | null;
}

export interface OcapEvidenceItem {
  category: 'CP' | 'Spatial' | 'WAT' | 'KLA';
  label: string;
  value: string;
  detail: string;
}

export interface OcapTriage {
  status: 'NOMINAL' | 'REVIEW' | 'ATTENTION';
  scope_note: string;
  evidence: OcapEvidenceItem[];
  recommendations: string[];
}

interface AnalysisDatasetReference {
  id: number;
  source_type: IngestedDataType;
  wafer_id: string;
  lot_id: string;
  product_id: string;
}

export interface IngestionAnalysisResponse {
  cp: {
    dataset: AnalysisDatasetReference;
    total_dies: number;
    pass_dies: number;
    fail_dies: number;
    yield_pct: number;
    bins: CpBinParetoItem[];
    parametrics: CpParametricSummaryItem[];
    spatial: {
      coordinate_note: string;
      radial_zones: CpRadialZoneSummary[];
      failure_components: {
        component_count: number;
        cluster_count: number;
        clustered_failure_dies: number;
        isolated_failure_dies: number;
        top_clusters: CpFailureComponent[];
      };
    };
    telemetry: CpTelemetrySummary[];
    observed_edge_scenarios: CpObservedScenario[];
  };
  wat: {
    available: boolean;
    dataset: AnalysisDatasetReference | null;
    compatibility?: DatasetCompatibility;
    total_measurements: number;
    fail_measurements: number;
    parameters: WatCapabilityItem[];
  };
  kla: {
    available: boolean;
    dataset: AnalysisDatasetReference | null;
    compatibility?: DatasetCompatibility;
    total_defects: number;
    repeater_defects: number;
    correlations: KlaCorrelationItem[];
  };
  ocap: OcapTriage;
}
