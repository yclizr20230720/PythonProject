import { describe, expect, it } from "vitest";
import { calculateClientSpatialAnalytics, generateClientWaferLayout } from "./waferGeometry";

const waferConfig = {
  wafer_id: "TEST-W300-001",
  lot_id: "LOT-TEST",
  product_id: "PRODUCT-TEST",
  diameter_mm: 300,
  edge_exclusion_mm: 3,
  notch_angle_deg: 270 as const,
  center_offset_x_mm: 0,
  center_offset_y_mm: 0,
};

const dieConfig = {
  width_mm: 8.5,
  height_mm: 10.2,
  scribe_x_mm: 0.08,
  scribe_y_mm: 0.08,
  reticle_cols: 3,
  reticle_rows: 2,
  die_type_matrix: [["LOGIC_CORE", "LOGIC_CORE", "SRAM_CACHE"], ["LOGIC_CORE", "IO_PHY", "ANALOG_PLL"]],
};

describe("WaferMap client geometry", () => {
  it("generates a non-empty 300 mm layout with stable metadata", () => {
    const { layout } = generateClientWaferLayout(waferConfig, dieConfig, "random");
    expect(layout.metadata.diameter_mm).toBe(300);
    expect(layout.metadata.gross_die_count).toBeGreaterThan(0);
    expect(layout.metadata.total_shots).toBeGreaterThan(0);
    expect(layout.dies.length).toBeGreaterThanOrEqual(layout.metadata.gross_die_count);
  });

  it("retains reticle defect visibility through spatial analytics", () => {
    const { layout } = generateClientWaferLayout(waferConfig, dieConfig, "repeater");
    const spatial = calculateClientSpatialAnalytics(layout);
    expect(spatial.radial_zones).toHaveLength(8);
    expect(spatial.angular_sectors).toHaveLength(8);
    expect(spatial.reticle_repeater_matrix).toHaveLength(2);
    expect(spatial.reticle_repeater_matrix[0]).toHaveLength(3);
  });
});
