import { describe, expect, it } from "vitest";
import { fitWaferToViewport, panFromLocalPointer, safeViewport, screenToWaferMm } from "./canvasViewport";

describe("canvas viewport safety", () => {
  it("defers layout fit until a non-zero canvas viewport exists", () => {
    expect(safeViewport(0, 720)).toBeNull();
    expect(safeViewport(1200, 0)).toBeNull();
    expect(safeViewport(1798.8, 666.9)).toEqual({ width: 1798, height: 666 });
  });

  it("fits a 300 mm wafer with finite centered transform values", () => {
    const transform = fitWaferToViewport({ width: 1798, height: 666 }, 300);
    expect(transform.pan).toEqual({ x: 899, y: 333 });
    expect(transform.scale).toBeGreaterThan(0.6);
    expect(Number.isFinite(transform.scale)).toBe(true);
  });

  it("uses canvas-local pointer movement and always returns finite wafer coordinates", () => {
    expect(panFromLocalPointer({ x: 640, y: 320 }, { x: 120, y: 80 })).toEqual({ x: 520, y: 240 });
    expect(screenToWaferMm({ x: 440, y: 300 }, { x: 520, y: 240 }, 2)).toEqual({ x: -40, y: -30 });
    expect(screenToWaferMm({ x: 440, y: 300 }, { x: Infinity, y: Number.NaN }, 0)).toEqual({ x: 440, y: -300 });
  });
});
