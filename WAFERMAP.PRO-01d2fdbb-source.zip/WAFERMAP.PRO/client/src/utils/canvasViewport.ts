export type CanvasPoint = { x: number; y: number };
export type CanvasViewport = { width: number; height: number };

export function safeViewport(width: number, height: number): CanvasViewport | null {
  const measuredWidth = Math.floor(width);
  const measuredHeight = Math.floor(height);
  return Number.isFinite(measuredWidth) && Number.isFinite(measuredHeight) && measuredWidth > 24 && measuredHeight > 24
    ? { width: measuredWidth, height: measuredHeight }
    : null;
}

export function fitWaferToViewport(viewport: CanvasViewport, diameterMm: number): { scale: number; pan: CanvasPoint } {
  const safeDiameter = Number.isFinite(diameterMm) && diameterMm > 0 ? diameterMm : 300;
  const scale = Math.max(0.6, Math.min(25, (Math.min(viewport.width, viewport.height) * 0.82) / safeDiameter));
  return { scale, pan: { x: viewport.width / 2, y: viewport.height / 2 } };
}

export function screenToWaferMm(point: CanvasPoint, pan: CanvasPoint, scale: number): CanvasPoint {
  const safeScale = Number.isFinite(scale) && scale > 0 ? scale : 1;
  const safePanX = Number.isFinite(pan.x) ? pan.x : 0;
  const safePanY = Number.isFinite(pan.y) ? pan.y : 0;
  const x = (point.x - safePanX) / safeScale;
  const y = -(point.y - safePanY) / safeScale;
  return { x: Number.isFinite(x) ? x : 0, y: Number.isFinite(y) ? y : 0 };
}

export function panFromLocalPointer(point: CanvasPoint, pointerOffset: CanvasPoint): CanvasPoint {
  return { x: point.x - pointerOffset.x, y: point.y - pointerOffset.y };
}
