/**
 * Wafer Geometry and Mathematical Calculation Module
 * Provides fast client-side wafer stepping, GDPW placement calculation,
 * color maps, spatial statistics, and SEMI E142/G85 parsers and exporters.
 */

import {
  WaferConfig,
  DieConfig,
  WaferLayoutResponse,
  SpatialAnalytics,
  DefectPatternType,
  ColormapMode,
} from '../types';

export function calculateGDPWFormula(
  diameterMm: number,
  edgeExclusionMm: number,
  dieWMm: number,
  dieHMm: number
): number {
  const rUsable = diameterMm / 2 - edgeExclusionMm;
  if (rUsable <= 0) return 0;
  const areaDie = dieWMm * dieHMm;
  if (areaDie <= 0) return 0;
  const term1 = (Math.PI * rUsable * rUsable) / areaDie;
  const term2 = (Math.PI * rUsable) / Math.sqrt(2.0 * areaDie);
  return Math.max(0, Math.floor(term1 - term2));
}

export function generateClientWaferLayout(
  waferCfg: WaferConfig,
  dieCfg: DieConfig,
  defectPattern: DefectPatternType = 'random'
): { layout: WaferLayoutResponse; spatial: SpatialAnalytics } {
  const rWafer = waferCfg.diameter_mm / 2.0;
  const rUsable = rWafer - waferCfg.edge_exclusion_mm;

  // Reticle field dimensions
  const reticleW =
    dieCfg.reticle_cols * dieCfg.width_mm +
    (dieCfg.reticle_cols - 1) * dieCfg.scribe_x_mm;
  const reticleH =
    dieCfg.reticle_rows * dieCfg.height_mm +
    (dieCfg.reticle_rows - 1) * dieCfg.scribe_y_mm;

  const pitchX = reticleW + dieCfg.scribe_x_mm;
  const pitchY = reticleH + dieCfg.scribe_y_mm;

  const dieStepX = dieCfg.width_mm + dieCfg.scribe_x_mm;
  const dieStepY = dieCfg.height_mm + dieCfg.scribe_y_mm;

  const maxShotCols = Math.ceil(rWafer / pitchX) + 2;
  const maxShotRows = Math.ceil(rWafer / pitchY) + 2;

  const dies = [];
  const shots = [];

  let grossDieCount = 0;
  let passDieCount = 0;
  let failDieCount = 0;
  let partialDieCount = 0;

  const repeaterR = dieCfg.reticle_rows > 1 ? 1 : 0;
  const repeaterC = dieCfg.reticle_cols > 2 ? 2 : 0;

  const scratchP1 = [-70.0, 60.0];
  const scratchP2 = [80.0, -40.0];

  for (let sRow = -maxShotRows; sRow <= maxShotRows; sRow++) {
    for (let sCol = -maxShotCols; sCol <= maxShotCols; sCol++) {
      const sCenterX = waferCfg.center_offset_x_mm + sCol * pitchX;
      const sCenterY = waferCfg.center_offset_y_mm + sRow * pitchY;

      const sHalfW = reticleW / 2.0;
      const sHalfH = reticleH / 2.0;

      const sMinDist =
        Math.sqrt(sCenterX * sCenterX + sCenterY * sCenterY) -
        Math.sqrt(sHalfW * sHalfW + sHalfH * sHalfH);
      if (sMinDist > rWafer) continue;

      const shotId = `S(${sRow >= 0 ? '+' : ''}${sRow},${sCol >= 0 ? '+' : ''}${sCol})`;
      const shotDies = [];
      let shotPass = 0;
      let shotFail = 0;

      for (let rRow = 0; rRow < dieCfg.reticle_rows; rRow++) {
        for (let rCol = 0; rCol < dieCfg.reticle_cols; rCol++) {
          const localX =
            -sHalfW + rCol * dieStepX + dieCfg.width_mm / 2.0;
          const localY =
            sHalfH - rRow * dieStepY - dieCfg.height_mm / 2.0;

          const dieXMm = sCenterX + localX;
          const dieYMm = sCenterY + localY;

          const globalDieX = sCol * dieCfg.reticle_cols + rCol;
          const globalDieY =
            sRow * dieCfg.reticle_rows + (dieCfg.reticle_rows - 1 - rRow);

          const dHalfW = dieCfg.width_mm / 2.0;
          const dHalfH = dieCfg.height_mm / 2.0;

          const corners = [
            [dieXMm - dHalfW, dieYMm - dHalfH],
            [dieXMm + dHalfW, dieYMm - dHalfH],
            [dieXMm + dHalfW, dieYMm + dHalfH],
            [dieXMm - dHalfW, dieYMm + dHalfH],
          ];

          let insideCount = 0;
          for (let k = 0; k < 4; k++) {
            const dist = Math.sqrt(
              corners[k][0] * corners[k][0] + corners[k][1] * corners[k][1]
            );
            if (dist <= rUsable) insideCount++;
          }

          const centerDist = Math.sqrt(dieXMm * dieXMm + dieYMm * dieYMm);
          const angleRad = Math.atan2(dieYMm, dieXMm);
          const angleDeg = ((angleRad * 180) / Math.PI + 360) % 360;

          let status: 'FULL' | 'PARTIAL' | 'OUTSIDE' = 'OUTSIDE';
          let isYieldable = false;

          if (insideCount === 4) {
            status = 'FULL';
            isYieldable = true;
            grossDieCount++;
          } else if (insideCount > 0 || centerDist <= rUsable) {
            status = 'PARTIAL';
            partialDieCount++;
          } else {
            continue;
          }

          let dieType = 'PRODUCT_DIE';
          if (
            rRow < dieCfg.die_type_matrix.length &&
            rCol < dieCfg.die_type_matrix[rRow].length
          ) {
            dieType = dieCfg.die_type_matrix[rRow][rCol];
          }

          // Simulate Defect Distribution
          const normR = centerDist / rUsable;
          let failProb = 0.04;

          if (defectPattern === 'edge_ring') {
            if (normR > 0.82) {
              failProb += 0.65 * Math.pow((normR - 0.82) / 0.18, 1.8);
            }
          } else if (defectPattern === 'center_cluster') {
            if (normR < 0.35) {
              failProb += 0.7 * Math.pow(1.0 - normR / 0.35, 1.5);
            }
          } else if (defectPattern === 'scratch') {
            const x1 = scratchP1[0],
              y1 = scratchP1[1];
            const x2 = scratchP2[0],
              y2 = scratchP2[1];
            const dx = x2 - x1;
            const dy = y2 - y1;
            const l2 = dx * dx + dy * dy;
            if (l2 > 0) {
              const t = Math.max(
                0,
                Math.min(1, ((dieXMm - x1) * dx + (dieYMm - y1) * dy) / l2)
              );
              const projX = x1 + t * dx;
              const projY = y1 + t * dy;
              const distToScratch = Math.sqrt(
                (dieXMm - projX) * (dieXMm - projX) +
                  (dieYMm - projY) * (dieYMm - projY)
              );
              if (distToScratch < 12.0) {
                failProb += 0.85 * (1.0 - distToScratch / 12.0);
              }
            }
          } else if (defectPattern === 'repeater') {
            if (rRow === repeaterR && rCol === repeaterC) {
              failProb = 0.95;
            }
          } else if (defectPattern === 'donut') {
            if (normR >= 0.45 && normR <= 0.75) {
              const midDist = Math.abs(normR - 0.6) / 0.15;
              failProb += 0.6 * Math.max(0.0, 1.0 - midDist);
            }
          }

          // Deterministic Pseudo-Random Generator
          const seed = Math.sin(globalDieX * 12.9898 + globalDieY * 78.233) * 43758.5453;
          const pseudoRand = seed - Math.floor(seed);
          const isFail = isYieldable ? pseudoRand < failProb : true;

          let binCode = 1;
          let binName = 'PASS_GOOD';
          let binQuality: 'PASS' | 'FAIL' | 'NULL' = 'PASS';
          let paramVal = 95.0;
          let leakageUa = 12.0;
          let testFreq = 3.6;
          let defectCount = 0;

          if (!isYieldable) {
            binCode = 99;
            binName = 'EDGE_PARTIAL';
            binQuality = 'NULL';
            paramVal = 0.0;
            leakageUa = 999.0;
            testFreq = 0.0;
            defectCount = 0;
          } else if (!isFail) {
            binCode = 1;
            binName = 'PASS_GOOD';
            binQuality = 'PASS';
            passDieCount++;
            shotPass++;
            paramVal = +(92.0 + (1.0 - normR) * 7.5 + (pseudoRand - 0.5) * 2.5).toFixed(2);
            testFreq = +(3.4 + (1.0 - normR * 0.4) * 0.6 + (pseudoRand - 0.5) * 0.15).toFixed(3);
            leakageUa = +(8.5 + normR * 4.2 + (pseudoRand - 0.5) * 1.5).toFixed(2);
            defectCount = pseudoRand > 0.92 ? 1 : 0;
          } else {
            failDieCount++;
            shotFail++;
            binQuality = 'FAIL';
            if (defectPattern === 'repeater' && rRow === repeaterR && rCol === repeaterC) {
              binCode = 6;
              binName = 'FAIL_RETICLE_DEFECT';
            } else if (normR > 0.85) {
              binCode = 4;
              binName = 'FAIL_EDGE_LEAKAGE';
            } else if (pseudoRand < 0.4) {
              binCode = 2;
              binName = 'FAIL_CORE_VOLTAGE';
            } else if (pseudoRand < 0.7) {
              binCode = 5;
              binName = 'FAIL_TIMING_MARGIN';
            } else {
              binCode = 7;
              binName = 'FAIL_PARTICLE_DEFECT';
            }
            paramVal = +(55.0 + pseudoRand * 25.0).toFixed(2);
            testFreq = +(2.1 + pseudoRand * 0.9).toFixed(3);
            leakageUa = +(45.0 + pseudoRand * 85.0).toFixed(2);
            defectCount = Math.floor(1 + pseudoRand * 3);
          }

          const dieUid = `${waferCfg.wafer_id}-S${sRow >= 0 ? '+' : ''}${sRow}_${sCol >= 0 ? '+' : ''}${sCol}-R${rRow}_${rCol}`;
          const dieObj = {
            die_uid: dieUid,
            global_x: globalDieX,
            global_y: globalDieY,
            center_x_mm: +dieXMm.toFixed(4),
            center_y_mm: +dieYMm.toFixed(4),
            width_mm: +dieCfg.width_mm.toFixed(4),
            height_mm: +dieCfg.height_mm.toFixed(4),
            shot_row: sRow,
            shot_col: sCol,
            reticle_row: rRow,
            reticle_col: rCol,
            die_type: dieType,
            status,
            is_yieldable: isYieldable,
            bin_code: binCode,
            bin_name: binName,
            bin_quality: binQuality,
            parametric_val: paramVal,
            test_freq_ghz: testFreq,
            leakage_ua: leakageUa,
            defect_count: defectCount,
            radial_dist_mm: +centerDist.toFixed(3),
            angle_deg: +angleDeg.toFixed(2),
          };

          dies.push(dieObj);
          shotDies.push(dieObj);
        }
      }

      if (shotDies.length > 0) {
        const tot = shotDies.length;
        const sYield = (shotPass / tot) * 100.0;
        const shotStatus = shotDies.every((d) => d.status === 'FULL')
          ? ('FULL' as const)
          : ('PARTIAL' as const);
        shots.push({
          shot_id: shotId,
          shot_row: sRow,
          shot_col: sCol,
          center_x_mm: +sCenterX.toFixed(4),
          center_y_mm: +sCenterY.toFixed(4),
          width_mm: +reticleW.toFixed(4),
          height_mm: +reticleH.toFixed(4),
          status: shotStatus,
          total_dies: tot,
          pass_dies: shotPass,
          fail_dies: shotFail,
          yield_pct: +sYield.toFixed(2),
        });
      }
    }
  }

  const theoreticalGdpw = calculateGDPWFormula(
    waferCfg.diameter_mm,
    waferCfg.edge_exclusion_mm,
    dieCfg.width_mm,
    dieCfg.height_mm
  );
  const actualYieldPct =
    grossDieCount > 0 ? (passDieCount / grossDieCount) * 100.0 : 0.0;

  const layout: WaferLayoutResponse = {
    metadata: {
      wafer_id: waferCfg.wafer_id,
      lot_id: waferCfg.lot_id,
      product_id: waferCfg.product_id,
      diameter_mm: waferCfg.diameter_mm,
      edge_exclusion_mm: waferCfg.edge_exclusion_mm,
      usable_radius_mm: +rUsable.toFixed(3),
      notch_angle_deg: waferCfg.notch_angle_deg,
      center_offset_x_mm: waferCfg.center_offset_x_mm,
      center_offset_y_mm: waferCfg.center_offset_y_mm,
      theoretical_gdpw: theoreticalGdpw,
      gross_die_count: grossDieCount,
      pass_die_count: passDieCount,
      fail_die_count: failDieCount,
      partial_die_count: partialDieCount,
      yield_pct: +actualYieldPct.toFixed(2),
      reticle_field_w_mm: +reticleW.toFixed(4),
      reticle_field_h_mm: +reticleH.toFixed(4),
      reticle_rows: dieCfg.reticle_rows,
      reticle_cols: dieCfg.reticle_cols,
      shot_pitch_x_mm: +pitchX.toFixed(4),
      shot_pitch_y_mm: +pitchY.toFixed(4),
      total_shots: shots.length,
      defect_pattern: defectPattern,
    },
    dies,
    shots,
  };

  // Compute Spatial Analytics
  const spatial = calculateClientSpatialAnalytics(layout);

  return { layout, spatial };
}

export function calculateClientSpatialAnalytics(
  layout: WaferLayoutResponse
): SpatialAnalytics {
  const dies = layout.dies;
  const yieldableDies = dies.filter((d) => d.is_yieldable);

  const rMax = layout.metadata.usable_radius_mm;
  const numRings = 8;
  const ringWidth = rMax / numRings;

  const rings = Array.from({ length: numRings }, (_, i) => ({
    zone: `Zone ${i + 1} (${Math.round(i * ringWidth)}-${Math.round((i + 1) * ringWidth)}mm)`,
    radius_min: i * ringWidth,
    radius_max: (i + 1) * ringWidth,
    total: 0,
    pass: 0,
    fail: 0,
    yield_pct: 0,
    mean_param: 0,
  }));

  const sectorLabels = [
    'E (0°)',
    'NE (45°)',
    'N (90°)',
    'NW (135°)',
    'W (180°)',
    'SW (225°)',
    'S (270°)',
    'SE (315°)',
  ];
  const sectors = sectorLabels.map((label, i) => ({
    sector: label,
    angle_min: i * 45.0,
    angle_max: (i + 1) * 45.0,
    total: 0,
    pass: 0,
    fail: 0,
    yield_pct: 0,
  }));

  const rRows = layout.metadata.reticle_rows;
  const rCols = layout.metadata.reticle_cols;
  const reticleMatrix = Array.from({ length: rRows }, (_, r) =>
    Array.from({ length: rCols }, (_, c) => ({
      reticle_row: r,
      reticle_col: c,
      total: 0,
      pass: 0,
      fail: 0,
      fail_rate_pct: 0,
    }))
  );

  for (const d of yieldableDies) {
    // Rings
    const ringIdx = Math.min(numRings - 1, Math.floor(d.radial_dist_mm / ringWidth));
    rings[ringIdx].total++;
    if (d.bin_quality === 'PASS') rings[ringIdx].pass++;
    else rings[ringIdx].fail++;

    // Sectors
    const secIdx = Math.floor(d.angle_deg / 45.0) % 8;
    sectors[secIdx].total++;
    if (d.bin_quality === 'PASS') sectors[secIdx].pass++;
    else sectors[secIdx].fail++;

    // Reticle matrix
    if (d.reticle_row < rRows && d.reticle_col < rCols) {
      const cell = reticleMatrix[d.reticle_row][d.reticle_col];
      cell.total++;
      if (d.bin_quality === 'PASS') cell.pass++;
      else cell.fail++;
    }
  }

  for (const r of rings) {
    if (r.total > 0) r.yield_pct = +((r.pass / r.total) * 100).toFixed(2);
  }
  for (const s of sectors) {
    if (s.total > 0) s.yield_pct = +((s.pass / s.total) * 100).toFixed(2);
  }
  for (let r = 0; r < rRows; r++) {
    for (let c = 0; c < rCols; c++) {
      const cell = reticleMatrix[r][c];
      cell.fail_rate_pct = +(
        cell.total > 0 ? (cell.fail / cell.total) * 100 : 0
      ).toFixed(2);
    }
  }

  // Moran's I
  const sample =
    yieldableDies.length <= 400
      ? yieldableDies
      : yieldableDies.slice(0, 400);
  const n = sample.length;
  const vals = sample.map((d) => (d.bin_quality === 'FAIL' ? 1.0 : 0.0));
  const meanVal = vals.reduce<number>((a, b) => a + b, 0) / (n || 1);
  let s0 = 0;
  let numerator = 0;
  let denom = vals.reduce<number>((acc, v) => acc + (v - meanVal) * (v - meanVal), 0) + 1e-9;

  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const dx = sample[i].center_x_mm - sample[j].center_x_mm;
      const dy = sample[i].center_y_mm - sample[j].center_y_mm;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > 0 && dist <= 25.0) {
        const w = 1.0 / dist;
        s0 += 2 * w;
        numerator += 2 * w * (vals[i] - meanVal) * (vals[j] - meanVal);
      }
    }
  }

  let moranI = 0;
  if (s0 > 0 && denom > 0) {
    moranI = (n / s0) * (numerator / denom);
  }

  let clusteringLevel = 'Random / Uniform Distribution';
  if (moranI > 0.35) {
    clusteringLevel = 'Severe Spatial Clustering (Scratch / Edge Ring)';
  } else if (moranI > 0.15) {
    clusteringLevel = 'Moderate Clustering (Localized Cluster)';
  } else if (moranI < -0.1) {
    clusteringLevel = 'Dispersed / Alternating Pattern';
  }

  return {
    moran_i: +moranI.toFixed(4),
    clustering_level: clusteringLevel,
    radial_zones: rings,
    angular_sectors: sectors,
    reticle_repeater_matrix: reticleMatrix,
  };
}

// Colormaps
export function getColormapColor(
  value: number,
  minVal: number,
  maxVal: number,
  colormap: ColormapMode = 'turbo'
): string {
  const t = Math.max(0, Math.min(1, (value - minVal) / (maxVal - minVal || 1)));

  if (colormap === 'turbo') {
    // High-contrast perceptual colormap
    const r = Math.sin(t * Math.PI * 1.5 - 0.5) * 127 + 128;
    const g = Math.sin(t * Math.PI * 2.0 - 1.0) * 127 + 128;
    const b = Math.sin((1 - t) * Math.PI * 1.5 - 0.5) * 127 + 128;
    return `rgb(${Math.floor(r)}, ${Math.floor(g)}, ${Math.floor(b)})`;
  } else if (colormap === 'viridis') {
    const r = Math.floor(68 + t * (253 - 68));
    const g = Math.floor(1 + t * (231 - 1));
    const b = Math.floor(84 + (1 - t) * (140 - 84));
    return `rgb(${r}, ${g}, ${b})`;
  } else if (colormap === 'plasma') {
    const r = Math.floor(13 + t * 227);
    const g = Math.floor(8 + t * 180);
    const b = Math.floor(135 + (1 - t) * 90);
    return `rgb(${r}, ${g}, ${b})`;
  } else if (colormap === 'coolwarm') {
    const r = Math.floor(59 + t * (180 - 59));
    const g = Math.floor(76 + (1 - Math.abs(t - 0.5) * 2) * 100);
    const b = Math.floor(192 - t * (192 - 60));
    return `rgb(${r}, ${g}, ${b})`;
  }

  // Inferno
  const r = Math.floor(t * 252);
  const g = Math.floor(Math.pow(t, 2) * 255);
  const b = Math.floor(Math.pow(1 - t, 3) * 128);
  return `rgb(${r}, ${g}, ${b})`;
}

// Bin Color Code mapping
export const BIN_COLORS: Record<number, { bg: string; border: string; name: string }> = {
  1: { bg: '#10b981', border: '#059669', name: 'PASS_GOOD (Bin 01)' },
  2: { bg: '#ef4444', border: '#dc2626', name: 'FAIL_VOLTAGE (Bin 02)' },
  3: { bg: '#f97316', border: '#ea580c', name: 'FAIL_OPEN_SHORT (Bin 03)' },
  4: { bg: '#eab308', border: '#ca8a04', name: 'FAIL_LEAKAGE (Bin 04)' },
  5: { bg: '#8b5cf6', border: '#7c3aed', name: 'FAIL_TIMING (Bin 05)' },
  6: { bg: '#ec4899', border: '#db2777', name: 'FAIL_RETICLE_DEFECT (Bin 06)' },
  7: { bg: '#06b6d4', border: '#0891b2', name: 'FAIL_PARTICLE (Bin 07)' },
  99: { bg: '#334155', border: '#475569', name: 'EDGE_PARTIAL (Bin 99)' },
};

export const DIE_TYPE_COLORS: Record<string, { bg: string; border: string; name: string; code: string }> = {
  LOGIC_CORE: { bg: '#3b82f6', border: '#2563eb', name: 'Logic Core Die', code: 'LOGIC' },
  SRAM_CACHE: { bg: '#8b5cf6', border: '#7c3aed', name: 'SRAM Cache Array', code: 'SRAM' },
  IO_PHY: { bg: '#06b6d4', border: '#0891b2', name: 'High-Speed I/O PHY', code: 'I/O' },
  ANALOG_PLL: { bg: '#f59e0b', border: '#d97706', name: 'Analog PLL / SerDes', code: 'PLL' },
  TEST_KEY: { bg: '#10b981', border: '#059669', name: 'Kerf Test Structure', code: 'KERF' },
  PRODUCT_DIE: { bg: '#6366f1', border: '#4f46e5', name: 'Standard Product Die', code: 'PROD' },
};
