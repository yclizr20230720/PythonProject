import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Database,
  FileSearch,
  Filter,
  Loader2,
  RefreshCw,
  Search,
  Upload,
  X,
} from 'lucide-react';
import {
  CpDieRecord,
  IngestedDataType,
  IngestedWaferData,
  IngestionDatasetResult,
  IngestionDatasetSummary,
  KlaDefectItem,
  PersistedDatasetCatalog,
  PersistedIngestionDataset,
  WatMeasurementItem,
} from '../types';

const SOURCE_STYLE: Record<IngestedDataType, { accent: string; label: string }> = {
  CP: { accent: '#00FF9C', label: 'CP wafer sort' },
  WAT: { accent: '#00E5FF', label: 'WAT metrology' },
  KLA: { accent: '#FF5A52', label: 'KLA defect inspection' },
};

interface OverlayPayload {
  dataset: {
    id: number;
    source_type: IngestedDataType;
    wafer_id: string;
    lot_id: string;
    product_id: string;
    summary: IngestionDatasetSummary;
  };
  records?: unknown[];
  columns?: string[];
  rows?: unknown[][];
}

interface DataCriteriaExplorerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenIngestion: () => void;
  onOpenAnalysis: () => void;
  onApply: (data: IngestedWaferData) => void;
}

interface CriteriaState {
  sourceTypes: IngestedDataType[];
  lotId: string;
  waferId: string;
  productId: string;
}

const EMPTY_CATALOG: PersistedDatasetCatalog = {
  datasets: [],
  criteria: { source_types: [], lot_ids: [], wafer_ids: [], product_ids: [] },
  persistence_available: false,
};

function asSourceType(value: unknown): IngestedDataType | null {
  return value === 'CP' || value === 'WAT' || value === 'KLA' ? value : null;
}

function asDataset(item: Record<string, unknown>): PersistedIngestionDataset | null {
  const sourceType = asSourceType(item.sourceType);
  if (!sourceType || !Number.isInteger(Number(item.id))) return null;
  return {
    id: Number(item.id),
    source_type: sourceType,
    wafer_id: String(item.waferId || 'UNSPECIFIED-WAFER'),
    lot_id: String(item.lotId || 'UNSPECIFIED-LOT'),
    product_id: String(item.productId || 'UNSPECIFIED-PRODUCT'),
    original_filename: String(item.originalFilename || 'source-file'),
    valid_rows: Number(item.validRows || 0),
    error_rows: Number(item.errorRows || 0),
    created_at: item.createdAt ? String(item.createdAt) : null,
  };
}

function unpackRecords(payload: OverlayPayload): Record<string, unknown>[] {
  if (Array.isArray(payload.records)) return payload.records as Record<string, unknown>[];
  if (!Array.isArray(payload.columns) || !Array.isArray(payload.rows)) return [];
  return payload.rows.map(row => Object.fromEntries(payload.columns!.map((column, index) => [column, row[index]])));
}

function formatTimestamp(value: string | null): string {
  if (!value) return 'Timestamp unavailable';
  const timestamp = new Date(value);
  return Number.isNaN(timestamp.getTime()) ? value : timestamp.toLocaleString();
}

export function DataCriteriaExplorer({ isOpen, onClose, onOpenIngestion, onOpenAnalysis, onApply }: DataCriteriaExplorerProps) {
  const [criteria, setCriteria] = useState<CriteriaState>({ sourceTypes: [], lotId: '', waferId: '', productId: '' });
  const [catalog, setCatalog] = useState<PersistedDatasetCatalog>(EMPTY_CATALOG);
  const [loading, setLoading] = useState(false);
  const [openingId, setOpeningId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadCatalog = useCallback(async (nextCriteria: CriteriaState) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: '50' });
      if (nextCriteria.sourceTypes.length) params.set('source_types', nextCriteria.sourceTypes.join(','));
      if (nextCriteria.lotId) params.set('lot_id', nextCriteria.lotId);
      if (nextCriteria.waferId) params.set('wafer_id', nextCriteria.waferId);
      if (nextCriteria.productId) params.set('product_id', nextCriteria.productId);
      const response = await fetch(`/api/ingestion/catalog?${params.toString()}`);
      const payload = await response.json() as Record<string, unknown>;
      if (!response.ok) throw new Error(String(payload.message || 'The persisted source catalog is unavailable.'));
      const datasets = Array.isArray(payload.datasets)
        ? payload.datasets.map(item => asDataset(item as Record<string, unknown>)).filter((item): item is PersistedIngestionDataset => item !== null)
        : [];
      const rawCriteria = (payload.criteria || {}) as Record<string, unknown>;
      setCatalog({
        datasets,
        persistence_available: Boolean(payload.persistence_available),
        criteria: {
          source_types: Array.isArray(rawCriteria.source_types) ? rawCriteria.source_types.map(asSourceType).filter((item): item is IngestedDataType => item !== null) : [],
          lot_ids: Array.isArray(rawCriteria.lot_ids) ? rawCriteria.lot_ids.map(String) : [],
          wafer_ids: Array.isArray(rawCriteria.wafer_ids) ? rawCriteria.wafer_ids.map(String) : [],
          product_ids: Array.isArray(rawCriteria.product_ids) ? rawCriteria.product_ids.map(String) : [],
        },
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to load persisted source criteria.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) void loadCatalog(criteria);
  }, [isOpen, criteria, loadCatalog]);

  const toggleSource = (sourceType: IngestedDataType) => {
    setCriteria(current => ({
      ...current,
      sourceTypes: current.sourceTypes.includes(sourceType)
        ? current.sourceTypes.filter(type => type !== sourceType)
        : [...current.sourceTypes, sourceType],
    }));
  };

  const clearCriteria = () => setCriteria({ sourceTypes: [], lotId: '', waferId: '', productId: '' });
  const activeCriteriaCount = criteria.sourceTypes.length + Number(Boolean(criteria.lotId)) + Number(Boolean(criteria.waferId)) + Number(Boolean(criteria.productId));

  const openDataset = async (selected: PersistedIngestionDataset) => {
    setOpeningId(selected.id);
    setError(null);
    try {
      const response = await fetch(`/api/ingestion/datasets/${selected.id}/overlay`);
      const payload = await response.json() as OverlayPayload & { message?: string };
      if (!response.ok) throw new Error(payload.message || 'The selected source overlay could not be loaded.');
      const sourceType = asSourceType(payload.dataset?.source_type);
      if (!sourceType) throw new Error('The selected source has an unsupported type.');
      const records = unpackRecords(payload);
      const dataset: IngestionDatasetResult = {
        dataset_id: Number(payload.dataset.id),
        source_type: sourceType,
        storage_url: '',
        summary: payload.dataset.summary,
      };
      onApply({
        dataset,
        ...(sourceType === 'CP' ? { cpRecords: records as unknown as CpDieRecord[] } : {}),
        ...(sourceType === 'WAT' ? { watRecords: records as unknown as WatMeasurementItem[] } : {}),
        ...(sourceType === 'KLA' ? { klaRecords: records as unknown as KlaDefectItem[] } : {}),
      });
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to open the selected source.');
    } finally {
      setOpeningId(null);
    }
  };

  const criteriaSummary = useMemo(() => activeCriteriaCount ? `${activeCriteriaCount} active criterion${activeCriteriaCount === 1 ? '' : 'a'}` : 'No criteria applied', [activeCriteriaCount]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-label="Persisted source criteria explorer">
      <section className="flex max-h-[94vh] w-full max-w-7xl flex-col overflow-hidden rounded-xl border border-[#00E5FF]/30 bg-[#0e0e0e] text-[#ddd] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#00E5FF]/20 bg-[#101517] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#00E5FF]/35 bg-[#00E5FF]/10 text-[#00E5FF]"><Filter className="h-5 w-5" /></div>
            <div className="min-w-0"><div className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#00E5FF]">Persisted source pipeline</div><h2 className="mt-0.5 text-base font-bold tracking-wide text-white sm:text-lg">DATA CRITERIA & SOURCE EXPLORER</h2><p className="mt-0.5 text-xs text-neutral-400">Filter retained CP, WAT, and KLA datasets by their stored source identities. Results never fall back to synthetic lots or generated data.</p></div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white" aria-label="Close persisted source criteria explorer"><X className="h-5 w-5" /></button>
        </header>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {error && <div role="alert" className="mb-4 flex items-start gap-2 rounded-lg border border-red-800 bg-red-950/40 p-3 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}
          <div className="grid gap-5 xl:grid-cols-[minmax(255px,0.32fr)_minmax(0,1fr)]">
            <aside className="rounded-xl border border-[#273335] bg-[#111718] p-4">
              <div className="mb-4 flex items-center justify-between"><div><h3 className="text-xs font-bold uppercase tracking-wider text-white">Dataset definition</h3><p className="mt-1 text-[11px] text-neutral-500">{criteriaSummary}</p></div><button type="button" onClick={clearCriteria} disabled={!activeCriteriaCount} className="rounded border border-[#3a4a4d] px-2 py-1 text-[10px] font-bold uppercase text-[#8ba2a5] transition-colors hover:border-[#00E5FF] hover:text-[#00E5FF] disabled:opacity-40">Reset</button></div>
              <div className="space-y-4">
                <fieldset><legend className="mb-2 text-[10px] font-bold uppercase tracking-widest text-[#6c8588]">Source type</legend><div className="space-y-1.5">{(['CP', 'WAT', 'KLA'] as IngestedDataType[]).map(sourceType => { const enabled = criteria.sourceTypes.includes(sourceType); const style = SOURCE_STYLE[sourceType]; return <button type="button" key={sourceType} onClick={() => toggleSource(sourceType)} className={`flex w-full items-center justify-between rounded border px-3 py-2 text-left text-xs transition-colors ${enabled ? 'border-[#00E5FF]/70 bg-[#00E5FF]/10 text-white' : 'border-[#2b383a] bg-[#0d1112] text-neutral-400 hover:border-[#00E5FF]/40'}`}><span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: style.accent }} />{style.label}</span>{enabled && <Check className="h-3.5 w-3.5 text-[#00E5FF]" />}</button>; })}</div></fieldset>
                <CriteriaSelect label="Product / reticle" value={criteria.productId} options={catalog.criteria.product_ids} onChange={productId => setCriteria(current => ({ ...current, productId }))} />
                <CriteriaSelect label="Lot identity" value={criteria.lotId} options={catalog.criteria.lot_ids} onChange={lotId => setCriteria(current => ({ ...current, lotId }))} />
                <CriteriaSelect label="Wafer identity" value={criteria.waferId} options={catalog.criteria.wafer_ids} onChange={waferId => setCriteria(current => ({ ...current, waferId }))} />
              </div>
              <div className="mt-5 border-t border-[#283638] pt-4"><p className="flex items-start gap-2 text-[10px] leading-relaxed text-[#718386]"><Database className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#00E5FF]" />All cards originate from the retained ingestion index and preserve source file, import-run, and normalized-record lineage.</p></div>
            </aside>

            <section className="min-w-0 rounded-xl border border-[#252525] bg-[#121212]">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#252525] px-4 py-3 sm:px-5"><div><h3 className="flex items-center gap-2 text-sm font-bold text-white"><FileSearch className="h-4 w-4 text-[#00E5FF]" />Matched retained datasets</h3><p className="mt-0.5 text-[11px] text-neutral-500">{catalog.datasets.length} result{catalog.datasets.length === 1 ? '' : 's'} · maximum 50 per query</p></div><button type="button" onClick={() => void loadCatalog(criteria)} disabled={loading} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />Refresh</button></div>
              <div className="max-h-[58vh] overflow-y-auto p-4 sm:p-5">
                {loading && catalog.datasets.length === 0 ? <div className="flex min-h-60 items-center justify-center gap-2 text-sm text-neutral-400"><Loader2 className="h-5 w-5 animate-spin text-[#00E5FF]" />Loading persisted source index…</div> : catalog.datasets.length === 0 ? <div className="flex min-h-60 flex-col items-center justify-center rounded-lg border border-dashed border-[#303c3e] p-8 text-center"><Search className="mb-3 h-8 w-8 text-neutral-600" /><h4 className="text-sm font-bold text-white">No retained source matches this definition</h4><p className="mt-2 max-w-sm text-xs leading-relaxed text-neutral-400">Adjust the criteria or ingest a validated CP, WAT, or KLA data source. The explorer does not substitute sample records.</p><button type="button" onClick={onOpenIngestion} className="mt-4 flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Ingest source data</button></div> : <div className="grid gap-3 lg:grid-cols-2">{catalog.datasets.map(dataset => <DatasetCard key={dataset.id} dataset={dataset} opening={openingId === dataset.id} disabled={openingId !== null} onOpen={() => void openDataset(dataset)} />)}</div>}
              </div>
            </section>
          </div>
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#00E5FF]/20 bg-[#101517] px-5 py-3.5 sm:px-6"><span className="text-[10px] text-[#718386]">Read-only criteria surface · no arbitrary table browsing · no simulated production fallback</span><div className="ml-auto flex gap-2"><button type="button" onClick={onOpenAnalysis} className="rounded border border-[#00FF9C]/45 bg-[#00FF9C]/10 px-3 py-2 text-xs font-bold text-[#00FF9C] hover:bg-[#00FF9C]/20">Open CP analysis</button><button type="button" onClick={onOpenIngestion} className="flex items-center gap-2 rounded bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Ingest data</button></div></footer>
      </section>
    </div>
  );
}

function CriteriaSelect({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) {
  return <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-[#6c8588]">{label}</span><div className="relative"><select value={value} onChange={event => onChange(event.target.value)} className="w-full appearance-none rounded border border-[#2b383a] bg-[#0d1112] px-3 py-2 pr-8 font-mono text-xs text-[#d7e1e2] outline-none transition-colors focus:border-[#00E5FF]"><option value="">All retained values</option>{options.map(option => <option key={option} value={option}>{option}</option>)}</select><ChevronDown className="pointer-events-none absolute right-2.5 top-2.5 h-3.5 w-3.5 text-[#6c8588]" /></div></label>;
}

function DatasetCard({ dataset, opening, disabled, onOpen }: { dataset: PersistedIngestionDataset; opening: boolean; disabled: boolean; onOpen: () => void }) {
  const style = SOURCE_STYLE[dataset.source_type];
  return <article className="rounded-lg border border-[#2b3334] bg-[#151a1b] p-3.5 transition-colors hover:border-[#4a5e61]"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="flex items-center gap-2"><span className="rounded px-1.5 py-0.5 font-mono text-[10px] font-bold" style={{ backgroundColor: `${style.accent}1e`, color: style.accent }}>{dataset.source_type}</span><span className="truncate font-mono text-xs font-bold text-white" title={dataset.original_filename}>{dataset.original_filename}</span></div><p className="mt-1 font-mono text-[10px] text-[#708083]">Dataset #{dataset.id} · {formatTimestamp(dataset.created_at)}</p></div><button type="button" onClick={onOpen} disabled={disabled} className="shrink-0 rounded border px-2.5 py-1.5 text-[11px] font-bold transition-colors disabled:cursor-wait disabled:opacity-60" style={{ borderColor: `${style.accent}88`, color: style.accent }}>{opening ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Load map'}</button></div><div className="mt-3 grid grid-cols-3 gap-2 border-t border-[#293233] pt-3 font-mono text-[10px]"><div><span className="block text-[#6f7f82]">Product</span><strong className="block truncate text-[#d7e1e2]" title={dataset.product_id}>{dataset.product_id}</strong></div><div><span className="block text-[#6f7f82]">Lot / wafer</span><strong className="block truncate text-[#d7e1e2]" title={`${dataset.lot_id} / ${dataset.wafer_id}`}>{dataset.lot_id}</strong></div><div><span className="block text-[#6f7f82]">Validated rows</span><strong className="text-[#d7e1e2]">{dataset.valid_rows.toLocaleString()}</strong></div></div></article>;
}
