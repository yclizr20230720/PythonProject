import { describe, expect, it } from 'vitest';
import { buildCpYmsReport } from './CPAnalysisStudio';
import type { IngestionAnalysisResponse } from '../types';

const analysis: IngestionAnalysisResponse = {
  cp: {
    dataset: { id: 41, source_type: 'CP', lot_id: 'LOT-41', wafer_id: 'W300-41', product_id: 'PROD-41' },
    total_dies: 12,
    pass_dies: 10,
    fail_dies: 2,
    yield_pct: 83.33,
    bins: [{ bin_code: 3, bin_name: 'CONTINUITY', count: 2, percent_of_fails: 100, cumulative_percent: 100 }],
    parametrics: [{ param_name: 'VTH', param_unit: 'V', measured_rows: 12, mean: 0.33, std_dev: 0.02, min: 0.28, max: 0.37 }],
    spatial: {
      coordinate_note: 'Imported coordinates only.',
      radial_zones: [{ zone: 'Center 0–50 mm', total_dies: 12, pass_dies: 10, fail_dies: 2, yield_pct: 83.33 }],
      failure_components: { component_count: 2, cluster_count: 1, clustered_failure_dies: 2, isolated_failure_dies: 0, top_clusters: [{ die_count: 2, dominant_bin: 3, dominant_bin_name: 'CONTINUITY', dominant_bin_count: 2, die_x_min: 0, die_x_max: 1, die_y_min: 0, die_y_max: 0 }] },
    },
    telemetry: [{ name: 'Test frequency', unit: 'GHz', measured_rows: 0, mean: null, std_dev: null, min: null, max: null }],
    observed_edge_scenarios: [{ edge_exclusion_mm: 3, included_dies: 12, excluded_dies: 0, pass_dies: 10, fail_dies: 2, yield_pct: 83.33 }],
  },
  wat: { available: false, dataset: null, total_measurements: 0, fail_measurements: 0, parameters: [] },
  kla: { available: false, dataset: null, total_defects: 0, repeater_defects: 0, correlations: [] },
  ocap: { status: 'REVIEW', scope_note: 'Observed data only.', evidence: [{ category: 'CP', label: 'Primary detractor', value: '2 dies', detail: 'CONTINUITY' }], recommendations: ['Review source evidence.'] },
};

describe('buildCpYmsReport', () => {
  it('exports source-backed aggregates with explicit governance exclusions', () => {
    const report = buildCpYmsReport(analysis, {
      CP: {
        dataset: {
          dataset_id: 41,
          source_type: 'CP',
          storage_url: '/source.csv',
          summary: {
            data_type: 'CP', lot_id: 'LOT-41', wafer_id: 'W300-41', product_name: 'PROD-41', source_filename: 'source.csv', file_format: 'CSV', total_rows: 12, valid_rows: 12, error_rows: 0, parameter_names: ['VTH'], selected_parameter: 'VTH', stats: { gross_items: 12, pass_count: 10, fail_count: 2, yield_pct: 83.33, mean_val: 0.33, min_val: 0.28, max_val: 0.37, std_dev: 0.02, defect_count: 0, defect_density_per_cm2: 0, repeater_defect_count: 0 }, detected_columns: {}, sample_rows: [],
          },
        },
      },
    });

    expect(report.report_type).toBe('WAFERMAP.PRO_CP_YMS_SOURCE_BACKED_ANALYSIS');
    expect(report.active_sources).toEqual([expect.objectContaining({ dataset_id: 41, source_type: 'CP' })]);
    expect(report.data_governance.exclusions).toContain('No synthetic VEDA lot records');
    expect(report.analysis.cp.spatial.failure_components.cluster_count).toBe(1);
  });
});
