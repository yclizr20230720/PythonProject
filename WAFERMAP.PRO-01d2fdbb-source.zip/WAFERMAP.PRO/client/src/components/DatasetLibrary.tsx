import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Database, FileArchive, FolderOpen, Layers, Loader2, RefreshCw, Upload, X } from 'lucide-react';
import {
  CpDieRecord,
  IngestedDataType,
  IngestedWaferData,
  IngestionDatasetResult,
  IngestionDatasetSummary,
  KlaDefectItem,
  PersistedIngestionDataset,
  WatMeasurementItem,
} from '../types';
import { getIngestionPreset } from '../data/productPresets';

const SOURCE_STYLE: Record<IngestedDataType, { accent: string; label: string }> = {
  CP: { accent: '#00FF9C', label: 'CP wafer sort' },
  WAT: { accent: '#00E5FF', label: 'WAT metrology' },
  KLA: { accent: '#FF5A52', label: 'KLA defect inspection' },
};

interface OverlayPayload {
  dataset: {
    id: number;
    source_type: IngestedDataType;
    wafer_id: string;
    lot_id: string;
    product_id: string;
    summary: IngestionDatasetSummary;
  };
  records?: unknown[];
  columns?: string[];
  rows?: unknown[][];
}

interface DatasetLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenIngestion: () => void;
  onApply: (data: IngestedWaferData) => void;
}

function asSourceType(value: unknown): IngestedDataType | null {
  return value === 'CP' || value === 'WAT' || value === 'KLA' ? value : null;
}

function formatTimestamp(value: string | null): string {
  if (!value) return 'Timestamp unavailable';
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString();
}

function unpackRecords(payload: OverlayPayload): Record<string, unknown>[] {
  if (Array.isArray(payload.records)) return payload.records as Record<string, unknown>[];
  if (!Array.isArray(payload.columns) || !Array.isArray(payload.rows)) return [];
  return payload.rows.map(row => Object.fromEntries(payload.columns!.map((column, index) => [column, row[index]])));
}

export function DatasetLibrary({ isOpen, onClose, onOpenIngestion, onApply }: DatasetLibraryProps) {
  const [datasets, setDatasets] = useState<PersistedIngestionDataset[]>([]);
  const [loading, setLoading] = useState(false);
  const [openingId, setOpeningId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadDatasets = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/ingestion/recent?limit=24');
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.message || 'The persisted-dataset index is unavailable.');
      const normalized = Array.isArray(payload.datasets)
        ? payload.datasets
            .map((item: Record<string, unknown>) => {
              const sourceType = asSourceType(item.sourceType);
              if (!sourceType || !Number.isInteger(Number(item.id))) return null;
              return {
                id: Number(item.id),
                source_type: sourceType,
                wafer_id: String(item.waferId || 'UNSPECIFIED-WAFER'),
                lot_id: String(item.lotId || 'UNSPECIFIED-LOT'),
                product_id: String(item.productId || 'UNSPECIFIED-PRODUCT'),
                original_filename: String(item.originalFilename || 'source-file'),
                valid_rows: Number(item.validRows || 0),
                error_rows: Number(item.errorRows || 0),
                created_at: item.createdAt ? String(item.createdAt) : null,
              } satisfies PersistedIngestionDataset;
            })
            .filter((item: PersistedIngestionDataset | null): item is PersistedIngestionDataset => item !== null)
        : [];
      setDatasets(normalized);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to load persisted datasets.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) void loadDatasets();
  }, [isOpen, loadDatasets]);

  const grouped = useMemo(() => {
    return (Object.keys(SOURCE_STYLE) as IngestedDataType[]).map(sourceType => ({
      sourceType,
      datasets: datasets.filter(dataset => dataset.source_type === sourceType),
    }));
  }, [datasets]);

  const openDataset = async (selected: PersistedIngestionDataset) => {
    setOpeningId(selected.id);
    setError(null);
    try {
      const response = await fetch(`/api/ingestion/datasets/${selected.id}/overlay`);
      const payload = await response.json() as OverlayPayload & { message?: string };
      if (!response.ok) throw new Error(payload.message || 'The dataset overlay could not be reopened.');
      const sourceType = asSourceType(payload.dataset?.source_type);
      if (!sourceType) throw new Error('The persisted dataset has an unsupported source type.');
      const dataset: IngestionDatasetResult = {
        dataset_id: Number(payload.dataset.id),
        source_type: sourceType,
        storage_url: '',
        summary: payload.dataset.summary,
      };
      const records = unpackRecords(payload);
      const ingested: IngestedWaferData = {
        dataset,
        ...(sourceType === 'CP' ? { cpRecords: records as unknown as CpDieRecord[] } : {}),
        ...(sourceType === 'WAT' ? { watRecords: records as unknown as WatMeasurementItem[] } : {}),
        ...(sourceType === 'KLA' ? { klaRecords: records as unknown as KlaDefectItem[] } : {}),
      };
      onApply(ingested);
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to reopen this dataset.');
    } finally {
      setOpeningId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-label="Persisted wafer dataset library">
      <section className="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-[#252525] bg-[#0e0e0e] text-[#ddd] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#242424] bg-[#141414] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#00E5FF]/30 bg-[#00E5FF]/10 text-[#00E5FF]"><Database className="h-5 w-5" /></div>
            <div className="min-w-0">
              <h2 className="text-base font-bold tracking-wide text-white sm:text-lg">PERSISTED WAFER DATA LIBRARY</h2>
              <p className="mt-0.5 text-xs text-neutral-400">Reopen a validated CP, WAT, or KLA dataset from managed storage without uploading it again.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white" aria-label="Close persisted wafer dataset library"><X className="h-5 w-5" /></button>
        </header>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#242424] bg-[#111] px-5 py-3 sm:px-6">
          <div className="flex items-center gap-2 text-xs text-neutral-400"><Layers className="h-4 w-4 text-[#00FF9C]" />{datasets.length} recent dataset{datasets.length === 1 ? '' : 's'} available</div>
          <button type="button" onClick={() => void loadDatasets()} disabled={loading} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />Refresh index</button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {error && <div role="alert" className="mb-4 flex items-start gap-2 rounded-lg border border-red-800 bg-red-950/40 p-3 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}
          {loading && datasets.length === 0 ? (
            <div className="flex min-h-56 items-center justify-center gap-2 text-sm text-neutral-400"><Loader2 className="h-5 w-5 animate-spin text-[#00E5FF]" />Loading persisted datasets…</div>
          ) : datasets.length === 0 ? (
            <div className="flex min-h-56 flex-col items-center justify-center rounded-xl border border-dashed border-[#313131] bg-[#121212] p-8 text-center">
              <FolderOpen className="mb-3 h-8 w-8 text-neutral-600" />
              <h3 className="text-sm font-bold text-white">No persisted datasets found</h3>
              <p className="mt-1 max-w-md text-xs leading-relaxed text-neutral-400">Ingest a coordinate-aware CP, WAT, or KLA source file to build a retained dataset, audit record, and reusable wafer overlay.</p>
              <button type="button" onClick={onOpenIngestion} className="mt-4 flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Open ingestion studio</button>
            </div>
          ) : (
            <div className="space-y-5">
              {grouped.map(group => {
                const style = SOURCE_STYLE[group.sourceType];
                return <section key={group.sourceType} className="rounded-xl border border-[#242424] bg-[#121212] p-4">
                  <div className="mb-3 flex items-center justify-between"><h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: style.accent }} />{style.label}</h3><span className="font-mono text-[10px] text-neutral-500">{group.datasets.length} retained</span></div>
                  {group.datasets.length === 0 ? <p className="rounded-lg border border-dashed border-[#2a2a2a] p-3 text-xs text-neutral-500">No retained {group.sourceType} datasets in the recent index.</p> : <div className="grid gap-3 lg:grid-cols-2">
                    {group.datasets.map(dataset => <article key={dataset.id} className="rounded-lg border border-[#2c2c2c] bg-[#161616] p-3.5 transition-colors hover:border-neutral-500">
                      <div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="flex items-center gap-2"><FileArchive className="h-4 w-4 shrink-0" style={{ color: style.accent }} /><span className="truncate font-mono text-xs font-bold text-white" title={dataset.original_filename}>{dataset.original_filename}</span></div><p className="mt-1 font-mono text-[10px] text-neutral-500">Dataset #{dataset.id} · {formatTimestamp(dataset.created_at)}</p></div><button type="button" onClick={() => void openDataset(dataset)} disabled={openingId !== null} className="shrink-0 rounded border px-2.5 py-1.5 text-[11px] font-bold transition-colors disabled:cursor-wait disabled:opacity-60" style={{ borderColor: `${style.accent}88`, color: style.accent }}>{openingId === dataset.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Open overlay'}</button></div>
                      <div className="mt-3 grid grid-cols-3 gap-2 border-t border-[#282828] pt-3 font-mono text-[10px]"><div><span className="block text-neutral-500">Lot</span><strong className="block truncate text-neutral-200" title={dataset.lot_id}>{dataset.lot_id}</strong></div><div><span className="block text-neutral-500">Wafer</span><strong className="block truncate text-neutral-200" title={dataset.wafer_id}>{dataset.wafer_id}</strong></div><div><span className="block text-neutral-500">Validated rows</span><strong className="text-neutral-200">{dataset.valid_rows.toLocaleString()}</strong></div></div>
                    </article>)}
                  </div>}
                </section>;
              })}
            </div>
          )}
        </div>

        <footer className="flex items-center justify-between gap-3 border-t border-[#242424] bg-[#141414] px-5 py-4 sm:px-6"><span className="hidden items-center gap-2 text-[11px] text-neutral-500 sm:flex"><CheckCircle2 className="h-4 w-4 text-[#00FF9C]" />Managed source-file retention and import-run audit enabled</span><button type="button" onClick={onOpenIngestion} className="ml-auto flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c]"><Upload className="h-4 w-4" />Ingest new data</button></footer>
      </section>
    </div>
  );
}
