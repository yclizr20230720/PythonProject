import React from 'react';
import {
  Cpu,
  Layers,
  Sparkles,
  BarChart3,
  Download,
  RotateCcw,
  Zap,
  Grid,
  Eye,
  Activity,
  Upload,
  Search,
  Database,
} from 'lucide-react';
import { IngestedDataType, ViewDisplayMode, ColormapMode, WaferMetadata } from '../types';

interface HeaderProps {
  metadata: WaferMetadata;
  viewMode: ViewDisplayMode;
  setViewMode: (mode: ViewDisplayMode) => void;
  colormap: ColormapMode;
  setColormap: (map: ColormapMode) => void;
  onOpenOptimizer: () => void;
  onOpenAnalytics: () => void;
  onOpenExport: () => void;
  onOpenReticleStudio: () => void;
  onOpenIngestion: () => void;
  onOpenDataLibrary: () => void;
  onOpenCpAnalysis: () => void;
  onOpenDataCriteria: () => void;
  onResetView: () => void;
  isOptimizing?: boolean;
  onSaveSession: () => void;
  isSavingSession?: boolean;
  sessionStatus?: string | null;
  availableDataTypes?: IngestedDataType[];
  hasCpData?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  metadata,
  viewMode,
  setViewMode,
  colormap,
  setColormap,
  onOpenOptimizer,
  onOpenAnalytics,
  onOpenExport,
  onOpenReticleStudio,
  onOpenIngestion,
  onOpenDataLibrary,
  onOpenCpAnalysis,
  onOpenDataCriteria,
  onResetView,
  isOptimizing = false,
  onSaveSession,
  isSavingSession = false,
  sessionStatus,
  availableDataTypes = [],
  hasCpData = false,
}) => {
  return (
    <header
      id="main-app-header"
      className="bg-[#0C0C0C] border-b border-[#222] px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-30 select-none"
    >
      {/* Brand & Fab Title */}
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-sm bg-[#111] border border-[#222] flex items-center justify-center text-[#00FF9C] shadow-[0_0_12px_rgba(0,255,156,0.15)]">
          <Cpu className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-[#555] text-[9px] uppercase tracking-[0.3em] font-bold">
            Precision Metrology / SEMI M20
          </span>
          <div className="flex items-baseline gap-2.5">
            <h1 className="text-2xl font-extrabold tracking-tighter leading-none italic text-[#E5E5E5]">
              WAFERMAP<span className="text-[#00FF9C]">.PRO</span>
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#111] border border-[#222] text-[#00FF9C] tracking-tight">
              {metadata.diameter_mm}mm FAB
            </span>
          </div>
        </div>
      </div>

      {/* Real-time KPI Bar - Editorial Style */}
      <div className="hidden lg:flex items-center gap-6 bg-[#111] border border-[#222] px-4 py-2 rounded-sm text-xs font-mono">
        <div className="flex flex-col">
          <span className="text-[9px] text-[#555] uppercase tracking-[0.2em]">Gross Dies</span>
          <span className="font-bold text-[#E5E5E5] text-sm tracking-tight">
            {metadata.gross_die_count.toLocaleString()}
          </span>
        </div>
        <div className="w-px h-6 bg-[#222]" />
        <div className="flex flex-col">
          <span className="text-[9px] text-[#555] uppercase tracking-[0.2em]">Pass / Fail</span>
          <div className="font-bold text-sm tracking-tight">
            <span className="text-[#00FF9C]">{metadata.pass_die_count}</span>
            <span className="text-[#444]"> / </span>
            <span className="text-[#FF3E3E]">{metadata.fail_die_count}</span>
          </div>
        </div>
        <div className="w-px h-6 bg-[#222]" />
        <div className="flex flex-col">
          <span className="text-[9px] text-[#555] uppercase tracking-[0.2em]">Net Yield</span>
          <span
            className={`font-bold text-sm tracking-tight ${
              metadata.yield_pct >= 90
                ? 'text-[#00FF9C]'
                : metadata.yield_pct >= 75
                ? 'text-[#FFAE00]'
                : 'text-[#FF3E3E]'
            }`}
          >
            {metadata.yield_pct}%
          </span>
        </div>
        <div className="w-px h-6 bg-[#222]" />
        <div className="flex flex-col">
          <span className="text-[9px] text-[#555] uppercase tracking-[0.2em]">Reticle Grid</span>
          <span className="font-bold text-[#AAA] text-sm tracking-tight">
            {metadata.total_shots} <span className="text-[10px] text-[#555]">({metadata.reticle_cols}×{metadata.reticle_rows})</span>
          </span>
        </div>
      </div>

      {/* View Mode Switcher */}
      <div className="flex items-center gap-1 bg-[#080808] border border-[#222] p-1 rounded-sm">
        <button
          id="btn-view-bin"
          onClick={() => setViewMode('bin_category')}
          className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
            viewMode === 'bin_category'
              ? 'bg-[#E5E5E5] text-black font-bold shadow-sm'
              : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
          }`}
          title="Standard Bin Map (Pass / Fail Codes)"
        >
          <Grid className="w-3.5 h-3.5" />
          <span>Bin Map</span>
        </button>

        <button
          id="btn-view-heatmap"
          onClick={() => setViewMode('parametric_heatmap')}
          className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
            viewMode === 'parametric_heatmap'
              ? 'bg-[#E5E5E5] text-black font-bold shadow-sm'
              : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
          }`}
          title="Continuous Parametric & Yield Heatmap"
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Parametric</span>
        </button>

        {availableDataTypes.includes('WAT') && (
          <button
            id="btn-view-wat"
            onClick={() => setViewMode('wat_sites')}
            className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
              viewMode === 'wat_sites'
                ? 'bg-[#00E5FF] text-black font-bold shadow-sm'
                : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
            }`}
            title="WAT PCM metrology site overlay"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>WAT</span>
          </button>
        )}

        <button
          id="btn-view-shot"
          onClick={() => setViewMode('shot_yield')}
          className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
            viewMode === 'shot_yield'
              ? 'bg-[#E5E5E5] text-black font-bold shadow-sm'
              : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
          }`}
          title="Shot Field / Stepping Grid Yield"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Shot Grid</span>
        </button>

        <button
          id="btn-view-defect"
          onClick={() => setViewMode('defect_markers')}
          className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
            viewMode === 'defect_markers'
              ? 'bg-[#E5E5E5] text-black font-bold shadow-sm'
              : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
          }`}
          title="KLARF Defect Inspection Markers"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Defects</span>
        </button>
        {availableDataTypes.includes('KLA') && (
          <button
            id="btn-view-kla"
            onClick={() => setViewMode('kla_defects')}
            className={`px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded-xs transition-all flex items-center gap-1.5 ${
              viewMode === 'kla_defects'
                ? 'bg-[#FF5A52] text-black font-bold shadow-sm'
                : 'text-[#888] hover:text-[#E5E5E5] hover:bg-[#111]'
            }`}
            title="Imported KLA defect and reticle repeater overlay"
          >
            <Search className="w-3.5 h-3.5" />
            <span>KLA</span>
          </button>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2">
        <div className="hidden xl:flex flex-col items-end mr-1 max-w-36">
          <span className="text-[8px] uppercase tracking-[0.16em] text-[#555]">Persistence</span>
          <span className={`text-[9px] font-mono truncate max-w-36 ${sessionStatus?.includes('saved') ? 'text-[#00FF9C]' : 'text-[#888]'}`}>
            {sessionStatus || 'Unsaved workspace'}
          </span>
        </div>
        <button
          id="btn-save-session"
          onClick={onSaveSession}
          disabled={isSavingSession}
          className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] flex items-center gap-1.5 transition-colors disabled:opacity-50"
          title="Persist this wafer configuration and analysis session"
        >
          <Download className="w-3.5 h-3.5 text-[#00FF9C]" />
          <span>{isSavingSession ? 'Saving' : 'Save Session'}</span>
        </button>
        <button
          id="btn-open-ingestion"
          onClick={onOpenIngestion}
          className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00E5FF] hover:text-[#00E5FF] flex items-center gap-1.5 transition-colors"
          title="Upload CP, WAT, or KLA wafer data"
        >
          <Upload className="w-3.5 h-3.5 text-[#00E5FF]" />
          <span>Ingest Data</span>
        </button>
        <button
          id="btn-open-data-criteria"
          onClick={onOpenDataCriteria}
          className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#00E5FF]/10 hover:bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 hover:border-[#00E5FF] flex items-center gap-1.5 transition-colors"
          title="Filter retained CP, WAT, and KLA sources by stored dataset identity"
        >
          <Search className="w-3.5 h-3.5" />
          <span>Data Criteria</span>
        </button>
        <button
          id="btn-open-dataset-library"
          onClick={onOpenDataLibrary}
          className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00E5FF] hover:text-[#00E5FF] flex items-center gap-1.5 transition-colors"
          title="Reopen a retained CP, WAT, or KLA wafer dataset"
        >
          <Database className="w-3.5 h-3.5 text-[#00E5FF]" />
          <span>Data Library</span>
        </button>
        <button
          id="btn-open-cp-analysis"
          onClick={onOpenCpAnalysis}
          className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] flex items-center gap-1.5 transition-colors"
          title={hasCpData ? 'Analyze active CP, WAT, and KLA sources' : 'Open the CP and YMS studio to select retained CP data'}
        >
          <Activity className="w-3.5 h-3.5 text-[#00FF9C]" />
          <span>CP Analysis</span>
        </button>
        {/* Reticle Studio Drawer Toggle */}
        <button
          id="btn-open-reticle-studio"
          onClick={onOpenReticleStudio}
          className="px-3.5 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] flex items-center gap-1.5 transition-colors"
          title="Inspect & Design Reticle Shot Field"
        >
          <Cpu className="w-3.5 h-3.5 text-[#00FF9C]" />
          <span>Reticle Studio</span>
        </button>

        {/* Shot Optimizer */}
        <button
          id="btn-open-optimizer"
          onClick={onOpenOptimizer}
          disabled={isOptimizing}
          className="px-3.5 py-1.5 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#00FF9C] hover:bg-[#00e08a] text-black flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(0,255,156,0.25)] disabled:opacity-50"
          title="AI Stepping Center-Offset Optimizer to Maximize GDPW"
        >
          <Zap className="w-3.5 h-3.5 fill-current" />
          <span>Optimizer</span>
        </button>

        {/* Spatial Analytics */}
        <button
          id="btn-open-analytics"
          onClick={onOpenAnalytics}
          className="p-2 text-xs rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] transition-colors"
          title="Spatial Autocorrelation, Radial Zones & Moran's I"
        >
          <BarChart3 className="w-4 h-4" />
        </button>

        {/* Export SEMI / PNG */}
        <button
          id="btn-open-export"
          onClick={onOpenExport}
          className="p-2 text-xs rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] transition-colors"
          title="Export SEMI E142 XML, G85, KLARF, CSV, PNG"
        >
          <Download className="w-4 h-4" />
        </button>

        {/* Reset View */}
        <button
          id="btn-reset-view"
          onClick={onResetView}
          className="p-2 text-xs rounded-sm bg-[#111] hover:bg-[#1a1a1a] text-[#888] hover:text-[#E5E5E5] border border-[#222] transition-colors"
          title="Reset Zoom & Center Wafer Map"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
