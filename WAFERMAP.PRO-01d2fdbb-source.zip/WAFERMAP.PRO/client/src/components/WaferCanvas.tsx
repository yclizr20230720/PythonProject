import React, { useRef, useEffect, useLayoutEffect, useMemo, useState, useCallback } from 'react';
import {
  DieInstance,
  ShotInstance,
  WaferMetadata,
  ViewDisplayMode,
  ColormapMode,
  CpDieRecord,
  KlaDefectItem,
  WatMeasurementItem,
} from '../types';
import {
  BIN_COLORS,
  DIE_TYPE_COLORS,
  getColormapColor,
} from '../utils/waferGeometry';
import { fitWaferToViewport, panFromLocalPointer, safeViewport, screenToWaferMm } from '../utils/canvasViewport';
import { ZoomIn, ZoomOut, Maximize2, Crosshair, MapPin } from 'lucide-react';

interface WaferCanvasProps {
  metadata: WaferMetadata;
  dies: DieInstance[];
  shots: ShotInstance[];
  viewMode: ViewDisplayMode;
  colormap: ColormapMode;
  selectedDie: DieInstance | null;
  onSelectDie: (die: DieInstance | null) => void;
  selectedShot: ShotInstance | null;
  onSelectShot: (shot: ShotInstance | null) => void;
  highlightedReticleCell: { row: number; col: number } | null;
  resetViewTrigger: number;
  cpRecords?: CpDieRecord[];
  watRecords?: WatMeasurementItem[];
  klaRecords?: KlaDefectItem[];
  selectedCpBin?: number | null;
}

export const WaferCanvas: React.FC<WaferCanvasProps> = ({
  metadata,
  dies,
  shots,
  viewMode,
  colormap,
  selectedDie,
  onSelectDie,
  selectedShot,
  onSelectShot,
  highlightedReticleCell,
  resetViewTrigger,
  cpRecords = [],
  watRecords = [],
  klaRecords = [],
  selectedCpBin = null,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Viewport Transform State (Scale and Pan in Pixels)
  const [scale, setScale] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [viewport, setViewport] = useState<{ width: number; height: number }>({ width: 0, height: 0 });
  const didInitialFitRef = useRef(false);
  const dragRef = useRef<{ pointerId: number; offsetX: number; offsetY: number } | null>(null);
  const didDragRef = useRef(false);

  // Hover state
  const [hoveredDie, setHoveredDie] = useState<DieInstance | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [mouseMm, setMouseMm] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const cpByDie = useMemo(() => new Map(cpRecords.map(record => [`${record.die_x}:${record.die_y}`, record])), [cpRecords]);
  const shotsByCoordinate = useMemo(() => new Map(shots.map(shot => [`${shot.shot_row}:${shot.shot_col}`, shot])), [shots]);

  const readViewport = useCallback(() => {
    const element = containerRef.current;
    if (!element) return null;
    const rect = element.getBoundingClientRect();
    return safeViewport(rect.width, rect.height);
  }, []);

  const fitViewport = useCallback((nextViewport: { width: number; height: number }) => {
    const transform = fitWaferToViewport(nextViewport, metadata.diameter_mm);
    setScale(transform.scale);
    setPan(transform.pan);
  }, [metadata.diameter_mm]);

  // Wait for a non-zero flex layout before fitting. ResizeObserver also corrects wide-screen reflows.
  useLayoutEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    let frame = 0;
    const measure = () => {
      const nextViewport = readViewport();
      if (!nextViewport) return;
      setViewport(current => current.width === nextViewport.width && current.height === nextViewport.height ? current : nextViewport);
      if (!didInitialFitRef.current) {
        fitViewport(nextViewport);
        didInitialFitRef.current = true;
      }
    };
    const scheduleMeasure = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(measure);
    };
    const observer = new ResizeObserver(scheduleMeasure);
    observer.observe(element);
    scheduleMeasure();
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(frame);
    };
  }, [fitViewport, readViewport]);

  const handleResetView = useCallback(() => {
    const nextViewport = readViewport();
    if (!nextViewport) {
      didInitialFitRef.current = false;
      return;
    }
    fitViewport(nextViewport);
    didInitialFitRef.current = true;
  }, [fitViewport, readViewport]);

  useEffect(() => {
    didInitialFitRef.current = false;
    handleResetView();
  }, [handleResetView, resetViewTrigger]);

  // Convert Screen Pixel to Wafer MM Coordinates
  const screenToMm = useCallback(
    (screenX: number, screenY: number) => {
      return screenToWaferMm({ x: screenX, y: screenY }, pan, scale);
    },
    [pan, scale]
  );

  // Main Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !containerRef.current) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = viewport;
    if (width < 1 || height < 1) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    ctx.save();
    ctx.scale(dpr, dpr);

    // 1. Dark Background with subtle editorial grid
    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, width, height);

    // Draw Subtle Grid
    ctx.strokeStyle = '#141414';
    ctx.lineWidth = 1;
    const renderScale = Number.isFinite(scale) && scale > 0 ? scale : 1;
    const renderPan = {
      x: Number.isFinite(pan.x) ? pan.x : width / 2,
      y: Number.isFinite(pan.y) ? pan.y : height / 2,
    };
    const gridSize = Math.max(16, 40 * (renderScale / 2.2));
    const offsetX = renderPan.x % gridSize;
    const offsetY = renderPan.y % gridSize;

    ctx.beginPath();
    for (let x = offsetX; x < width; x += gridSize) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }
    for (let y = offsetY; y < height; y += gridSize) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();

    // 2. Coordinate Axes (0,0) center lines
    ctx.strokeStyle = 'rgba(0, 255, 156, 0.25)';
    ctx.lineWidth = 1.2;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(renderPan.x, 0);
    ctx.lineTo(renderPan.x, height);
    ctx.moveTo(0, renderPan.y);
    ctx.lineTo(width, renderPan.y);
    ctx.stroke();
    ctx.setLineDash([]);

    // Transform to Wafer Coordinate System (origin at center)
    ctx.save();
    ctx.translate(renderPan.x, renderPan.y);

    const rWaferMm = (Number.isFinite(metadata.diameter_mm) && metadata.diameter_mm > 0 ? metadata.diameter_mm : 300) / 2.0;
    const edgeExclusionMm = Number.isFinite(metadata.edge_exclusion_mm) ? Math.max(0, metadata.edge_exclusion_mm) : 0;
    const rWaferPx = rWaferMm * renderScale;
    const rUsableMm = Math.max(0, rWaferMm - edgeExclusionMm);
    const rUsablePx = rUsableMm * renderScale;

    // 3. Silicon Wafer Outer Circle & Notch
    ctx.save();
    // Silicon substrate gradient fill
    const waferGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, rWaferPx);
    waferGrad.addColorStop(0, '#151515');
    waferGrad.addColorStop(0.85, '#0F0F0F');
    waferGrad.addColorStop(1, '#0A0A0A');

    ctx.fillStyle = waferGrad;
    ctx.beginPath();
    ctx.arc(0, 0, rWaferPx, 0, Math.PI * 2);
    ctx.fill();

    // Metallic Wafer Outer Bevel
    ctx.strokeStyle = '#2A2A2A';
    ctx.lineWidth = 2.0;
    ctx.stroke();

    // Notch Rendering (Standard SEMI Notch)
    const notchAngleRad = ((metadata.notch_angle_deg || 270) * Math.PI) / 180;
    const notchDepthPx = 3.5 * renderScale;
    // Notch center on wafer perimeter
    const notchPxX = Math.cos(notchAngleRad) * rWaferPx;
    const notchPxY = -Math.sin(notchAngleRad) * rWaferPx;

    ctx.fillStyle = '#080808'; // background color cutout
    ctx.beginPath();
    ctx.arc(notchPxX, notchPxY, notchDepthPx * 1.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#00FF9C';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Notch indicator label
    ctx.fillStyle = '#00FF9C';
    ctx.font = '10px "Fira Code", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const labelDist = rWaferPx + 16;
    ctx.fillText(
      `NOTCH ${metadata.notch_angle_deg}°`,
      Math.cos(notchAngleRad) * labelDist,
      -Math.sin(notchAngleRad) * labelDist
    );

    // 4. Edge Exclusion Boundary (Dashed Ring)
    ctx.strokeStyle = 'rgba(255, 174, 0, 0.6)';
    ctx.lineWidth = 1.2;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(0, 0, rUsablePx, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Edge exclusion tag
    ctx.fillStyle = 'rgba(255, 174, 0, 0.8)';
    ctx.font = '9px "Fira Code", monospace';
    ctx.fillText(
      `EXCLUSION ${edgeExclusionMm}MM`,
      0,
      -rUsablePx + 12
    );

    // 5. Draw Individual Dies
    const dieWMm = dies[0]?.width_mm || 8.5;
    const dieHMm = dies[0]?.height_mm || 10.2;
    const dieWPx = dieWMm * renderScale;
    const dieHPx = dieHMm * renderScale;

    const isNearZoom = renderScale > 5.5;
    const isMediumZoom = renderScale > 3.0;

    for (const d of dies) {
      if (d.status === 'OUTSIDE') continue;

      const pxX = d.center_x_mm * renderScale - dieWPx / 2;
      // Invert Y for physical coordinates
      const pxY = -d.center_y_mm * renderScale - dieHPx / 2;

      // Determine Die Color based on View Mode
      let fillColor = '#141414';
      let strokeColor = '#222222';
      const cpRecord = cpByDie.get(`${d.global_x}:${d.global_y}`);
      const isSelectedCpBin = viewMode === 'bin_category' && selectedCpBin !== null && cpRecord?.bin_code === selectedCpBin;
      const isDimmedByCpBin = viewMode === 'bin_category' && selectedCpBin !== null && !isSelectedCpBin;

      if (viewMode === 'bin_category') {
        const binInfo = BIN_COLORS[cpRecord?.bin_code ?? d.bin_code] || BIN_COLORS[1];
        fillColor = binInfo.bg;
        strokeColor = binInfo.border;
      } else if (viewMode === 'parametric_heatmap') {
        if (!d.is_yieldable) {
          fillColor = '#141414';
        } else {
          fillColor = getColormapColor(d.parametric_val, 50, 100, colormap);
        }
      } else if (viewMode === 'shot_yield') {
        // Color based on parent shot yield
        const parentShot = shotsByCoordinate.get(`${d.shot_row}:${d.shot_col}`);
        const shotYield = parentShot ? parentShot.yield_pct : 90;
        fillColor = getColormapColor(shotYield, 50, 100, 'turbo');
      } else if (viewMode === 'defect_markers') {
        if (d.defect_count > 0) {
          fillColor = '#FF3E3E';
        } else if (d.bin_quality === 'PASS') {
          fillColor = '#00663E';
        } else {
          fillColor = '#222222';
        }
      } else if (viewMode === 'die_types') {
        const typeInfo = DIE_TYPE_COLORS[d.die_type] || DIE_TYPE_COLORS.PRODUCT_DIE;
        fillColor = typeInfo.bg;
        strokeColor = typeInfo.border;
      } else if (viewMode === 'wat_sites') {
        fillColor = '#123a3a';
        strokeColor = '#205055';
      } else if (viewMode === 'kla_defects') {
        fillColor = '#221717';
        strokeColor = '#3b2525';
      }

      // Check if this die is part of the highlighted reticle cell
      const isReticleHighlighted =
        highlightedReticleCell &&
        d.reticle_row === highlightedReticleCell.row &&
        d.reticle_col === highlightedReticleCell.col;

      const isSelected = selectedDie?.die_uid === d.die_uid;
      const isHovered = hoveredDie?.die_uid === d.die_uid;

      // Render Die Cell
      ctx.globalAlpha = isDimmedByCpBin ? 0.16 : 1;
      ctx.fillStyle = fillColor;
      ctx.fillRect(pxX, pxY, dieWPx, dieHPx);

      // Border handling for performance
      if (isMediumZoom || isSelected || isHovered || isReticleHighlighted || isSelectedCpBin) {
        if (isSelectedCpBin) {
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 1.25;
        } else if (isSelected) {
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 2.0;
        } else if (isHovered) {
          ctx.strokeStyle = '#00FF9C';
          ctx.lineWidth = 1.8;
        } else if (isReticleHighlighted) {
          ctx.strokeStyle = '#FFAE00';
          ctx.lineWidth = 1.8;
        } else {
          ctx.strokeStyle = strokeColor;
          ctx.lineWidth = 0.5;
        }
        ctx.strokeRect(pxX, pxY, dieWPx, dieHPx);
      }

      // High Zoom Detailed Text
      if (isNearZoom) {
        ctx.fillStyle = '#E5E5E5';
        ctx.font = `${Math.max(8, Math.floor(dieHPx * 0.22))}px "Fira Code", monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`${d.global_x},${d.global_y}`, pxX + dieWPx / 2, pxY + dieHPx * 0.35);

        ctx.fillStyle = d.bin_quality === 'PASS' ? '#00FF9C' : '#FF3E3E';
        ctx.font = `${Math.max(7, Math.floor(dieHPx * 0.18))}px "Fira Code", monospace`;
        ctx.fillText(`R${d.reticle_row},${d.reticle_col}`, pxX + dieWPx / 2, pxY + dieHPx * 0.68);
      }
      ctx.globalAlpha = 1;
    }

    // 6. Draw Stepping Shot Field Boundaries
    const reticleWMm = metadata.reticle_field_w_mm || 25.5;
    const reticleHMm = metadata.reticle_field_h_mm || 20.4;
    const reticleWPx = reticleWMm * renderScale;
    const reticleHPx = reticleHMm * renderScale;

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1.0;

    for (const s of shots) {
      const sPxX = s.center_x_mm * renderScale - reticleWPx / 2;
      const sPxY = -s.center_y_mm * renderScale - reticleHPx / 2;

      const isShotSelected = selectedShot?.shot_id === s.shot_id;

      if (isShotSelected) {
        ctx.strokeStyle = '#00FF9C';
        ctx.lineWidth = 2.0;
        ctx.strokeRect(sPxX, sPxY, reticleWPx, reticleHPx);
      } else {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 0.8;
        ctx.strokeRect(sPxX, sPxY, reticleWPx, reticleHPx);
      }

      // Shot label at appropriate zoom
      if (renderScale > 2.0 && renderScale <= 5.5) {
        ctx.fillStyle = '#666666';
        ctx.font = '8px "Fira Code", monospace';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillText(s.shot_id, sPxX + 2, sPxY + 2);
      }
    }

    if (viewMode === 'wat_sites') {
      for (const site of watRecords) {
        const x = site.x_mm * renderScale;
        const y = -site.y_mm * renderScale;
        ctx.beginPath();
        ctx.arc(x, y, Math.max(3, Math.min(8, 3.8 + Math.abs(site.value) * 0.25)), 0, Math.PI * 2);
        ctx.fillStyle = site.status === 'PASS' ? '#00E5FF' : site.status === 'WARN' ? '#FFAE00' : '#FF5A52';
        ctx.fill();
        ctx.strokeStyle = '#0A0A0A';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
    }

    if (viewMode === 'kla_defects' || (viewMode === 'defect_markers' && klaRecords.length > 0)) {
      for (const defect of klaRecords) {
        const x = defect.x_mm * renderScale;
        const y = -defect.y_mm * renderScale;
        const radius = Math.max(2.5, Math.min(8, 2 + Math.sqrt(defect.size_um || 0.1)));
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = defect.is_repeater ? '#FFAE00' : '#FF3E3E';
        ctx.fill();
        if (defect.is_repeater) {
          ctx.strokeStyle = '#FFF1C4';
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
      }
    }

    ctx.restore(); // Restore Wafer Center Transform
    ctx.restore(); // Restore Canvas DPR
  }, [
    metadata,
    dies,
    shots,
    viewMode,
    colormap,
    scale,
    pan,
    viewport,
    selectedDie,
    selectedShot,
    hoveredDie,
    highlightedReticleCell,
    cpByDie,
    selectedCpBin,
    shotsByCoordinate,
    watRecords,
    klaRecords,
  ]);

  const getLocalPoint = (e: React.PointerEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    return rect ? { x: e.clientX - rect.left, y: e.clientY - rect.top } : null;
  };

  // Pointer events retain mouse, trackpad, pen, and touch drag support with local canvas coordinates.
  const handlePointerDown = (e: React.PointerEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('button, input, select, textarea, [data-canvas-control]')) {
      return;
    }
    if (e.button === 0 || e.button === 1) {
      const point = getLocalPoint(e);
      if (!point) return;
      e.currentTarget.setPointerCapture(e.pointerId);
      dragRef.current = { pointerId: e.pointerId, offsetX: point.x - pan.x, offsetY: point.y - pan.y };
      didDragRef.current = false;
      setIsDragging(true);
      e.preventDefault();
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const point = getLocalPoint(e);
    if (!point) return;
    const screenX = point.x;
    const screenY = point.y;

    setMousePos({ x: screenX, y: screenY });

    const drag = dragRef.current;
    if (drag?.pointerId === e.pointerId) {
      if (Math.abs(screenX - (pan.x + drag.offsetX)) > 2 || Math.abs(screenY - (pan.y + drag.offsetY)) > 2) {
        didDragRef.current = true;
      }
      setPan(panFromLocalPointer({ x: screenX, y: screenY }, { x: drag.offsetX, y: drag.offsetY }));
      return;
    }

    // Convert mouse to wafer coordinates in mm
    const mm = screenToMm(screenX, screenY);
    setMouseMm({ x: +mm.x.toFixed(3), y: +mm.y.toFixed(3) });

    // Hit test dies
    const dieWMm = dies[0]?.width_mm || 8.5;
    const dieHMm = dies[0]?.height_mm || 10.2;
    const halfW = dieWMm / 2;
    const halfH = dieHMm / 2;

    const hit = dies.find(
      (d) =>
        d.status !== 'OUTSIDE' &&
        Math.abs(d.center_x_mm - mm.x) <= halfW &&
        Math.abs(d.center_y_mm - mm.y) <= halfH
    );

    setHoveredDie(hit || null);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (dragRef.current?.pointerId === e.pointerId && e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    dragRef.current = null;
    setIsDragging(false);
  };

  const handleClick = () => {
    if (didDragRef.current) {
      didDragRef.current = false;
      return;
    }
    if (hoveredDie) {
      onSelectDie(hoveredDie);
      // Select parent shot as well
      const parentShot = shots.find(
        (s) => s.shot_row === hoveredDie.shot_row && s.shot_col === hoveredDie.shot_col
      );
      onSelectShot(parentShot || null);
    } else {
      onSelectDie(null);
      onSelectShot(null);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const mouseScreenX = e.clientX - rect.left;
    const mouseScreenY = e.clientY - rect.top;

    const safeScale = Number.isFinite(scale) && scale > 0 ? scale : 1;
    const safePan = { x: Number.isFinite(pan.x) ? pan.x : mouseScreenX, y: Number.isFinite(pan.y) ? pan.y : mouseScreenY };
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    const newScale = Math.max(0.6, Math.min(25.0, safeScale * zoomFactor));

    // Zoom centered on cursor
    const newPanX = mouseScreenX - (mouseScreenX - safePan.x) * (newScale / safeScale);
    const newPanY = mouseScreenY - (mouseScreenY - safePan.y) * (newScale / safeScale);

    setScale(newScale);
    setPan({ x: newPanX, y: newPanY });
  };

  return (
    <div
      id="wafer-canvas-container"
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onPointerLeave={() => {
        if (!dragRef.current) {
          setIsDragging(false);
        }
        setHoveredDie(null);
      }}
      onClick={handleClick}
      onWheel={handleWheel}
      data-canvas-width={viewport.width}
      data-canvas-height={viewport.height}
      data-canvas-scale={scale}
      data-canvas-pan-x={pan.x}
      data-canvas-pan-y={pan.y}
      className={`relative w-full h-full min-w-0 min-h-0 select-none touch-none overflow-hidden bg-slate-950 ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
    >
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* On-Canvas Mini Overlay Controls */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        <div className="bg-[#0C0C0C] border border-[#222] p-1 rounded-sm shadow-xl flex flex-col gap-1">
          <button
            id="btn-zoom-in"
            onClick={(e) => {
              e.stopPropagation();
              setScale((s) => Math.min(25.0, s * 1.25));
            }}
            className="p-1.5 hover:bg-[#1A1A1A] text-[#888] hover:text-[#00FF9C] rounded-xs transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            id="btn-zoom-out"
            onClick={(e) => {
              e.stopPropagation();
              setScale((s) => Math.max(0.6, s * 0.8));
            }}
            className="p-1.5 hover:bg-[#1A1A1A] text-[#888] hover:text-[#00FF9C] rounded-xs transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            id="btn-zoom-fit"
            onClick={(e) => {
              e.stopPropagation();
              handleResetView();
            }}
            className="p-1.5 hover:bg-[#1A1A1A] text-[#888] hover:text-[#00FF9C] rounded-xs transition-colors"
            title="Fit Wafer to Screen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Coordinate & Zoom Readout Bar */}
      <div className="absolute bottom-4 left-4 bg-[#0C0C0C] border border-[#222] px-3.5 py-2 rounded-sm shadow-2xl text-xs font-mono text-[#E5E5E5] flex items-center gap-4 z-10">
        <div className="flex items-center gap-2 text-[#00FF9C]">
          <Crosshair className="w-3.5 h-3.5" />
          <span>
            X: <strong className="text-[#E5E5E5] font-bold">{Number.isFinite(mouseMm.x) && mouseMm.x > 0 ? `+${mouseMm.x}` : Number.isFinite(mouseMm.x) ? mouseMm.x : 0}</strong> mm
          </span>
          <span>
            Y: <strong className="text-[#E5E5E5] font-bold">{Number.isFinite(mouseMm.y) && mouseMm.y > 0 ? `+${mouseMm.y}` : Number.isFinite(mouseMm.y) ? mouseMm.y : 0}</strong> mm
          </span>
        </div>
        <div className="w-px h-3.5 bg-[#222]" />
        <div>
          Zoom: <strong className="text-[#E5E5E5]">{(scale / 2.2).toFixed(1)}x</strong>
        </div>
        <div className="w-px h-3.5 bg-[#222]" />
        <div>
          Radius:{' '}
          <strong className="text-[#FFAE00]">
            {(Number.isFinite(mouseMm.x) && Number.isFinite(mouseMm.y) ? Math.sqrt(mouseMm.x ** 2 + mouseMm.y ** 2) : 0).toFixed(1)} mm
          </strong>
        </div>
      </div>

      {/* Real-time Hover Tooltip Card */}
      {hoveredDie && (
        <div
          id="die-hover-tooltip"
          className="absolute pointer-events-none bg-[#0C0C0C] border border-[#222] rounded-sm p-3.5 shadow-2xl z-20 text-xs font-mono text-[#E5E5E5] min-w-[240px]"
          style={{
            left: `${Math.max(8, Math.min(viewport.width - 260, mousePos.x + 18))}px`,
            top: `${Math.max(8, Math.min(viewport.height - 220, mousePos.y + 18))}px`,
          }}
        >
          <div className="flex items-center justify-between border-b border-[#222] pb-2 mb-2.5">
            <span className="font-bold text-[#00FF9C] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              Die ({hoveredDie.global_x}, {hoveredDie.global_y})
            </span>
            <span
              className={`px-2 py-0.5 rounded-xs text-[10px] font-bold uppercase tracking-wider ${
                hoveredDie.bin_quality === 'PASS'
                  ? 'bg-[#00331f] text-[#00FF9C] border border-[#00FF9C]/40'
                  : hoveredDie.bin_quality === 'FAIL'
                  ? 'bg-[#330c0c] text-[#FF3E3E] border border-[#FF3E3E]/40'
                  : 'bg-[#111] text-[#888] border border-[#222]'
              }`}
            >
              {hoveredDie.bin_name}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px]">
            <div>
              <span className="text-[#666]">Shot ID:</span>{' '}
              <strong className="text-[#E5E5E5]">
                S({hoveredDie.shot_row >= 0 ? `+${hoveredDie.shot_row}` : hoveredDie.shot_row},
                {hoveredDie.shot_col >= 0 ? `+${hoveredDie.shot_col}` : hoveredDie.shot_col})
              </strong>
            </div>
            <div>
              <span className="text-[#666]">Reticle Cell:</span>{' '}
              <strong className="text-[#E5E5E5]">
                ({hoveredDie.reticle_row},{hoveredDie.reticle_col})
              </strong>
            </div>
            <div>
              <span className="text-[#666]">Center:</span>{' '}
              <span className="text-[#AAA]">
                {hoveredDie.center_x_mm},{hoveredDie.center_y_mm}
              </span>
            </div>
            <div>
              <span className="text-[#666]">Radius:</span>{' '}
              <span className="text-[#AAA]">{hoveredDie.radial_dist_mm} mm</span>
            </div>
            <div>
              <span className="text-[#666]">Parametric:</span>{' '}
              <strong className="text-[#00FF9C]">{hoveredDie.parametric_val}</strong>
            </div>
            <div>
              <span className="text-[#666]">Clock Freq:</span>{' '}
              <span className="text-[#AAA]">{hoveredDie.test_freq_ghz} GHz</span>
            </div>
            <div>
              <span className="text-[#666]">Leakage:</span>{' '}
              <span className="text-[#AAA]">{hoveredDie.leakage_ua} µA</span>
            </div>
            <div>
              <span className="text-[#666]">Defects:</span>{' '}
              <strong className={hoveredDie.defect_count > 0 ? 'text-[#FF3E3E]' : 'text-[#888]'}>
                {hoveredDie.defect_count}
              </strong>
            </div>
          </div>
          <div className="mt-2.5 text-[10px] text-[#555] border-t border-[#222] pt-1.5 text-center uppercase tracking-widest">
            Click die to inspect diagnostics
          </div>
        </div>
      )}
    </div>
  );
};
