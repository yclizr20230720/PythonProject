import React, { useRef, useState } from 'react';
import { AlertTriangle, Check, CheckCircle2, ChevronRight, Cpu, Database, Download, FileSpreadsheet, FlaskConical, Loader2, Microscope, Search, Upload, X } from 'lucide-react';
import { IngestedDataType, IngestedWaferData, IngestionDatasetResult, KlaDefectItem, CpDieRecord, WatMeasurementItem } from '../types';
import { getIngestionPreset, INGESTION_PRODUCT_PRESETS, IngestionProductPreset } from '../data/productPresets';

const MOCK_FILES: Record<IngestedDataType, { url: string; fileName: string; label: string }> = {
  CP: { url: '/manus-storage/CP_WaferSort_HD100K_f1d611cb.csv', fileName: 'CP_WaferSort_HD100K.csv', label: 'CP Wafer Sort · 100k Dies' },
  WAT: { url: '/manus-storage/WAT_PCM_Metrology_81Sites_97da6b4c.csv', fileName: 'WAT_PCM_Metrology_81Sites.csv', label: 'WAT PCM Metrology · 81 Sites' },
  KLA: { url: '/manus-storage/KLA_DefectInspection_KLARF_b6ad9aa1.csv', fileName: 'KLA_DefectInspection_KLARF.csv', label: 'KLA Defect Inspection · KLARF' },
};

const CATEGORY_META: Record<IngestedDataType, { title: string; detail: string; accent: string; icon: typeof Cpu }> = {
  CP: { title: 'CP Wafer Sort', detail: 'Die bins, functional result, Vth, frequency and leakage by die coordinate.', accent: '#00FF9C', icon: Cpu },
  WAT: { title: 'WAT Metrology', detail: 'PCM site parameters, specification limits, status and radial process variation.', accent: '#00E5FF', icon: Microscope },
  KLA: { title: 'KLA Defect Inspection', detail: 'KLARF-compatible defect coordinates, classes, clusters and reticle repeaters.', accent: '#FF5A52', icon: Search },
};

interface DataIngestionStudioProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (data: IngestedWaferData, preset: IngestionProductPreset) => void;
}

export function DataIngestionStudio({ isOpen, onClose, onApply }: DataIngestionStudioProps) {
  const [category, setCategory] = useState<IngestedDataType>('CP');
  const [presetId, setPresetId] = useState('HD-MICRO-100K');
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<IngestedWaferData | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  if (!isOpen) return null;

  const preset = getIngestionPreset(presetId);
  const meta = CATEGORY_META[category];
  const CategoryIcon = meta.icon;

  const resetForCategory = (next: IngestedDataType) => {
    setCategory(next);
    setPending(null);
    setError(null);
  };

  const uploadFile = async (file: File) => {
    if (!/\.(csv|xlsx)$/i.test(file.name)) {
      setError('Upload a CSV or XLSX file. Legacy XLS is intentionally not accepted by the production parser.');
      return;
    }
    if (file.size === 0 || file.size > 20 * 1024 * 1024) {
      setError('File size must be between 1 byte and 20 MB.');
      return;
    }
    setUploading(true);
    setError(null);
    setPending(null);
    try {
      const form = new FormData();
      form.append('source_type', category);
      form.append('product_id', preset.id);
      form.append('file', file);
      const response = await fetch('/api/ingestion/upload', { method: 'POST', body: form });
      const body = await response.json();
      if (!response.ok) throw new Error(body.message || 'The ingestion service rejected this file.');
      const dataset = body.dataset as IngestionDatasetResult;
      const overlayResponse = await fetch(`/api/ingestion/datasets/${dataset.dataset_id}/overlay`);
      const overlay = await overlayResponse.json();
      if (!overlayResponse.ok) throw new Error(overlay.message || 'The source file was saved, but its wafer overlay is unavailable.');
      const records = Array.isArray(overlay.records)
        ? overlay.records
        : Array.isArray(overlay.rows) && Array.isArray(overlay.columns)
        ? overlay.rows.map((row: unknown[]) => Object.fromEntries(overlay.columns.map((column: string, index: number) => [column, row[index]])))
        : [];
      const data: IngestedWaferData = {
        dataset,
        ...(category === 'CP' ? { cpRecords: records as CpDieRecord[] } : {}),
        ...(category === 'WAT' ? { watRecords: records as WatMeasurementItem[] } : {}),
        ...(category === 'KLA' ? { klaRecords: records as KlaDefectItem[] } : {}),
      };
      setPending(data);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The ingestion operation failed.');
    } finally {
      setUploading(false);
    }
  };

  const loadMock = async () => {
    setUploading(true);
    setError(null);
    try {
      const mock = MOCK_FILES[category];
      const response = await fetch(mock.url);
      if (!response.ok) throw new Error('The managed mock file could not be loaded.');
      const blob = await response.blob();
      await uploadFile(new File([blob], mock.fileName, { type: 'text/csv' }));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The managed mock file could not be loaded.');
      setUploading(false);
    }
  };

  const handleApply = () => {
    if (!pending) return;
    onApply(pending, preset);
    onClose();
  };

  const summary = pending?.dataset.summary;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6" role="dialog" aria-modal="true" aria-label="Fab metrology and defect ingestion studio">
      <section className="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-[#252525] bg-[#0e0e0e] text-[#ddd] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#242424] bg-[#141414] px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#00FF9C]/30 bg-[#00FF9C]/10 text-[#00FF9C]"><Upload className="h-5 w-5" /></div>
            <div className="min-w-0">
              <h2 className="flex flex-wrap items-center gap-2 text-base font-bold tracking-wide text-white sm:text-lg">FAB METROLOGY &amp; DEFECT INGESTION STUDIO <span className="rounded border border-[#00FF9C]/35 bg-[#00FF9C]/15 px-2 py-0.5 font-mono text-[10px] uppercase text-[#00FF9C]">CP · WAT · KLA</span></h2>
              <p className="mt-0.5 text-xs text-neutral-400">Upload coordinate-aware source files, validate their schema, then generate a product-specific wafer overlay.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white" aria-label="Close data ingestion studio"><X className="h-5 w-5" /></button>
        </header>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#242424] bg-[#111] px-5 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-2 overflow-x-auto">
            <span className="shrink-0 font-mono text-[10px] uppercase text-neutral-500">Analysis perspective:</span>
            <div className="flex rounded-lg border border-[#292929] bg-black/60 p-1">
              {(Object.keys(CATEGORY_META) as IngestedDataType[]).map(type => {
                const entry = CATEGORY_META[type];
                const Icon = entry.icon;
                const active = category === type;
                return <button key={type} type="button" onClick={() => resetForCategory(type)} className={`flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs transition-colors ${active ? 'font-bold text-black' : 'text-neutral-300 hover:bg-neutral-800 hover:text-white'}`} style={active ? { backgroundColor: entry.accent } : undefined}><Icon className="h-3.5 w-3.5" />{entry.title}</button>;
              })}
            </div>
          </div>
          <a href={MOCK_FILES[category].url} download={MOCK_FILES[category].fileName} className="flex items-center gap-1.5 rounded border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white"><Download className="h-3.5 w-3.5" />Download {category} Mock (CSV)</a>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto p-5 sm:p-6">
          <div className="rounded-xl border border-[#242424] bg-[#121212] p-4">
            <div className="mb-3 flex items-center justify-between gap-3"><div className="flex items-center gap-2"><FlaskConical className="h-4 w-4 text-[#00FF9C]" /><h3 className="text-xs font-bold uppercase tracking-wider text-white">Semiconductor domain analysis perspectives</h3></div><span className="hidden text-[11px] text-neutral-500 sm:block">300 mm wafer metrology and defect correlation</span></div>
            <div className="grid gap-3 md:grid-cols-3">
              {(Object.keys(CATEGORY_META) as IngestedDataType[]).map(type => {
                const entry = CATEGORY_META[type];
                const Icon = entry.icon;
                const active = category === type;
                return <button key={type} type="button" onClick={() => resetForCategory(type)} className={`rounded-lg border p-3.5 text-left transition-colors ${active ? 'bg-white/[0.04]' : 'border-[#292929] bg-[#161616] hover:border-neutral-600'}`} style={active ? { borderColor: entry.accent, boxShadow: `inset 0 0 0 1px ${entry.accent}44` } : undefined}><div className="mb-2 flex items-center gap-2"><Icon className="h-4 w-4" style={{ color: entry.accent }} /><span className="text-xs font-bold text-white">{entry.title}</span></div><p className="text-[11px] leading-relaxed text-neutral-400">{entry.detail}</p></button>;
              })}
            </div>
          </div>

          <div className="rounded-xl border border-[#242424] bg-[#121212] p-4"><div className="mb-3 flex items-center justify-between gap-3"><div className="flex items-center gap-2"><Database className="h-4 w-4 text-[#00FF9C]" /><h3 className="text-xs font-bold uppercase tracking-wider text-white">Target product &amp; reticle stepping matrix</h3></div><span className="hidden font-mono text-[11px] text-[#00FF9C] sm:block">{preset.id} selected</span></div><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">{INGESTION_PRODUCT_PRESETS.map(item => <button type="button" key={item.id} onClick={() => setPresetId(item.id)} className={`relative rounded-lg border p-3 text-left transition-colors ${preset.id === item.id ? 'border-[#00FF9C] bg-[#00FF9C]/10 ring-1 ring-[#00FF9C]/35' : 'border-[#292929] bg-[#161616] hover:border-neutral-600'}`}><div className="mb-1 flex items-center justify-between"><span className="text-xs font-bold text-white">{item.id}</span>{preset.id === item.id && <Check className="h-3.5 w-3.5 text-[#00FF9C]" />}</div><div className="mb-2 font-mono text-[10px] text-[#00FF9C]">{item.technology}</div><div className="font-mono text-[10px] leading-relaxed text-neutral-400">Die {item.dieWidthMm} × {item.dieHeightMm} mm<br />Reticle {item.reticleCols} × {item.reticleRows}</div></button>)}</div></div>

          <div className="grid gap-5 lg:grid-cols-3">
            <div className="lg:col-span-2"><input ref={fileInputRef} type="file" accept=".csv,.xlsx" className="hidden" onChange={event => { const file = event.target.files?.[0]; if (file) void uploadFile(file); event.currentTarget.value = ''; }} /><div onClick={() => fileInputRef.current?.click()} onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); const file = event.dataTransfer.files?.[0]; if (file) void uploadFile(file); }} className={`flex min-h-[210px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-7 text-center transition-colors ${dragging ? 'border-[#00FF9C] bg-[#00FF9C]/10' : 'border-[#343434] bg-[#131313] hover:border-[#00FF9C]/60 hover:bg-[#161616]'}`}><div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full border border-neutral-700 bg-neutral-900"><CategoryIcon className="h-7 w-7" style={{ color: meta.accent }} /></div><h3 className="mb-1 text-sm font-bold text-white">Drag &amp; Drop <span style={{ color: meta.accent }}>{category}</span> CSV or XLSX Here</h3><p className="mb-4 max-w-md text-xs text-neutral-400">Required: X/Y millimetre coordinates. CP requires a bin; WAT requires parameter and value; KLA accepts defect metadata. Maximum 20 MB / 150,000 rows.</p><span className="flex items-center gap-2 rounded-lg border border-neutral-600 bg-neutral-800 px-4 py-2 text-xs font-semibold text-white"><FileSpreadsheet className="h-3.5 w-3.5 text-[#00FF9C]" />Browse device files</span></div>{error && <div role="alert" className="mt-3 flex items-start gap-2 rounded-lg border border-red-800 bg-red-950/40 p-3 text-xs text-red-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}</div>
            <aside className="flex flex-col justify-between rounded-xl border border-[#242424] bg-[#121212] p-5"><div><div className="mb-3 flex items-center gap-2"><Cpu className="h-4 w-4 text-amber-400" /><h3 className="text-xs font-bold uppercase tracking-wider text-white">Supplied mock data</h3></div><p className="mb-4 text-xs leading-relaxed text-neutral-400">Load the verified reference dataset for the active perspective. It follows the same validation and persistence path as an operator upload.</p><div className="rounded-lg border border-[#313131] bg-[#161616] p-3"><div className="text-xs font-medium text-white">{MOCK_FILES[category].label}</div><div className="mt-1 font-mono text-[10px] text-neutral-500">Source retained in managed storage</div></div></div><button type="button" onClick={() => void loadMock()} disabled={uploading} className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-[#00FF9C] px-3 py-2.5 text-xs font-bold text-black transition-colors hover:bg-[#00e58c] disabled:cursor-wait disabled:opacity-60">{uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}{uploading ? 'Validating source file…' : 'Load & validate supplied mock'}</button></aside>
          </div>

          {summary && <section className="space-y-3 rounded-xl border border-[#00FF9C]/25 bg-[#00FF9C]/[0.035] p-4"><div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-[#00FF9C]" /><h3 className="text-xs font-bold uppercase tracking-wider text-white">Validated &amp; persisted dataset</h3></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">{[['Lot', summary.lot_id], ['Wafer', summary.wafer_id], ['Valid rows', summary.valid_rows.toLocaleString()], ['Rejected', summary.error_rows.toLocaleString()], [category === 'CP' ? 'Yield' : category === 'WAT' ? 'Mean' : 'Defects', category === 'CP' ? `${summary.stats.yield_pct}%` : category === 'WAT' ? summary.stats.mean_val.toString() : summary.stats.defect_count.toLocaleString()], [category === 'KLA' ? 'Repeaters' : 'Parameters', category === 'KLA' ? summary.stats.repeater_defect_count.toString() : summary.parameter_names.length.toString()]].map(([label, value]) => <div key={String(label)} className="rounded border border-[#2d2d2d] bg-[#131313] p-2.5"><div className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">{label}</div><div className="mt-1 truncate font-mono text-xs font-bold text-white">{value}</div></div>)}</div><div className="overflow-x-auto rounded border border-[#2d2d2d]"><table className="w-full text-left font-mono text-[10px]"><thead className="bg-[#161616] text-neutral-400"><tr>{Object.keys(summary.sample_rows[0] || {}).slice(0, 8).map(header => <th key={header} className="whitespace-nowrap px-3 py-2 font-medium">{header}</th>)}</tr></thead><tbody>{summary.sample_rows.slice(0, 3).map((row, index) => <tr key={index} className="border-t border-[#242424] text-neutral-300">{Object.values(row).slice(0, 8).map((value, cellIndex) => <td key={cellIndex} className="whitespace-nowrap px-3 py-2">{String(value ?? '—')}</td>)}</tr>)}</tbody></table></div></section>}
        </div>

        <footer className="flex items-center justify-between gap-3 border-t border-[#242424] bg-[#141414] px-5 py-4 sm:px-6"><div className="hidden items-center gap-2 font-mono text-xs text-neutral-400 sm:flex"><Database className="h-4 w-4 text-[#00FF9C]" />Target product: <strong className="text-white">{preset.id}</strong></div><div className="ml-auto flex gap-3"><button type="button" onClick={onClose} className="rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2 text-xs font-semibold text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white">Cancel</button><button id="btn-apply-ingestion" type="button" onClick={handleApply} disabled={!pending || uploading} className="flex items-center gap-2 rounded-lg bg-[#00FF9C] px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-[#00e58c] disabled:cursor-not-allowed disabled:bg-neutral-800 disabled:text-neutral-500"><span>Ingest &amp; Generate Wafer Map</span><ChevronRight className="h-4 w-4" /></button></div></footer>
      </section>
    </div>
  );
}
