import React from 'react';
import { Zap, Check, X, TrendingUp, Sparkles, AlertCircle } from 'lucide-react';
import { ShotOptimizationResult } from '../types';

interface ShotOptimizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  optimizationResult: ShotOptimizationResult | null;
  isLoading: boolean;
  onApplyOptimalOffset: (offsetX: number, offsetY: number) => void;
}

export const ShotOptimizerModal: React.FC<ShotOptimizerModalProps> = ({
  isOpen,
  onClose,
  optimizationResult,
  isLoading,
  onApplyOptimalOffset,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="shot-optimizer-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="bg-[#0C0C0C] border border-[#222] rounded-sm shadow-2xl w-full max-w-2xl overflow-hidden text-[#E5E5E5]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#111]">
          <div className="flex items-center gap-3.5">
            <div className="p-2 rounded-sm bg-[#080808] border border-[#222] text-[#00FF9C]">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tighter italic text-[#E5E5E5] flex items-center gap-2.5">
                <span>OPTIMIZER.AI</span>
                <span className="text-[10px] font-mono font-normal not-italic px-2 py-0.5 rounded-xs bg-[#080808] border border-[#222] text-[#00FF9C]">
                  GDPW MAXIMIZER
                </span>
              </h2>
              <p className="text-[11px] text-[#666] font-mono">
                2D Grid Search over Shot Pitch (dx, dy) space to maximize printable gross dies.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xs hover:bg-[#1A1A1A] text-[#666] hover:text-[#E5E5E5] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col gap-5">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-[#888]">
              <div className="w-8 h-8 border-2 border-[#00FF9C] border-t-transparent rounded-full animate-spin" />
              <div className="font-mono text-xs text-[#00FF9C]">Simulating stepping offset search permutations...</div>
            </div>
          ) : optimizationResult ? (
            <>
              {/* Summary Metric Cards */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-[#111] border border-[#222] p-3.5 rounded-sm flex flex-col">
                  <span className="text-[10px] text-[#666] uppercase tracking-[0.2em] font-mono">Baseline Gross</span>
                  <span className="text-xl font-bold font-mono text-[#AAA] mt-1">
                    {optimizationResult.baseline_gross_die}
                  </span>
                </div>

                <div className="bg-[#111] border border-[#222] p-3.5 rounded-sm flex flex-col">
                  <span className="text-[10px] text-[#00FF9C] uppercase tracking-[0.2em] font-mono flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>Optimized Gross</span>
                  </span>
                  <span className="text-xl font-bold font-mono text-[#E5E5E5] mt-1">
                    {optimizationResult.max_gross_die}
                  </span>
                </div>

                <div className="bg-[#111] border border-[#222] p-3.5 rounded-sm flex flex-col">
                  <span className="text-[10px] text-[#00FF9C] uppercase tracking-[0.2em] font-mono flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    <span>Net Gain</span>
                  </span>
                  <span className="text-xl font-bold font-mono text-[#00FF9C] mt-1">
                    +{optimizationResult.gain_dies} dies
                  </span>
                </div>
              </div>

              {/* Best Offset Coordinates */}
              <div className="bg-[#111] border border-[#222] p-4 rounded-sm flex items-center justify-between text-xs font-mono">
                <div>
                  <span className="text-[#666]">Best Offset X: </span>
                  <strong className="text-[#00FF9C]">
                    {optimizationResult.best_offset_x_mm > 0
                      ? `+${optimizationResult.best_offset_x_mm}`
                      : optimizationResult.best_offset_x_mm}{' '}
                    mm
                  </strong>
                </div>
                <div>
                  <span className="text-[#666]">Best Offset Y: </span>
                  <strong className="text-[#00FF9C]">
                    {optimizationResult.best_offset_y_mm > 0
                      ? `+${optimizationResult.best_offset_y_mm}`
                      : optimizationResult.best_offset_y_mm}{' '}
                    mm
                  </strong>
                </div>
              </div>

              {/* 2D Permutation Heatmap Visualizer */}
              <div className="bg-[#111] border border-[#222] p-4 rounded-sm flex flex-col gap-2">
                <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] flex justify-between font-mono">
                  <span>2D Offset Search Space Heatmap</span>
                  <span className="text-[#555]">Dark: Lower GDPW | Neon Green: Max GDPW</span>
                </div>

                <div className="flex justify-center items-center py-2">
                  <div className="grid grid-cols-20 gap-0.5 border border-[#222] p-1 bg-[#080808] rounded-xs">
                    {optimizationResult.heatmap.flatMap((row, rIdx) =>
                      row.map((cell, cIdx) => {
                        const minG = optimizationResult.baseline_gross_die - 15;
                        const maxG = optimizationResult.max_gross_die;
                        const norm = Math.max(0, Math.min(1, (cell.gdpw - minG) / (maxG - minG || 1)));
                        const isMax = cell.gdpw === maxG;

                        return (
                          <div
                            key={`h-${rIdx}-${cIdx}`}
                            className={`w-3.5 h-3.5 rounded-none transition-transform hover:scale-150 relative ${
                              isMax ? 'ring-1 ring-white' : ''
                            }`}
                            style={{
                              backgroundColor: isMax
                                ? '#00FF9C'
                                : `rgba(0, 255, 156, ${0.1 + norm * 0.7})`,
                            }}
                            title={`dx: ${cell.dx}mm, dy: ${cell.dy}mm -> ${cell.gdpw} dies`}
                          />
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-[#666] font-mono text-xs py-8 text-center">
              Click Start Optimization to compute the optimal center offset for your reticle field.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#222] bg-[#111] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#080808] hover:bg-[#1A1A1A] text-[#888] hover:text-[#E5E5E5] border border-[#222] transition-colors"
          >
            Cancel
          </button>

          {optimizationResult && (
            <button
              onClick={() => {
                onApplyOptimalOffset(
                  optimizationResult.best_offset_x_mm,
                  optimizationResult.best_offset_y_mm
                );
                onClose();
              }}
              className="px-5 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#00FF9C] hover:bg-[#00e08a] text-black flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(0,255,156,0.25)]"
            >
              <Check className="w-4 h-4" />
              <span>Apply Optimal Offset (+{optimizationResult.gain_dies} Dies)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
