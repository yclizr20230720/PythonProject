import React, { useState } from 'react';
import { Download, Copy, Check, X, FileCode, FileSpreadsheet, FileText } from 'lucide-react';
import { WaferLayoutResponse } from '../types';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  layoutData: WaferLayoutResponse | null;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  layoutData,
}) => {
  const [activeFormat, setActiveFormat] = useState<'e142' | 'g85' | 'klarf' | 'csv'>('e142');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen || !layoutData) return null;

  const { metadata, dies } = layoutData;

  // Generate SEMI E142 XML
  const generateE142Xml = () => {
    return `<?xml version="1.0" encoding="UTF-8"?>
<SubstrateMap xmlns="http://www.semi.org/standards/e142" SchemaVersion="1.0" SubstrateId="${metadata.wafer_id}" LotId="${metadata.lot_id}" ProductId="${metadata.product_id}" SubstrateType="Wafer300mm">
  <Layout Diameter="${metadata.diameter_mm}mm" EdgeExclusion="${metadata.edge_exclusion_mm}mm" NotchOrientation="${metadata.notch_angle_deg}deg" StepX="${metadata.shot_pitch_x_mm}mm" StepY="${metadata.shot_pitch_y_mm}mm" />
  <BinDefinitions>
    <Bin BinCode="1" BinName="PASS_GOOD" Quality="Pass" Rank="0" />
    <Bin BinCode="2" BinName="FAIL_CORE_VOLTAGE" Quality="Fail" Rank="1" />
    <Bin BinCode="3" BinName="FAIL_OPEN_SHORT" Quality="Fail" Rank="2" />
    <Bin BinCode="4" BinName="FAIL_EDGE_LEAKAGE" Quality="Fail" Rank="3" />
    <Bin BinCode="5" BinName="FAIL_TIMING_MARGIN" Quality="Fail" Rank="4" />
    <Bin BinCode="6" BinName="FAIL_RETICLE_DEFECT" Quality="Fail" Rank="5" />
    <Bin BinCode="7" BinName="FAIL_PARTICLE_DEFECT" Quality="Fail" Rank="6" />
    <Bin BinCode="99" BinName="EDGE_PARTIAL" Quality="Null" Rank="-1" />
  </BinDefinitions>
  <DieRecords Count="${dies.length}">
${dies
  .slice(0, 150)
  .map(
    (d) =>
      `    <Die UID="${d.die_uid}" X="${d.global_x}" Y="${d.global_y}" CenterX="${d.center_x_mm}" CenterY="${d.center_y_mm}" Shot="${d.shot_row},${d.shot_col}" Reticle="${d.reticle_row},${d.reticle_col}" Bin="${d.bin_code}" Status="${d.status}" />`
  )
  .join('\n')}
    <!-- ... ${Math.max(0, dies.length - 150)} more die records ... -->
  </DieRecords>
</SubstrateMap>`;
  };

  // Generate SEMI G85 Map String
  const generateG85Map = () => {
    const header = `# SEMI G85 Wafer Map Specification
WAFER_ID=${metadata.wafer_id}
LOT_ID=${metadata.lot_id}
PRODUCT_ID=${metadata.product_id}
DIAMETER=${metadata.diameter_mm}
NOTCH_ANGLE=${metadata.notch_angle_deg}
EDGE_EXCLUSION=${metadata.edge_exclusion_mm}
GROSS_DIE=${metadata.gross_die_count}
PASS_DIE=${metadata.pass_die_count}
YIELD_PCT=${metadata.yield_pct}%
[BIN_DEFINITIONS]
01=PASS_GOOD
02=FAIL_VOLTAGE
03=FAIL_OPEN_SHORT
04=FAIL_LEAKAGE
05=FAIL_TIMING
06=FAIL_RETICLE
07=FAIL_DEFECT
99=NULL_EDGE
[DIE_ARRAY_CSV]
GLOBAL_X,GLOBAL_Y,CENTER_X_MM,CENTER_Y_MM,SHOT_R,SHOT_C,RET_R,RET_C,BIN,STATUS\n`;

    const rows = dies
      .slice(0, 150)
      .map(
        (d) =>
          `${d.global_x},${d.global_y},${d.center_x_mm},${d.center_y_mm},${d.shot_row},${d.shot_col},${d.reticle_row},${d.reticle_col},${String(d.bin_code).padStart(2, '0')},${d.status}`
      )
      .join('\n');

    return header + rows + `\n# ... ${Math.max(0, dies.length - 150)} more records ...`;
  };

  // Generate KLARF format
  const generateKlarf = () => {
    return `FileVersion 1 2;
FileTimestamp 2026-08-28 15:52:00;
InspectionStationID "KLA-TENCOR-2900" "01";
SampleType WAFER;
SampleSize 300 300;
WaferID "${metadata.wafer_id}";
LotID "${metadata.lot_id}";
OrientationMarkLocation ${metadata.notch_angle_deg === 270 ? 'BOTTOM' : metadata.notch_angle_deg === 0 ? 'RIGHT' : metadata.notch_angle_deg === 90 ? 'TOP' : 'LEFT'};
DiePitch ${metadata.shot_pitch_x_mm} ${metadata.shot_pitch_y_mm};
DieOrigin 0 0;
DefectRecordSpec 7 DEFECTID XREL YREL XINDEX YINDEX DEFECTSIZE CLUSTER_NUMBER;
DefectList
${dies
  .filter((d) => d.defect_count > 0)
  .slice(0, 50)
  .map((d, i) => `  ${i + 1} 4.250 5.100 ${d.global_x} ${d.global_y} 0.18 0;`)
  .join('\n')}
SummarySpec 2 TEST NO_DEFECTS;
SummaryList
  1 ${dies.reduce((a, d) => a + d.defect_count, 0)};
EndOfFile;`;
  };

  // Generate CSV
  const generateCsv = () => {
    const header = 'die_uid,global_x,global_y,center_x_mm,center_y_mm,shot_row,shot_col,reticle_row,reticle_col,die_type,status,bin_code,bin_name,bin_quality,parametric_val,test_freq_ghz,leakage_ua,defect_count\n';
    const rows = dies
      .map(
        (d) =>
          `${d.die_uid},${d.global_x},${d.global_y},${d.center_x_mm},${d.center_y_mm},${d.shot_row},${d.shot_col},${d.reticle_row},${d.reticle_col},${d.die_type},${d.status},${d.bin_code},${d.bin_name},${d.bin_quality},${d.parametric_val},${d.test_freq_ghz},${d.leakage_ua},${d.defect_count}`
      )
      .join('\n');
    return header + rows;
  };

  const getContent = () => {
    if (activeFormat === 'e142') return generateE142Xml();
    if (activeFormat === 'g85') return generateG85Map();
    if (activeFormat === 'klarf') return generateKlarf();
    return generateCsv();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getContent());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const text = getContent();
    const filename = `${metadata.wafer_id}_${activeFormat}.${
      activeFormat === 'e142'
        ? 'xml'
        : activeFormat === 'g85'
        ? 'g85.txt'
        : activeFormat === 'klarf'
        ? 'klarf'
        : 'csv'
    }`;
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      id="export-standards-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="bg-[#0C0C0C] border border-[#222] rounded-sm shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden text-[#E5E5E5]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#111]">
          <div className="flex items-center gap-3.5">
            <div className="p-2 rounded-sm bg-[#080808] border border-[#222] text-[#00FF9C]">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tighter italic text-[#E5E5E5] flex items-center gap-2.5">
                <span>EXPORT.STANDARDS</span>
                <span className="text-[10px] font-mono font-normal not-italic px-2 py-0.5 rounded-xs bg-[#080808] border border-[#222] text-[#00FF9C]">
                  FAB INTEROPERABILITY
                </span>
              </h2>
              <p className="text-[11px] text-[#666] font-mono">
                Download or copy standardized wafer map descriptions for MES, ATE probe, and inspection tools.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xs hover:bg-[#1A1A1A] text-[#666] hover:text-[#E5E5E5] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Selector Tabs */}
        <div className="flex border-b border-[#222] bg-[#080808] px-6 gap-2 pt-2">
          <button
            onClick={() => setActiveFormat('e142')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeFormat === 'e142'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>SEMI E142 (XML)</span>
          </button>

          <button
            onClick={() => setActiveFormat('g85')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeFormat === 'g85'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>SEMI G85 (Map)</span>
          </button>

          <button
            onClick={() => setActiveFormat('klarf')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeFormat === 'klarf'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>KLARF (KLA)</span>
          </button>

          <button
            onClick={() => setActiveFormat('csv')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeFormat === 'csv'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Full Die CSV</span>
          </button>
        </div>

        {/* Code Content Preview */}
        <div className="p-6 overflow-y-auto flex-1 bg-[#080808]">
          <pre className="text-xs font-mono text-[#AAA] bg-[#0C0C0C] border border-[#222] p-4 rounded-sm overflow-x-auto select-all leading-relaxed">
            <code>{getContent()}</code>
          </pre>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-[#222] bg-[#111] flex items-center justify-between">
          <button
            onClick={handleCopy}
            className="px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#080808] hover:bg-[#1A1A1A] text-[#888] hover:text-[#E5E5E5] border border-[#222] flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-[#00FF9C]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Content'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-5 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#00FF9C] hover:bg-[#00e08a] text-black flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(0,255,156,0.25)]"
          >
            <Download className="w-4 h-4" />
            <span>Download .{activeFormat === 'e142' ? 'xml' : activeFormat === 'g85' ? 'g85' : activeFormat === 'klarf' ? 'klarf' : 'csv'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
