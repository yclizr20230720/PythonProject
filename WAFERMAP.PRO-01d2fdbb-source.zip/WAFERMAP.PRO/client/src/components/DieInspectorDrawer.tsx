import React from 'react';
import {
  X,
  MapPin,
  Cpu,
  Layers,
  Activity,
  Zap,
  CheckCircle2,
  AlertOctagon,
  Eye,
} from 'lucide-react';
import { DieInstance, ShotInstance } from '../types';

interface DieInspectorDrawerProps {
  die: DieInstance | null;
  shot: ShotInstance | null;
  onClose: () => void;
}

export const DieInspectorDrawer: React.FC<DieInspectorDrawerProps> = ({
  die,
  shot,
  onClose,
}) => {
  if (!die) return null;

  return (
    <div
      id="die-inspector-drawer"
      className="fixed bottom-0 right-0 w-full sm:w-96 bg-[#0C0C0C] border-t sm:border-l sm:border-t-0 border-[#222] shadow-2xl z-40 p-5 flex flex-col gap-4 text-[#E5E5E5] text-xs animate-in slide-in-from-right duration-150 select-none"
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#222] pb-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`p-1.5 rounded-xs ${
              die.bin_quality === 'PASS'
                ? 'bg-[#00331f] text-[#00FF9C] border border-[#00FF9C]/40'
                : 'bg-[#330c0c] text-[#FF3E3E] border border-[#FF3E3E]/40'
            }`}
          >
            {die.bin_quality === 'PASS' ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <AlertOctagon className="w-4 h-4" />
            )}
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#E5E5E5] font-mono">
              Die ({die.global_x}, {die.global_y})
            </h3>
            <div className="text-[10px] text-[#666] font-mono">{die.die_uid}</div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-xs hover:bg-[#1A1A1A] text-[#666] hover:text-[#E5E5E5] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Electrical Bin Status Card */}
      <div
        className={`p-3 rounded-sm border flex items-center justify-between font-mono ${
          die.bin_quality === 'PASS'
            ? 'bg-[#002214] border-[#00FF9C]/40'
            : 'bg-[#260a0a] border-[#FF3E3E]/40'
        }`}
      >
        <div>
          <div className="text-[9px] text-[#888] uppercase tracking-[0.2em]">
            Probe Test Result
          </div>
          <div
            className={`text-sm font-bold mt-0.5 ${
              die.bin_quality === 'PASS' ? 'text-[#00FF9C]' : 'text-[#FF3E3E]'
            }`}
          >
            {die.bin_name}
          </div>
        </div>
        <div className="text-right">
          <div className="text-[9px] text-[#888] uppercase tracking-[0.2em]">Bin Code</div>
          <div className="text-base font-bold text-[#E5E5E5] font-mono">
            {String(die.bin_code).padStart(2, '0')}
          </div>
        </div>
      </div>

      {/* Physical & Spatial Geometry */}
      <div className="bg-[#111] border border-[#222] p-3 rounded-sm flex flex-col gap-2 font-mono text-[11px]">
        <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] flex items-center gap-1.5">
          <MapPin className="w-3 h-3 text-[#00FF9C]" />
          <span>Physical Location (SEMI M20)</span>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-1">
          <div>
            <span className="text-[#666]">Center X:</span>{' '}
            <strong className="text-[#E5E5E5]">{die.center_x_mm} mm</strong>
          </div>
          <div>
            <span className="text-[#666]">Center Y:</span>{' '}
            <strong className="text-[#E5E5E5]">{die.center_y_mm} mm</strong>
          </div>
          <div>
            <span className="text-[#666]">Radial Dist:</span>{' '}
            <strong className="text-[#FFAE00]">{die.radial_dist_mm} mm</strong>
          </div>
          <div>
            <span className="text-[#666]">Azimuth Angle:</span>{' '}
            <strong className="text-[#E5E5E5]">{die.angle_deg}°</strong>
          </div>
        </div>
      </div>

      {/* Reticle & Shot Stepping Hierarchy */}
      <div className="bg-[#111] border border-[#222] p-3 rounded-sm flex flex-col gap-2 font-mono text-[11px]">
        <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] flex items-center gap-1.5">
          <Layers className="w-3 h-3 text-[#00FF9C]" />
          <span>Lithography Hierarchy</span>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-1">
          <div>
            <span className="text-[#666]">Shot ID:</span>{' '}
            <strong className="text-[#E5E5E5]">
              S({die.shot_row >= 0 ? `+${die.shot_row}` : die.shot_row},
              {die.shot_col >= 0 ? `+${die.shot_col}` : die.shot_col})
            </strong>
          </div>
          <div>
            <span className="text-[#666]">Reticle Cell:</span>{' '}
            <strong className="text-[#00FF9C]">
              R({die.reticle_row},{die.reticle_col})
            </strong>
          </div>
          <div>
            <span className="text-[#666]">Die Type:</span>{' '}
            <strong className="text-[#E5E5E5]">{die.die_type}</strong>
          </div>
          <div>
            <span className="text-[#666]">Status:</span>{' '}
            <strong className="text-[#00FF9C]">{die.status}</strong>
          </div>
        </div>
      </div>

      {/* Electrical Parametric Metrology */}
      <div className="bg-[#111] border border-[#222] p-3 rounded-sm flex flex-col gap-2 font-mono text-[11px]">
        <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] flex items-center gap-1.5">
          <Activity className="w-3 h-3 text-[#00FF9C]" />
          <span>Electrical Measurements</span>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-1">
          <div>
            <span className="text-[#666]">Parametric:</span>{' '}
            <strong className="text-[#00FF9C]">{die.parametric_val} / 100</strong>
          </div>
          <div>
            <span className="text-[#666]">Clock Freq:</span>{' '}
            <strong className="text-[#E5E5E5]">{die.test_freq_ghz} GHz</strong>
          </div>
          <div>
            <span className="text-[#666]">Leakage:</span>{' '}
            <strong className="text-[#FFAE00]">{die.leakage_ua} µA</strong>
          </div>
          <div>
            <span className="text-[#666]">Defects:</span>{' '}
            <strong className={die.defect_count > 0 ? 'text-[#FF3E3E]' : 'text-[#888]'}>
              {die.defect_count}
            </strong>
          </div>
        </div>
      </div>

      {/* Parent Shot Overview if available */}
      {shot && (
        <div className="bg-[#111] border border-[#222] p-3 rounded-sm flex items-center justify-between font-mono text-[11px]">
          <div>
            <div className="text-[9px] text-[#666] uppercase tracking-[0.2em]">Parent Shot Yield</div>
            <div className="text-[#E5E5E5] font-bold mt-0.5">
              {shot.pass_dies} / {shot.total_dies} Dies Pass
            </div>
          </div>
          <div className="text-right">
            <span
              className={`text-sm font-bold ${
                shot.yield_pct >= 90
                  ? 'text-[#00FF9C]'
                  : shot.yield_pct >= 75
                  ? 'text-[#FFAE00]'
                  : 'text-[#FF3E3E]'
              }`}
            >
              {shot.yield_pct}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
