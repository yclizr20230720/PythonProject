import React, { useState } from 'react';
import {
  Cpu,
  Layers,
  Sparkles,
  AlertTriangle,
  X,
  Plus,
  Minus,
  CheckCircle2,
  Grid,
} from 'lucide-react';
import { DieConfig, SpatialAnalytics, WaferMetadata } from '../types';
import { DIE_TYPE_COLORS } from '../utils/waferGeometry';

interface ReticleStudioProps {
  isOpen: boolean;
  onClose: () => void;
  dieConfig: DieConfig;
  setDieConfig: React.Dispatch<React.SetStateAction<DieConfig>>;
  metadata: WaferMetadata;
  spatial: SpatialAnalytics | null;
  highlightedCell: { row: number; col: number } | null;
  onHoverCell: (cell: { row: number; col: number } | null) => void;
}

export const ReticleStudio: React.FC<ReticleStudioProps> = ({
  isOpen,
  onClose,
  dieConfig,
  setDieConfig,
  metadata,
  spatial,
  highlightedCell,
  onHoverCell,
}) => {
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
  const [showRepeaterOverlay, setShowRepeaterOverlay] = useState<boolean>(true);

  if (!isOpen) return null;

  const repeaterMatrix = spatial?.reticle_repeater_matrix || [];

  const handleCellTypeChange = (newType: string) => {
    if (!selectedCell) return;
    const { row, col } = selectedCell;
    const newMatrix = dieConfig.die_type_matrix.map((r) => [...r]);
    if (newMatrix[row] && newMatrix[row][col] !== undefined) {
      newMatrix[row][col] = newType;
      setDieConfig((prev) => ({
        ...prev,
        die_type_matrix: newMatrix,
      }));
    }
  };

  const handleResizeReticle = (rows: number, cols: number) => {
    const validRows = Math.max(1, Math.min(6, rows));
    const validCols = Math.max(1, Math.min(8, cols));

    const newMatrix = Array.from({ length: validRows }, (_, r) =>
      Array.from({ length: validCols }, (_, c) => {
        if (dieConfig.die_type_matrix[r] && dieConfig.die_type_matrix[r][c]) {
          return dieConfig.die_type_matrix[r][c];
        }
        return 'LOGIC_CORE';
      })
    );

    setDieConfig((prev) => ({
      ...prev,
      reticle_rows: validRows,
      reticle_cols: validCols,
      die_type_matrix: newMatrix,
    }));
  };

  return (
    <div
      id="reticle-studio-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="bg-[#0C0C0C] border border-[#222] rounded-sm shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden text-[#E5E5E5]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#111]">
          <div className="flex items-center gap-3.5">
            <div className="p-2 rounded-sm bg-[#080808] border border-[#222] text-[#00FF9C]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tighter italic text-[#E5E5E5] flex items-center gap-2.5">
                <span>RETICLE.STUDIO</span>
                <span className="text-[10px] font-mono font-normal not-italic px-2 py-0.5 rounded-xs bg-[#080808] border border-[#222] text-[#00FF9C]">
                  {dieConfig.reticle_cols} × {dieConfig.reticle_rows} ARRAY
                </span>
              </h2>
              <p className="text-[11px] text-[#666] font-mono">
                Single Stepper Exposure Field ({metadata.reticle_field_w_mm} × {metadata.reticle_field_h_mm} mm) with Scribe Lanes
              </p>
            </div>
          </div>

          <button
            id="btn-close-reticle-studio"
            onClick={onClose}
            className="p-1.5 rounded-xs hover:bg-[#1A1A1A] text-[#666] hover:text-[#E5E5E5] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Visual Reticle Canvas */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] flex items-center gap-2">
                <Grid className="w-4 h-4 text-[#00FF9C]" />
                <span>Reticle Exposure Pattern</span>
              </div>
              <label className="flex items-center gap-2 text-xs font-mono text-[#888] cursor-pointer">
                <input
                  type="checkbox"
                  checked={showRepeaterOverlay}
                  onChange={(e) => setShowRepeaterOverlay(e.target.checked)}
                  className="rounded-none border-[#222] bg-[#080808] accent-[#00FF9C] focus:ring-0"
                />
                <span>Show Repeater Fail Rates</span>
              </label>
            </div>

            {/* Reticle Layout Visual Box */}
            <div className="bg-[#080808] border border-[#222] rounded-sm p-4 flex flex-col items-center justify-center min-h-[300px] relative shadow-inner">
              {/* Scribe Lane Indicators */}
              <div className="text-[10px] font-mono text-[#555] mb-2">
                Scribe Lanes: X={dieConfig.scribe_x_mm * 1000}µm | Y={dieConfig.scribe_y_mm * 1000}µm
              </div>

              {/* Grid of Dies */}
              <div
                className="grid gap-2 p-3 bg-[#111] border border-[#222] rounded-sm shadow-xl"
                style={{
                  gridTemplateColumns: `repeat(${dieConfig.reticle_cols}, minmax(0, 1fr))`,
                }}
              >
                {Array.from({ length: dieConfig.reticle_rows }, (_, r) =>
                  Array.from({ length: dieConfig.reticle_cols }, (_, c) => {
                    const dieType =
                      dieConfig.die_type_matrix[r]?.[c] || 'LOGIC_CORE';
                    const typeInfo = DIE_TYPE_COLORS[dieType] || DIE_TYPE_COLORS.PRODUCT_DIE;
                    const repeaterInfo = repeaterMatrix[r]?.[c];
                    const failRate = repeaterInfo ? repeaterInfo.fail_rate_pct : 0;
                    const isSelected = selectedCell?.row === r && selectedCell?.col === c;
                    const isHovered = highlightedCell?.row === r && highlightedCell?.col === c;

                    return (
                      <div
                        key={`cell-${r}-${c}`}
                        onMouseEnter={() => onHoverCell({ row: r, col: c })}
                        onMouseLeave={() => onHoverCell(null)}
                        onClick={() => setSelectedCell({ row: r, col: c })}
                        className={`p-3 rounded-sm border flex flex-col items-center justify-center cursor-pointer transition-all min-w-[76px] min-h-[76px] select-none ${
                          isSelected
                            ? 'border-[#00FF9C] bg-[#1a1a1a] shadow-lg scale-105'
                            : isHovered
                            ? 'border-[#00FF9C]/60 bg-[#161616]'
                            : 'border-[#222] bg-[#0C0C0C] hover:border-[#444]'
                        }`}
                      >
                        <div className="text-[10px] font-mono text-[#666]">
                          R({r},{c})
                        </div>
                        <div
                          className="w-3 h-3 rounded-full my-1"
                          style={{ backgroundColor: typeInfo.bg }}
                          title={typeInfo.name}
                        />
                        <div className="text-[10px] font-mono font-bold text-[#E5E5E5] truncate max-w-[70px]">
                          {typeInfo.code || dieType.slice(0, 5)}
                        </div>

                        {/* Reticle Fail Repeater Tag */}
                        {showRepeaterOverlay && repeaterInfo && (
                          <div
                            className={`mt-1 text-[9px] font-mono font-bold px-1 rounded-xs ${
                              failRate > 25
                                ? 'bg-[#330c0c] text-[#FF3E3E] border border-[#FF3E3E]/40'
                                : 'bg-[#111] text-[#666] border border-[#222]'
                            }`}
                          >
                            {failRate}% fail
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              <div className="text-[10px] font-mono text-[#555] mt-3 text-center">
                * Hovering any cell highlights all corresponding dies across all {metadata.total_shots} shots on the 300mm wafer.
              </div>
            </div>

            {/* Stepping Configuration Quick Sizer */}
            <div className="flex items-center justify-between bg-[#111] border border-[#222] p-3 rounded-sm text-xs font-mono">
              <div>
                <span className="text-[#666]">Field Size: </span>
                <strong className="text-[#E5E5E5]">
                  {metadata.reticle_field_w_mm} × {metadata.reticle_field_h_mm} mm
                </strong>
              </div>
              <div>
                <span className="text-[#666]">Step Pitch: </span>
                <strong className="text-[#00FF9C]">
                  {metadata.shot_pitch_x_mm} × {metadata.shot_pitch_y_mm} mm
                </strong>
              </div>
            </div>
          </div>

          {/* Right Column: Multi-Die Assignment & Array Controls */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Grid Sizing Controls */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-sm">
              <h3 className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] mb-3">
                Reticle Array Layout
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-mono text-[#666] block mb-1">Columns (X)</label>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleResizeReticle(dieConfig.reticle_rows, dieConfig.reticle_cols - 1)}
                      className="p-1.5 bg-[#080808] hover:bg-[#1A1A1A] border border-[#222] rounded-xs text-[#E5E5E5]"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="flex-1 text-center font-mono font-bold text-[#E5E5E5]">
                      {dieConfig.reticle_cols}
                    </span>
                    <button
                      onClick={() => handleResizeReticle(dieConfig.reticle_rows, dieConfig.reticle_cols + 1)}
                      className="p-1.5 bg-[#080808] hover:bg-[#1A1A1A] border border-[#222] rounded-xs text-[#E5E5E5]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-mono text-[#666] block mb-1">Rows (Y)</label>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleResizeReticle(dieConfig.reticle_rows - 1, dieConfig.reticle_cols)}
                      className="p-1.5 bg-[#080808] hover:bg-[#1A1A1A] border border-[#222] rounded-xs text-[#E5E5E5]"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="flex-1 text-center font-mono font-bold text-[#E5E5E5]">
                      {dieConfig.reticle_rows}
                    </span>
                    <button
                      onClick={() => handleResizeReticle(dieConfig.reticle_rows + 1, dieConfig.reticle_cols)}
                      className="p-1.5 bg-[#080808] hover:bg-[#1A1A1A] border border-[#222] rounded-xs text-[#E5E5E5]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Selected Cell Type Editor */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-sm flex-1">
              <h3 className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] mb-2">
                Cell Die Assignment
              </h3>
              {selectedCell ? (
                <div>
                  <div className="text-xs font-mono text-[#00FF9C] mb-3">
                    Selected: Cell R({selectedCell.row},{selectedCell.col})
                  </div>
                  <div className="flex flex-col gap-2">
                    {Object.entries(DIE_TYPE_COLORS).map(([key, info]) => {
                      const isCurrent =
                        dieConfig.die_type_matrix[selectedCell.row]?.[selectedCell.col] === key;
                      return (
                        <button
                          key={key}
                          onClick={() => handleCellTypeChange(key)}
                          className={`px-3 py-2 rounded-xs border text-left text-xs font-mono flex items-center justify-between transition-colors ${
                            isCurrent
                              ? 'border-[#00FF9C] bg-[#161616] text-[#00FF9C]'
                              : 'border-[#222] bg-[#0C0C0C] text-[#888] hover:border-[#444] hover:text-[#E5E5E5]'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <span
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: info.bg }}
                            />
                            <span>{info.name}</span>
                          </div>
                          {isCurrent && <CheckCircle2 className="w-4 h-4 text-[#00FF9C]" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="text-xs text-[#555] font-mono italic py-6 text-center">
                  Click any reticle cell on the left to change its product die type or test structure.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-[#222] bg-[#111] flex items-center justify-between">
          <span className="text-xs text-[#666] font-mono">
            Total Reticle Dies: {dieConfig.reticle_cols * dieConfig.reticle_rows}
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#E5E5E5] hover:bg-[#00FF9C] text-black transition-colors"
          >
            Apply & Close Studio
          </button>
        </div>
      </div>
    </div>
  );
};
