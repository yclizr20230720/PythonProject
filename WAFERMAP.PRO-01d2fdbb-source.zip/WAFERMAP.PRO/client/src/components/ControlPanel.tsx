import React, { useMemo } from 'react';
import {
  Settings2,
  Sliders,
  Sparkles,
  Zap,
  RotateCw,
  Maximize,
  Compass,
  Layers,
  HelpCircle,
  Activity,
} from 'lucide-react';
import {
  WaferConfig,
  DieConfig,
  DefectPatternType,
  IngestedDataType,
  IngestedWaferData,
  NotchOrientation,
  WaferMetadata,
} from '../types';

interface ControlPanelProps {
  waferConfig: WaferConfig;
  setWaferConfig: React.Dispatch<React.SetStateAction<WaferConfig>>;
  dieConfig: DieConfig;
  setDieConfig: React.Dispatch<React.SetStateAction<DieConfig>>;
  defectPattern: DefectPatternType;
  setDefectPattern: (pat: DefectPatternType) => void;
  metadata: WaferMetadata;
  onOpenOptimizer: () => void;
  onOpenReticleStudio: () => void;
  activeDatasets: Partial<Record<IngestedDataType, IngestedWaferData>>;
  onOpenIngestion: () => void;
  onOpenCpAnalysis: () => void;
  onClearActiveData: () => void;
}

const PRESETS = [
  {
    name: '5nm AI Accelerator (3×2 Reticle)',
    diameter: 300,
    edgeExclusion: 3.0,
    notch: 270 as NotchOrientation,
    dieW: 8.5,
    dieH: 10.2,
    scribeX: 0.08,
    scribeY: 0.08,
    retCols: 3,
    retRows: 2,
    matrix: [
      ['LOGIC_CORE', 'LOGIC_CORE', 'SRAM_CACHE'],
      ['LOGIC_CORE', 'IO_PHY', 'ANALOG_PLL'],
    ],
  },
  {
    name: 'Mobile Flagship SoC (2×3 Reticle)',
    diameter: 300,
    edgeExclusion: 2.5,
    notch: 270 as NotchOrientation,
    dieW: 10.5,
    dieH: 12.0,
    scribeX: 0.08,
    scribeY: 0.08,
    retCols: 2,
    retRows: 3,
    matrix: [
      ['LOGIC_CORE', 'SRAM_CACHE'],
      ['LOGIC_CORE', 'IO_PHY'],
      ['ANALOG_PLL', 'TEST_KEY'],
    ],
  },
  {
    name: 'Automotive MCU (4×3 Reticle)',
    diameter: 300,
    edgeExclusion: 3.0,
    notch: 270 as NotchOrientation,
    dieW: 5.2,
    dieH: 6.4,
    scribeX: 0.06,
    scribeY: 0.06,
    retCols: 4,
    retRows: 3,
    matrix: [
      ['LOGIC_CORE', 'LOGIC_CORE', 'LOGIC_CORE', 'SRAM_CACHE'],
      ['LOGIC_CORE', 'IO_PHY', 'IO_PHY', 'ANALOG_PLL'],
      ['LOGIC_CORE', 'LOGIC_CORE', 'TEST_KEY', 'ANALOG_PLL'],
    ],
  },
  {
    name: '3D NAND Flash (4×6 Reticle)',
    diameter: 300,
    edgeExclusion: 2.0,
    notch: 270 as NotchOrientation,
    dieW: 4.0,
    dieH: 4.8,
    scribeX: 0.05,
    scribeY: 0.05,
    retCols: 4,
    retRows: 6,
    matrix: Array(6).fill(Array(4).fill('PRODUCT_DIE')),
  },
  {
    name: 'Monolithic Mega GPU (1×1 Reticle)',
    diameter: 300,
    edgeExclusion: 3.5,
    notch: 270 as NotchOrientation,
    dieW: 24.0,
    dieH: 28.0,
    scribeX: 0.1,
    scribeY: 0.1,
    retCols: 1,
    retRows: 1,
    matrix: [['LOGIC_CORE']],
  },
];

export const ControlPanel: React.FC<ControlPanelProps> = ({
  waferConfig,
  setWaferConfig,
  dieConfig,
  setDieConfig,
  defectPattern,
  setDefectPattern,
  metadata,
  onOpenOptimizer,
  onOpenReticleStudio,
  activeDatasets,
  onOpenIngestion,
  onOpenCpAnalysis,
  onClearActiveData,
}) => {
  const activeSourceTypes = (Object.keys(activeDatasets) as IngestedDataType[]).filter(sourceType => activeDatasets[sourceType]);
  const primaryDataset = activeDatasets.CP ?? activeDatasets.WAT ?? activeDatasets.KLA;
  const activePresetIndex = useMemo(
    () => PRESETS.findIndex(p =>
      p.diameter === waferConfig.diameter_mm &&
      p.edgeExclusion === waferConfig.edge_exclusion_mm &&
      p.dieW === dieConfig.width_mm &&
      p.dieH === dieConfig.height_mm &&
      p.scribeX === dieConfig.scribe_x_mm &&
      p.scribeY === dieConfig.scribe_y_mm &&
      p.retCols === dieConfig.reticle_cols &&
      p.retRows === dieConfig.reticle_rows
    ),
    [waferConfig, dieConfig],
  );

  const handleApplyPreset = (idx: number) => {
    const p = PRESETS[idx];
    setWaferConfig((prev) => ({
      ...prev,
      diameter_mm: p.diameter,
      edge_exclusion_mm: p.edgeExclusion,
      notch_angle_deg: p.notch,
      center_offset_x_mm: 0,
      center_offset_y_mm: 0,
    }));
    setDieConfig({
      width_mm: p.dieW,
      height_mm: p.dieH,
      scribe_x_mm: p.scribeX,
      scribe_y_mm: p.scribeY,
      reticle_cols: p.retCols,
      reticle_rows: p.retRows,
      die_type_matrix: p.matrix,
    });
  };

  return (
    <aside
      id="wafer-control-panel"
      className="w-full lg:w-80 bg-[#0C0C0C] border-r border-[#222] p-5 flex flex-col gap-5 overflow-y-auto max-h-screen text-[#E5E5E5] text-xs select-none"
    >
      <button
        id="btn-open-panel-cp-analysis"
        type="button"
        onClick={onOpenCpAnalysis}
        className="group flex items-center justify-between rounded-sm border border-[#00FF9C]/60 bg-[#00FF9C] px-4 py-3 text-left text-black shadow-[0_0_14px_rgba(0,255,156,0.2)] transition-colors hover:bg-[#00e58c]"
      >
        <span><span className="block text-[10px] font-black uppercase tracking-[0.16em]">CP & YMS Analytics</span><span className="mt-0.5 block text-[9px] font-mono opacity-70">{activeDatasets.CP ? 'Source-backed analysis active' : 'Select retained CP data'}</span></span>
        <Activity className="h-5 w-5" />
      </button>

      <section className="rounded-sm border border-[#222] bg-[#111] p-3.5">
        <div className="flex items-center justify-between gap-2"><div><h3 className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#00E5FF]">Fab data workspace</h3><p className="mt-1 text-[10px] text-[#666]">CP · WAT · KLA retained sources</p></div><button id="btn-open-panel-ingestion" type="button" onClick={onOpenIngestion} className="rounded-sm bg-[#00FF9C] px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wide text-black hover:bg-[#00e58c]">{primaryDataset ? 'Add data' : 'Upload'}</button></div>
        {primaryDataset ? <div className="mt-3 border-t border-[#222] pt-3"><div className="flex flex-wrap gap-1.5">{activeSourceTypes.map(sourceType => <span key={sourceType} className={`rounded px-1.5 py-0.5 font-mono text-[9px] font-bold ${sourceType === 'CP' ? 'bg-[#00FF9C]/15 text-[#00FF9C]' : sourceType === 'WAT' ? 'bg-[#00E5FF]/15 text-[#00E5FF]' : 'bg-[#FF5A52]/15 text-[#FF5A52]'}`}>{sourceType} ACTIVE</span>)}</div><dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-[10px]"><div><dt className="text-[#666]">Lot</dt><dd className="truncate text-[#ccc]" title={primaryDataset.dataset.summary.lot_id}>{primaryDataset.dataset.summary.lot_id}</dd></div><div><dt className="text-[#666]">Wafer</dt><dd className="truncate text-[#ccc]" title={primaryDataset.dataset.summary.wafer_id}>{primaryDataset.dataset.summary.wafer_id}</dd></div><div><dt className="text-[#666]">Validated</dt><dd className="text-[#ccc]">{primaryDataset.dataset.summary.valid_rows.toLocaleString()}</dd></div><div><dt className="text-[#666]">Dataset</dt><dd className="text-[#ccc]">#{primaryDataset.dataset.dataset_id}</dd></div></dl><button type="button" onClick={onClearActiveData} className="mt-3 text-[10px] font-bold uppercase tracking-wider text-[#888] hover:text-[#FF5A52]">Clear active overlays</button></div> : <p className="mt-3 border-t border-[#222] pt-3 text-[10px] leading-relaxed text-[#666]">Upload a validated coordinate-aware source to activate overlays, provenance, and source-backed analysis.</p>}
      </section>

      {/* Executive Summary Stats Block */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222] space-y-3">
        <h3 className="text-[10px] text-[#00FF9C] uppercase tracking-[0.25em] font-bold flex items-center justify-between">
          <span>Executive Summary</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#00FF9C] shadow-[0_0_6px_#00FF9C]" />
        </h3>
        <div className="space-y-2 font-mono">
          <div className="flex justify-between items-baseline border-b border-[#1A1A1A] pb-1.5">
            <span className="text-[#888] text-[11px]">Gross Printable Dies</span>
            <span className="text-lg font-bold text-[#E5E5E5]">{metadata.gross_die_count.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-baseline border-b border-[#1A1A1A] pb-1.5">
            <span className="text-[#888] text-[11px]">Theoretical GDPW</span>
            <span className="text-lg font-bold text-[#AAA]">{metadata.theoretical_gdpw}</span>
          </div>
          <div className="flex justify-between items-baseline border-b border-[#1A1A1A] pb-1.5">
            <span className="text-[#888] text-[11px]">Partial Edge Exclusions</span>
            <span className="text-lg font-bold text-[#FFAE00]">{metadata.partial_die_count}</span>
          </div>
        </div>
      </div>

      {/* Preset Architecture Selector */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222]">
        <label className="text-[10px] text-[#888] uppercase tracking-[0.2em] font-bold block mb-2 flex items-center justify-between">
          <span>Architecture Preset</span>
          <Sparkles className="w-3.5 h-3.5 text-[#00FF9C]" />
        </label>
        <select
          id="select-preset"
          value={activePresetIndex >= 0 ? String(activePresetIndex) : 'imported'}
          onChange={(e) => {
            const index = Number(e.target.value);
            if (Number.isInteger(index) && index >= 0 && index < PRESETS.length) handleApplyPreset(index);
          }}
          className="w-full bg-[#080808] border border-[#222] rounded-xs px-3 py-2 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
        >
          {activePresetIndex < 0 && <option value="imported">Imported / Custom ({dieConfig.reticle_cols}×{dieConfig.reticle_rows} Reticle)</option>}
          {PRESETS.map((p, idx) => (
            <option key={p.name} value={idx}>
              {p.name}
            </option>
          ))}
        </select>
      </div>

      {/* Wafer Substrate Geometry (SEMI M20) */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222] flex flex-col gap-3">
        <h2 className="text-[10px] text-[#888] uppercase tracking-[0.2em] font-bold flex items-center justify-between">
          <span>Wafer Substrate (SEMI M20)</span>
          <Compass className="w-3.5 h-3.5 text-[#00FF9C]" />
        </h2>

        {/* Diameter & Notch */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Diameter (mm)</label>
            <select
              value={waferConfig.diameter_mm}
              onChange={(e) =>
                setWaferConfig((prev) => ({
                  ...prev,
                  diameter_mm: Number(e.target.value),
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            >
              <option value="300">300 mm (Std)</option>
              <option value="200">200 mm (Legacy)</option>
              <option value="450">450 mm (Next-Gen)</option>
            </select>
          </div>

          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Notch Orientation</label>
            <select
              value={waferConfig.notch_angle_deg}
              onChange={(e) =>
                setWaferConfig((prev) => ({
                  ...prev,
                  notch_angle_deg: Number(e.target.value) as NotchOrientation,
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            >
              <option value="270">270° (Bottom)</option>
              <option value="0">0° (Right)</option>
              <option value="90">90° (Top)</option>
              <option value="180">180° (Left)</option>
            </select>
          </div>
        </div>

        {/* Edge Exclusion */}
        <div className="pt-1">
          <div className="flex justify-between text-[#888] font-mono text-[11px] mb-1.5">
            <span>Edge Exclusion:</span>
            <strong className="text-[#00FF9C]">{waferConfig.edge_exclusion_mm} mm</strong>
          </div>
          <input
            type="range"
            min="1.0"
            max="8.0"
            step="0.5"
            value={waferConfig.edge_exclusion_mm}
            onChange={(e) =>
              setWaferConfig((prev) => ({
                ...prev,
                edge_exclusion_mm: Number(e.target.value),
              }))
            }
            className="w-full accent-[#00FF9C] cursor-pointer h-1.5 bg-[#1A1A1A] rounded-none"
          />
        </div>
      </div>

      {/* Reticle & Die Dimensions */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222] flex flex-col gap-3">
        <h2 className="text-[10px] text-[#888] uppercase tracking-[0.2em] font-bold flex items-center justify-between">
          <span>Die & Scribe Dimensions</span>
          <Layers className="w-3.5 h-3.5 text-[#00FF9C]" />
        </h2>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Die Width (mm)</label>
            <input
              type="number"
              min="1.0"
              max="40.0"
              step="0.1"
              value={dieConfig.width_mm}
              onChange={(e) =>
                setDieConfig((prev) => ({
                  ...prev,
                  width_mm: Math.max(1, Number(e.target.value)),
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            />
          </div>

          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Die Height (mm)</label>
            <input
              type="number"
              min="1.0"
              max="40.0"
              step="0.1"
              value={dieConfig.height_mm}
              onChange={(e) =>
                setDieConfig((prev) => ({
                  ...prev,
                  height_mm: Math.max(1, Number(e.target.value)),
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Scribe X (µm)</label>
            <input
              type="number"
              min="20"
              max="300"
              step="5"
              value={Math.round(dieConfig.scribe_x_mm * 1000)}
              onChange={(e) =>
                setDieConfig((prev) => ({
                  ...prev,
                  scribe_x_mm: Number(e.target.value) / 1000,
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            />
          </div>

          <div>
            <label className="text-[#666] text-[10px] uppercase font-mono block mb-1">Scribe Y (µm)</label>
            <input
              type="number"
              min="20"
              max="300"
              step="5"
              value={Math.round(dieConfig.scribe_y_mm * 1000)}
              onChange={(e) =>
                setDieConfig((prev) => ({
                  ...prev,
                  scribe_y_mm: Number(e.target.value) / 1000,
                }))
              }
              className="w-full bg-[#080808] border border-[#222] rounded-xs px-2.5 py-1.5 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
            />
          </div>
        </div>

        <button
          onClick={onOpenReticleStudio}
          className="w-full py-2.5 bg-[#111] hover:bg-[#1A1A1A] text-[#E5E5E5] border border-[#222] hover:border-[#00FF9C] hover:text-[#00FF9C] font-bold uppercase tracking-widest text-[10px] rounded-sm transition-colors flex items-center justify-center gap-1.5"
        >
          <span>Reticle Studio ({dieConfig.reticle_cols}×{dieConfig.reticle_rows})</span>
        </button>
      </div>

      {/* Stepping Shot Center Offset */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[10px] text-[#888] uppercase tracking-[0.2em] font-bold">
            Shot Center Offset (mm)
          </h2>
          <button
            onClick={onOpenOptimizer}
            className="text-[10px] text-[#00FF9C] hover:text-white font-bold uppercase tracking-wider flex items-center gap-1 transition-colors"
            title="Auto-Optimize Offset"
          >
            <Zap className="w-3 h-3 fill-current" />
            <span>Auto-Optimize</span>
          </button>
        </div>

        <div>
          <div className="flex justify-between text-[#888] font-mono text-[11px] mb-1.5">
            <span>Offset X:</span>
            <strong className="text-[#00FF9C] font-mono">{waferConfig.center_offset_x_mm} mm</strong>
          </div>
          <input
            type="range"
            min={-Math.round(metadata.shot_pitch_x_mm / 2)}
            max={Math.round(metadata.shot_pitch_x_mm / 2)}
            step="0.1"
            value={waferConfig.center_offset_x_mm}
            onChange={(e) =>
              setWaferConfig((prev) => ({
                ...prev,
                center_offset_x_mm: Number(e.target.value),
              }))
            }
            className="w-full accent-[#00FF9C] cursor-pointer h-1.5 bg-[#1A1A1A] rounded-none"
          />
        </div>

        <div>
          <div className="flex justify-between text-[#888] font-mono text-[11px] mb-1.5">
            <span>Offset Y:</span>
            <strong className="text-[#00FF9C] font-mono">{waferConfig.center_offset_y_mm} mm</strong>
          </div>
          <input
            type="range"
            min={-Math.round(metadata.shot_pitch_y_mm / 2)}
            max={Math.round(metadata.shot_pitch_y_mm / 2)}
            step="0.1"
            value={waferConfig.center_offset_y_mm}
            onChange={(e) =>
              setWaferConfig((prev) => ({
                ...prev,
                center_offset_y_mm: Number(e.target.value),
              }))
            }
            className="w-full accent-[#00FF9C] cursor-pointer h-1.5 bg-[#1A1A1A] rounded-none"
          />
        </div>
      </div>

      {/* Defect Signature Pattern Simulator */}
      <div className="p-4 bg-[#111] rounded-sm border border-[#222] flex flex-col gap-2">
        <label className="text-[10px] text-[#888] uppercase tracking-[0.2em] font-bold block mb-1 flex items-center justify-between">
          <span>Defect Spatial Signature</span>
          <Activity className="w-3.5 h-3.5 text-[#FF3E3E]" />
        </label>
        <select
          id="select-defect-pattern"
          value={defectPattern}
          onChange={(e) => setDefectPattern(e.target.value as DefectPatternType)}
          className="w-full bg-[#080808] border border-[#222] rounded-xs px-3 py-2 text-xs text-[#E5E5E5] focus:outline-none focus:border-[#00FF9C] font-mono"
        >
          <option value="random">Random Poisson (Baseline)</option>
          <option value="edge_ring">Edge Ring Roll-off (CMP / Bevel)</option>
          <option value="center_cluster">Center Cluster (Thermal Hotspot)</option>
          <option value="scratch">Linear Scratch (Chuck Handling)</option>
          <option value="repeater">Reticle Mask Repeater (Litho Defect)</option>
          <option value="donut">Thermal Donut Ring (Anneal Gradient)</option>
        </select>
      </div>
    </aside>
  );
};
