import React, { useState } from 'react';
import {
  BarChart3,
  X,
  Compass,
  PieChart,
  Grid,
  TrendingUp,
  Activity,
  Layers,
} from 'lucide-react';
import { SpatialAnalytics, WaferMetadata } from '../types';

interface SpatialAnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  spatial: SpatialAnalytics | null;
  metadata: WaferMetadata;
}

export const SpatialAnalyticsModal: React.FC<SpatialAnalyticsModalProps> = ({
  isOpen,
  onClose,
  spatial,
  metadata,
}) => {
  const [activeTab, setActiveTab] = useState<'radial' | 'angular' | 'repeater' | 'moran'>('radial');

  if (!isOpen || !spatial) return null;

  return (
    <div
      id="spatial-analytics-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="bg-[#0C0C0C] border border-[#222] rounded-sm shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden text-[#E5E5E5]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#111]">
          <div className="flex items-center gap-3.5">
            <div className="p-2 rounded-sm bg-[#080808] border border-[#222] text-[#00FF9C]">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tighter italic text-[#E5E5E5] flex items-center gap-2.5">
                <span>ANALYTICS.SPATIAL</span>
                <span className="text-[10px] font-mono font-normal not-italic px-2 py-0.5 rounded-xs bg-[#080808] border border-[#222] text-[#00FF9C]">
                  MORAN&apos;S I = {spatial.moran_i}
                </span>
              </h2>
              <p className="text-[11px] text-[#666] font-mono">
                Concentric Radial Yield, Angular Sector Asymmetry, and Reticle-Local Repeaters.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xs hover:bg-[#1A1A1A] text-[#666] hover:text-[#E5E5E5] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#222] bg-[#080808] px-6 gap-2 pt-2">
          <button
            onClick={() => setActiveTab('radial')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeTab === 'radial'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Radial Zones</span>
          </button>

          <button
            onClick={() => setActiveTab('angular')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeTab === 'angular'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Angular Sectors</span>
          </button>

          <button
            onClick={() => setActiveTab('repeater')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeTab === 'repeater'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Mask Repeaters</span>
          </button>

          <button
            onClick={() => setActiveTab('moran')}
            className={`pb-2.5 px-3 text-xs font-mono font-bold border-b-2 transition-colors flex items-center gap-1.5 uppercase tracking-wider ${
              activeTab === 'moran'
                ? 'border-[#00FF9C] text-[#00FF9C]'
                : 'border-transparent text-[#666] hover:text-[#E5E5E5]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Autocorrelation</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* 1. Radial Zones */}
          {activeTab === 'radial' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] font-mono">
                  Concentric Ring Yield Profile
                </h3>
                <span className="text-[11px] text-[#666] font-mono">
                  8 Annular Zones across 150mm Radius
                </span>
              </div>

              <div className="flex flex-col gap-2.5 bg-[#111] border border-[#222] p-4 rounded-sm">
                {spatial.radial_zones.map((zone, idx) => (
                  <div key={zone.zone} className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-[#E5E5E5] font-semibold">{zone.zone}</span>
                      <span className="flex items-center gap-3">
                        <span className="text-[#666]">
                          Pass: <strong className="text-[#00FF9C]">{zone.pass}</strong> / Total:{' '}
                          {zone.total}
                        </span>
                        <strong
                          className={`font-bold ${
                            zone.yield_pct >= 90
                              ? 'text-[#00FF9C]'
                              : zone.yield_pct >= 75
                              ? 'text-[#FFAE00]'
                              : 'text-[#FF3E3E]'
                          }`}
                        >
                          {zone.yield_pct}%
                        </strong>
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2 bg-[#080808] rounded-none overflow-hidden flex border border-[#222]">
                      <div
                        className={`h-full transition-all duration-300 ${
                          zone.yield_pct >= 90
                            ? 'bg-[#00FF9C]'
                            : zone.yield_pct >= 75
                            ? 'bg-[#FFAE00]'
                            : 'bg-[#FF3E3E]'
                        }`}
                        style={{ width: `${zone.yield_pct}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. Angular Sectors */}
          {activeTab === 'angular' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] font-mono">
                  Angular Sector Directional Yield
                </h3>
                <span className="text-[11px] text-[#666] font-mono">
                  8 Compass Directions (45° Slices)
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {spatial.angular_sectors.map((sec) => (
                  <div
                    key={sec.sector}
                    className="bg-[#111] border border-[#222] p-3.5 rounded-sm flex flex-col items-center justify-center text-center"
                  >
                    <span className="text-xs font-bold text-[#00FF9C] font-mono">{sec.sector}</span>
                    <span
                      className={`text-xl font-bold font-mono my-1 ${
                        sec.yield_pct >= 90
                          ? 'text-[#00FF9C]'
                          : sec.yield_pct >= 75
                          ? 'text-[#FFAE00]'
                          : 'text-[#FF3E3E]'
                      }`}
                    >
                      {sec.yield_pct}%
                    </span>
                    <span className="text-[11px] text-[#666] font-mono">
                      {sec.pass} / {sec.total} dies
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. Reticle-Local Repeater Matrix */}
          {activeTab === 'repeater' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em] font-mono">
                    Lithography Mask Repeater Matrix
                  </h3>
                  <p className="text-[11px] text-[#666] font-mono">
                    Aggregated cross-shot failure percentage for each reticle position. High failure indicates reticle mask/pellicle particles.
                  </p>
                </div>
              </div>

              <div className="bg-[#080808] border border-[#222] p-4 rounded-sm flex flex-col items-center justify-center">
                <div
                  className="grid gap-2 p-3 bg-[#111] border border-[#222] rounded-sm shadow-xl"
                  style={{
                    gridTemplateColumns: `repeat(${metadata.reticle_cols}, minmax(0, 1fr))`,
                  }}
                >
                  {spatial.reticle_repeater_matrix.flatMap((row, rIdx) =>
                    row.map((cell, cIdx) => (
                      <div
                        key={`rep-${rIdx}-${cIdx}`}
                        className={`p-3 rounded-sm border flex flex-col items-center justify-center min-w-[90px] min-h-[90px] font-mono ${
                          cell.fail_rate_pct > 25
                            ? 'bg-[#330c0c] border-[#FF3E3E]/60 text-[#FF3E3E]'
                            : cell.fail_rate_pct > 10
                            ? 'bg-[#332200] border-[#FFAE00]/60 text-[#FFAE00]'
                            : 'bg-[#0C0C0C] border-[#222] text-[#888]'
                        }`}
                      >
                        <span className="text-[10px] text-[#666]">
                          R({rIdx},{cIdx})
                        </span>
                        <strong className="text-base font-bold my-0.5 text-[#E5E5E5]">
                          {cell.fail_rate_pct}%
                        </strong>
                        <span className="text-[9px] text-[#555]">
                          {cell.fail} / {cell.total} fails
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 4. Moran's I Autocorrelation */}
          {activeTab === 'moran' && (
            <div className="flex flex-col gap-4">
              <div className="bg-[#111] border border-[#222] p-5 rounded-sm flex flex-col gap-3 font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[#888] uppercase tracking-[0.2em]">
                    Moran&apos;s I Spatial Autocorrelation Score
                  </span>
                  <span className="font-mono font-bold text-[#00FF9C] text-lg">
                    {spatial.moran_i}
                  </span>
                </div>

                <div className="text-xs text-[#E5E5E5] p-3 rounded-sm bg-[#080808] border border-[#222] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#00FF9C]" />
                  <span>Pattern Diagnosis: <strong>{spatial.clustering_level}</strong></span>
                </div>

                <div className="text-xs text-[#888] leading-relaxed space-y-2">
                  <p>
                    • <strong className="text-[#E5E5E5]">I &gt; +0.30</strong>: Strong spatial clustering (indicates non-random signatures such as handling scratches, edge roll-off ring, or thermal center hotspots).
                  </p>
                  <p>
                    • <strong className="text-[#E5E5E5]">-0.10 &le; I &le; +0.15</strong>: Spatial randomness (healthy baseline semiconductor process adhering to Poisson defect distribution).
                  </p>
                  <p>
                    • <strong className="text-[#E5E5E5]">I &lt; -0.10</strong>: Spatial dispersion or checkerboard patterns (often indicating alternating probe card needle or channel artifacts).
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-[#222] bg-[#111] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold uppercase tracking-widest rounded-sm bg-[#080808] hover:bg-[#1A1A1A] text-[#888] hover:text-[#E5E5E5] border border-[#222] transition-colors"
          >
            Close Analytics
          </button>
        </div>
      </div>
    </div>
  );
};
