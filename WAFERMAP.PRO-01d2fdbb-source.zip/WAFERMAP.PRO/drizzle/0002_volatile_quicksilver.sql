CREATE TABLE `analysis_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`waferConfigurationId` int NOT NULL,
	`reticleLayoutId` int,
	`viewMode` enum('bin_category','heatmap','shot_grid','defects') NOT NULL DEFAULT 'bin_category',
	`defectPattern` varchar(64) NOT NULL,
	`layoutSnapshot` json NOT NULL,
	`spatialSnapshot` json,
	`optimizationSnapshot` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analysis_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `export_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisSessionId` int,
	`format` enum('semi_e142','semi_g85','csv','png') NOT NULL,
	`contentHash` varchar(128) NOT NULL,
	`byteSize` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `export_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reticle_layouts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`waferConfigurationId` int NOT NULL,
	`revision` int NOT NULL,
	`columns` int NOT NULL,
	`rows` int NOT NULL,
	`dieTypeMatrix` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reticle_layouts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wafer_configurations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int,
	`waferId` varchar(128) NOT NULL,
	`lotId` varchar(128) NOT NULL,
	`productId` varchar(128) NOT NULL,
	`configuration` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wafer_configurations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `analysis_sessions` ADD CONSTRAINT `analysis_wafer_fk` FOREIGN KEY (`waferConfigurationId`) REFERENCES `wafer_configurations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `analysis_sessions` ADD CONSTRAINT `analysis_reticle_fk` FOREIGN KEY (`reticleLayoutId`) REFERENCES `reticle_layouts`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `export_records` ADD CONSTRAINT `export_session_fk` FOREIGN KEY (`analysisSessionId`) REFERENCES `analysis_sessions`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reticle_layouts` ADD CONSTRAINT `reticle_wafer_fk` FOREIGN KEY (`waferConfigurationId`) REFERENCES `wafer_configurations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `wafer_configurations` ADD CONSTRAINT `wafer_owner_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `analysis_sessions_configuration_created_idx` ON `analysis_sessions` (`waferConfigurationId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `export_records_session_created_idx` ON `export_records` (`analysisSessionId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `reticle_layouts_configuration_revision_idx` ON `reticle_layouts` (`waferConfigurationId`,`revision`);--> statement-breakpoint
CREATE INDEX `wafer_configurations_owner_created_idx` ON `wafer_configurations` (`ownerId`,`createdAt`);