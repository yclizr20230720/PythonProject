CREATE TABLE `cp_die_measurements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`datasetId` int NOT NULL,
	`dieX` int NOT NULL,
	`dieY` int NOT NULL,
	`xMm` double NOT NULL,
	`yMm` double NOT NULL,
	`binCode` int NOT NULL,
	`binName` varchar(256) NOT NULL,
	`binQuality` enum('PASS','FAIL','NULL') NOT NULL,
	`paramName` varchar(128),
	`paramValue` double,
	`paramUnit` varchar(32),
	`testFreqGhz` double,
	`leakageUa` double,
	CONSTRAINT `cp_die_measurements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ingestion_datasets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int,
	`sourceType` enum('CP','WAT','KLA') NOT NULL,
	`waferId` varchar(128) NOT NULL,
	`lotId` varchar(128) NOT NULL,
	`productId` varchar(128) NOT NULL,
	`originalFilename` varchar(255) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` varchar(640) NOT NULL,
	`sourceHash` varchar(64) NOT NULL,
	`byteSize` int NOT NULL,
	`totalRows` int NOT NULL,
	`validRows` int NOT NULL,
	`errorRows` int NOT NULL,
	`columnMapping` json NOT NULL,
	`summary` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ingestion_datasets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kla_defects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`datasetId` int NOT NULL,
	`defectId` varchar(128) NOT NULL,
	`dieX` int NOT NULL,
	`dieY` int NOT NULL,
	`xMm` double NOT NULL,
	`yMm` double NOT NULL,
	`reticleLocalXmm` double,
	`reticleLocalYmm` double,
	`sizeUm` double NOT NULL,
	`defectClass` varchar(128) NOT NULL,
	`layer` varchar(128),
	`clusterId` int NOT NULL DEFAULT 0,
	`isRepeater` boolean NOT NULL DEFAULT false,
	CONSTRAINT `kla_defects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wat_measurements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`datasetId` int NOT NULL,
	`siteId` varchar(128) NOT NULL,
	`dieX` int NOT NULL,
	`dieY` int NOT NULL,
	`xMm` double NOT NULL,
	`yMm` double NOT NULL,
	`paramName` varchar(128) NOT NULL,
	`value` double NOT NULL,
	`unit` varchar(32) NOT NULL,
	`specLow` double,
	`specTarget` double,
	`specHigh` double,
	`status` enum('PASS','WARN','FAIL') NOT NULL,
	CONSTRAINT `wat_measurements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `cp_die_measurements` ADD CONSTRAINT `cp_dataset_fk` FOREIGN KEY (`datasetId`) REFERENCES `ingestion_datasets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD CONSTRAINT `ingest_owner_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `kla_defects` ADD CONSTRAINT `kla_dataset_fk` FOREIGN KEY (`datasetId`) REFERENCES `ingestion_datasets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `wat_measurements` ADD CONSTRAINT `wat_dataset_fk` FOREIGN KEY (`datasetId`) REFERENCES `ingestion_datasets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `cp_dataset_die_idx` ON `cp_die_measurements` (`datasetId`,`dieX`,`dieY`);--> statement-breakpoint
CREATE INDEX `ingest_wafer_created_idx` ON `ingestion_datasets` (`waferId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `ingest_source_created_idx` ON `ingestion_datasets` (`sourceType`,`createdAt`);--> statement-breakpoint
CREATE INDEX `kla_dataset_coordinate_idx` ON `kla_defects` (`datasetId`,`xMm`,`yMm`);--> statement-breakpoint
CREATE INDEX `kla_dataset_repeater_idx` ON `kla_defects` (`datasetId`,`isRepeater`);--> statement-breakpoint
CREATE INDEX `wat_dataset_parameter_idx` ON `wat_measurements` (`datasetId`,`paramName`);