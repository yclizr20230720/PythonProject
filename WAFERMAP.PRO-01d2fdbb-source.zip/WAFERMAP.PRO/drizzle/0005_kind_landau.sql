CREATE TABLE `import_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int,
	`sourceType` enum('CP','WAT','KLA') NOT NULL,
	`originalFilename` varchar(255) NOT NULL,
	`sourceHash` varchar(64) NOT NULL,
	`status` enum('PROCESSING','COMPLETED','REJECTED') NOT NULL DEFAULT 'PROCESSING',
	`diagnostics` json,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `import_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD `importRunId` int;--> statement-breakpoint
ALTER TABLE `import_runs` ADD CONSTRAINT `import_owner_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `import_runs_status_started_idx` ON `import_runs` (`status`,`startedAt`);--> statement-breakpoint
ALTER TABLE `ingestion_datasets` ADD CONSTRAINT `ingest_run_fk` FOREIGN KEY (`importRunId`) REFERENCES `import_runs`(`id`) ON DELETE set null ON UPDATE no action;