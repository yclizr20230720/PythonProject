# Semiconductor Fab Metrology & Defect Data Repository

This directory contains standardized manufacturing test and metrology datasets for semiconductor wafer map analysis, process capability evaluation, and photomask defect inspection.

## Directory Structure

- **`CP_WaferSort_7nm_HPC.csv`**
  - **Type**: Circuit Probe (CP / Wafer Sort)
  - **Technology**: 7nm FinFET High-Performance Computing (Flagship AP-ULTRA-X9)
  - **Die Count**: ~752 Dies
  - **Fields**: `LotID`, `WaferID`, `ProductName`, `DieX`, `DieY`, `Point_X_mm`, `Point_Y_mm`, `BinCode`, `BinName`, `BinQuality`, `Param_Name`, `Test_Value`, `Freq_GHz`, `Leakage_uA`
  - **Signatures**: CMP edge roll-off yield drop, mechanical wafer handler scratch line, core Vth and Iddq leakage distributions.

- **`CP_WaferSort_HD100K.csv`**
  - **Type**: Circuit Probe (CP / Wafer Sort)
  - **Technology**: High-Density Micro-Array (HD-MICRO-100K)
  - **Die Count**: 102,400+ Dies (0.8mm × 0.8mm pitch)
  - **Fields**: Complete 100k-die array with Hard/Soft Binning (Bin 1-7), pass/fail status, Freq_GHz, and Leakage current across 300mm wafer.

- **`WAT_PCM_Metrology_81Sites.csv`**
  - **Type**: Wafer Acceptance Test (WAT / PCM Process Control Monitor)
  - **Technology**: 5nm / 3nm Metrology Scribe-Line Test Structures
  - **PCM Sites**: 81 Test Sites across 6 Radial Concentric Rings (0mm, 25mm, 55mm, 85mm, 115mm, 140mm)
  - **Parameters**:
    - `WAT_NMOS_VTH_SAT` (V)
    - `WAT_PMOS_VTH_SAT` (V)
    - `WAT_ION_NMOS_DRIVE` (mA/µm)
    - `WAT_IOFF_LEAKAGE_PA` (pA/µm)
    - `WAT_POLY_SHEET_RES` (Ω/sq)
    - `WAT_M1_COPPER_RES` (Ω)
    - `WAT_VIA1_KELVIN_RES` (Ω)
    - `WAT_GATE_OXIDE_BV` (V)
    - `WAT_RING_OSC_DELAY` (ps)
  - **Fields**: `LotID`, `WaferID`, `SiteID`, `DieX`, `DieY`, `Point_X_mm`, `Point_Y_mm`, `Param_Name`, `Test_Value`, `Unit`, `Spec_Low`, `Spec_Target`, `Spec_High`, `Status` (PASS / WARN / FAIL)

- **`KLA_DefectInspection_KLARF.csv`**
  - **Type**: KLA Optical/E-Beam Defect Inspection (KLARF format compatible)
  - **Technology**: Multi-layer In-line Defect Metrology
  - **Defect Count**: ~440+ defect points
  - **Signatures**:
    - Random background killer particles (organic, metallic, pinholes)
    - CMP brush arc scratch cluster (Cluster ID: 101)
    - Stepper Photomask Reticle Repeater defect (Cluster ID: 999) repeating at exact sub-die offsets in 28 exposure shots.
  - **Fields**: `LotID`, `WaferID`, `ProductName`, `DefectID`, `Point_X_mm`, `Point_Y_mm`, `DieX`, `DieY`, `Defect_Class`, `Defect_Size_um`, `Layer`, `ClusterID`

## Standards Compliance

These files follow **SEMI M20**, **SEMI E142 (Substrate Map)**, and **KLA KLARF** semiconductor data interchange standards.
