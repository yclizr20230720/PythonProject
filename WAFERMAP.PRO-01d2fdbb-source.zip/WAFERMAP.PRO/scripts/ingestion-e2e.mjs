import assert from "node:assert/strict";
import { chromium } from "@playwright/test";

const baseUrl = process.env.WAFERMAP_E2E_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true });

try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 980 } });
  await page.goto(baseUrl, { waitUntil: "networkidle" });

  await page.locator("#btn-open-data-criteria").click();
  await page.getByRole("dialog", { name: "Persisted source criteria explorer" }).waitFor({ state: "visible" });
  assert.equal(await page.getByText("DATA CRITERIA & SOURCE EXPLORER").count(), 1, "source criteria explorer must open");
  await page.getByRole("button", { name: "Close persisted source criteria explorer" }).click();

  await page.locator("#btn-open-cp-analysis").click();
  await page.getByRole("dialog", { name: "CP and YMS analysis studio" }).waitFor({ state: "visible" });
  assert.ok(await page.getByText("Select a retained CP source").count(), "CP and YMS studio must provide a data-selection state before CP is loaded");
  await page.getByRole("button", { name: "Close CP and YMS analysis studio" }).click();

  const openStudio = async () => {
    await page.locator("#btn-open-ingestion").click();
    await page.getByRole("dialog", { name: "Fab metrology and defect ingestion studio" }).waitFor({ state: "visible" });
  };

  await openStudio();
  assert.equal(await page.getByText("FAB METROLOGY & DEFECT INGESTION STUDIO").count(), 1, "ingestion studio must open");
  await page.getByRole("button", { name: "Load & validate supplied mock" }).click();
  await page.waitForFunction(() => !document.querySelector("#btn-apply-ingestion")?.hasAttribute("disabled"), undefined, { timeout: 120_000 });
  await page.locator("#btn-apply-ingestion").click();
  await page.locator("#wafer-canvas-container").waitFor({ state: "visible" });
  assert.ok((await page.locator("#main-app-header").textContent())?.includes("CP dataset #"), "100k-die CP dataset status must be visible after handoff");

  await openStudio();
  await page.getByRole("button", { name: "WAT Metrology" }).first().click();
  await page.getByRole("button", { name: "Load & validate supplied mock" }).click();
  await page.locator("#btn-apply-ingestion").waitFor({ state: "visible", timeout: 90_000 });
  await page.waitForFunction(() => !document.querySelector("#btn-apply-ingestion")?.hasAttribute("disabled"), undefined, { timeout: 90_000 });
  await page.locator("#btn-apply-ingestion").click();
  await page.locator("#btn-view-wat").waitFor({ state: "visible" });
  await page.locator("#btn-view-wat").click();
  assert.equal(await page.locator("#wafer-canvas-container").getAttribute("data-canvas-width") !== "0", true, "WAT overlay must retain an initialized canvas");

  await openStudio();
  await page.getByRole("button", { name: "KLA Defect Inspection" }).first().click();
  await page.getByRole("button", { name: "Load & validate supplied mock" }).click();
  await page.waitForFunction(() => !document.querySelector("#btn-apply-ingestion")?.hasAttribute("disabled"), undefined, { timeout: 90_000 });
  await page.locator("#btn-apply-ingestion").click();
  await page.locator("#btn-view-kla").waitFor({ state: "visible" });
  await page.locator("#btn-view-kla").click();
  assert.ok((await page.locator("#main-app-header").textContent())?.includes("KLA dataset #"), "KLA dataset status must be visible after handoff");

  await page.locator("#btn-open-cp-analysis").click();
  await page.getByRole("dialog", { name: "CP and YMS analysis studio" }).waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Bin Pareto" }).click();
  await page.getByText("Bin yield detractor Pareto & cumulative loss").waitFor({ state: "visible", timeout: 90_000 });
  assert.ok((await page.getByText("Total tested dies").count()) > 0, "CP analysis must render persisted CP metrics");
  await page.getByRole("button", { name: "Kill-ratio & trace" }).click();
  await page.getByText("Kill-ratio & coordinate trace").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Spatial screening" }).click();
  await page.getByText("Spatial screening & radial zones").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "OCAP triage" }).click();
  await page.getByText("Observed-condition action plan").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Process window" }).click();
  await page.getByText("CP measured process window").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Test signals" }).click();
  await page.getByText("Imported CP test signals").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Observed scenarios" }).click();
  await page.getByText("Observed edge-exclusion scenarios").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Cross-domain" }).click();
  await page.getByText("KLA coordinate overlap").waitFor({ state: "visible", timeout: 90_000 });
  await page.getByRole("button", { name: "Data lineage" }).click();
  await page.getByText("Active persisted source lineage").waitFor({ state: "visible", timeout: 90_000 });
  console.log("Ingestion E2E passed: retained source criteria, CP/WAT/KLA upload, overlay controls, and the full governed CP and YMS studio are operational.");
} finally {
  await browser.close();
}
