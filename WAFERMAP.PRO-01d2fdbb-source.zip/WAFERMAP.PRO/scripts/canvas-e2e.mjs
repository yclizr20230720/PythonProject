import assert from "node:assert/strict";
import { chromium } from "@playwright/test";

const baseUrl = process.env.WAFERMAP_E2E_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true });

try {
  const context = await browser.newContext({ viewport: { width: 2048, height: 793 }, deviceScaleFactor: 1, hasTouch: true });
  const page = await context.newPage();
  await page.goto(baseUrl, { waitUntil: "networkidle" });

  const canvas = page.locator("#wafer-canvas-container");
  await canvas.waitFor({ state: "visible" });
  const getTransform = async () => canvas.evaluate((element) => ({
    width: Number(element.getAttribute("data-canvas-width")),
    height: Number(element.getAttribute("data-canvas-height")),
    scale: Number(element.getAttribute("data-canvas-scale")),
    panX: Number(element.getAttribute("data-canvas-pan-x")),
    panY: Number(element.getAttribute("data-canvas-pan-y")),
    text: element.textContent || "",
  }));

  const initial = await getTransform();
  assert.ok(initial.width > 1000 && initial.height > 500, "ultra-wide workspace must have a measurable canvas viewport");
  assert.ok(Number.isFinite(initial.scale) && initial.scale > 0, "initial canvas scale must be finite and positive");
  assert.ok(Number.isFinite(initial.panX) && Number.isFinite(initial.panY), "initial pan must be finite");
  assert.ok(!initial.text.includes("Infinity"), "canvas telemetry must not show Infinity");

  const bounds = await canvas.boundingBox();
  assert.ok(bounds, "canvas must expose a draggable pointer target");
  const startX = bounds.x + bounds.width * 0.48;
  const startY = bounds.y + bounds.height * 0.48;
  await page.mouse.move(startX, startY);
  await page.mouse.down();
  await page.mouse.move(startX + 180, startY + 90, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(80);

  const afterDrag = await getTransform();
  assert.ok(Math.abs(afterDrag.panX - initial.panX) > 100, "pointer drag must move pan X in canvas-local pixels");
  assert.ok(Math.abs(afterDrag.panY - initial.panY) > 45, "pointer drag must move pan Y in canvas-local pixels");

  await page.locator("#btn-zoom-in").click();
  await page.waitForTimeout(80);
  const afterZoom = await getTransform();
  assert.ok(
    afterZoom.scale > afterDrag.scale,
    `zoom-in must increase canvas scale; before=${afterDrag.scale}, after=${afterZoom.scale}, initial=${initial.scale}`
  );
  await page.locator("#btn-zoom-fit").click();
  await page.waitForTimeout(80);
  const afterFit = await getTransform();
  assert.ok(Number.isFinite(afterFit.scale) && Number.isFinite(afterFit.panX) && Number.isFinite(afterFit.panY), "fit must restore a finite transform");

  await context.close();
  console.log("Canvas E2E passed: ultra-wide fit, pointer pan, and zoom controls are stable.");
} finally {
  await browser.close();
}
