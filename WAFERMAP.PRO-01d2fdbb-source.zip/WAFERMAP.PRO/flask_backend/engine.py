"""
RetiMap 300 - WaferMap & Reticle Geometry & Analytics Engine
Pure Python 3.10 standard library implementation with zero external C-dependencies.
Handles SEMI M20/M1 wafer coordinates, reticle stepping layout, GDPW placement optimization,
spatial autocorrelation (Moran's I), reticle repeater analysis, and SEMI E142/G85/KLARF formats.
"""

import math
import json
import random
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Tuple, Optional, Any


@dataclass
class DieConfig:
    width_mm: float = 8.5
    height_mm: float = 10.2
    scribe_x_mm: float = 0.08
    scribe_y_mm: float = 0.08
    reticle_cols: int = 3
    reticle_rows: int = 2
    die_type_matrix: List[List[str]] = field(default_factory=lambda: [
        ["LOGIC_CORE", "LOGIC_CORE", "SRAM_CACHE"],
        ["LOGIC_CORE", "IO_PHY", "ANALOG_PLL"]
    ])


@dataclass
class WaferConfig:
    diameter_mm: float = 300.0
    edge_exclusion_mm: float = 3.0
    notch_angle_deg: float = 270.0  # 270 = Bottom notch (SEMI 300mm standard)
    center_offset_x_mm: float = 0.0
    center_offset_y_mm: float = 0.0
    wafer_id: str = "W300-PROD-202608-01"
    lot_id: str = "LOT-7NM-A88"
    product_id: str = "AP-ULTRA-X9"


@dataclass
class DieInstance:
    die_uid: str
    global_x: int
    global_y: int
    center_x_mm: float
    center_y_mm: float
    width_mm: float
    height_mm: float
    shot_row: int
    shot_col: int
    reticle_row: int
    reticle_col: int
    die_type: str
    status: str  # FULL, PARTIAL, OUTSIDE, SCRIBE
    is_yieldable: bool
    bin_code: int = 1
    bin_name: str = "PASS"
    bin_quality: str = "PASS"  # PASS, FAIL, NULL
    parametric_val: float = 98.5
    test_freq_ghz: float = 3.8
    leakage_ua: float = 12.4
    defect_count: int = 0
    radial_dist_mm: float = 0.0
    angle_deg: float = 0.0


@dataclass
class ShotInstance:
    shot_id: str
    shot_row: int
    shot_col: int
    center_x_mm: float
    center_y_mm: float
    width_mm: float
    height_mm: float
    status: str  # FULL, PARTIAL, EXCLUDED
    total_dies: int = 0
    pass_dies: int = 0
    fail_dies: int = 0
    yield_pct: float = 0.0


class WaferEngine:
    """Core mathematical and geometric calculation engine for 300mm Wafer & Reticle mapping."""

    @staticmethod
    def calculate_gdpw_formula(diameter_mm: float, edge_exclusion_mm: float, die_w_mm: float, die_h_mm: float) -> int:
        """Closed-form GDPW approximation formula."""
        r_usable = (diameter_mm / 2.0) - edge_exclusion_mm
        if r_usable <= 0:
            return 0
        area_die = die_w_mm * die_h_mm
        if area_die <= 0:
            return 0
        term1 = (math.pi * (r_usable ** 2)) / area_die
        term2 = (math.pi * r_usable) / math.sqrt(2.0 * area_die)
        return max(0, int(term1 - term2))

    @staticmethod
    def generate_wafer_layout(wafer_cfg: WaferConfig, die_cfg: DieConfig, defect_pattern: str = "random", yield_target: float = 0.92) -> Dict[str, Any]:
        """
        Generates full 300mm wafer map with reticle stepping grid, die coordinates,
        radial zones, bin codes, parametric data, and spatial defect signatures.
        """
        r_wafer = wafer_cfg.diameter_mm / 2.0
        r_usable = r_wafer - wafer_cfg.edge_exclusion_mm

        # Reticle field dimension
        reticle_w = (die_cfg.reticle_cols * die_cfg.width_mm) + ((die_cfg.reticle_cols - 1) * die_cfg.scribe_x_mm)
        reticle_h = (die_cfg.reticle_rows * die_cfg.height_mm) + ((die_cfg.reticle_rows - 1) * die_cfg.scribe_y_mm)
        
        # Shot pitch
        pitch_x = reticle_w + die_cfg.scribe_x_mm
        pitch_y = reticle_h + die_cfg.scribe_y_mm

        # Die step pitch
        die_step_x = die_cfg.width_mm + die_cfg.scribe_x_mm
        die_step_y = die_cfg.height_mm + die_cfg.scribe_y_mm

        # Determine shot grid bounds
        max_shot_cols = int(math.ceil(r_wafer / pitch_x)) + 2
        max_shot_rows = int(math.ceil(r_wafer / pitch_y)) + 2

        dies: List[Dict[str, Any]] = []
        shots: List[Dict[str, Any]] = []
        
        # Track statistics
        gross_die_count = 0
        pass_die_count = 0
        fail_die_count = 0
        partial_die_count = 0
        
        # Reticle repeater failure map for simulation
        repeater_r = 1 if die_cfg.reticle_rows > 1 else 0
        repeater_c = 2 if die_cfg.reticle_cols > 2 else 0

        # Scratch parameters if scratch pattern selected
        scratch_p1 = (-70.0, 60.0)
        scratch_p2 = (80.0, -40.0)

        # Iterate through shot grid
        for s_row in range(-max_shot_rows, max_shot_rows + 1):
            for s_col in range(-max_shot_cols, max_shot_cols + 1):
                # Shot center on wafer in physical mm
                s_center_x = wafer_cfg.center_offset_x_mm + (s_col * pitch_x)
                s_center_y = wafer_cfg.center_offset_y_mm + (s_row * pitch_y)

                # Check shot bounding box distance to center
                s_half_w = reticle_w / 2.0
                s_half_h = reticle_h / 2.0
                s_corners = [
                    (s_center_x - s_half_w, s_center_y - s_half_h),
                    (s_center_x + s_half_w, s_center_y - s_half_h),
                    (s_center_x + s_half_w, s_center_y + s_half_h),
                    (s_center_x - s_half_w, s_center_y + s_half_h),
                ]
                
                # Check if entire shot is outside wafer
                s_min_dist = math.sqrt(s_center_x**2 + s_center_y**2) - math.sqrt(s_half_w**2 + s_half_h**2)
                if s_min_dist > r_wafer:
                    continue

                shot_id = f"S({s_row:+03d},{s_col:+03d})"
                shot_dies_list = []
                shot_pass = 0
                shot_fail = 0

                # Generate dies inside this shot field
                for r_row in range(die_cfg.reticle_rows):
                    for r_col in range(die_cfg.reticle_cols):
                        # Die local offset relative to shot center
                        local_x = -s_half_w + (r_col * die_step_x) + (die_cfg.width_mm / 2.0)
                        # Reticle row 0 is top
                        local_y = s_half_h - (r_row * die_step_y) - (die_cfg.height_mm / 2.0)

                        die_x_mm = s_center_x + local_x
                        die_y_mm = s_center_y + local_y

                        # Global integer die coordinates
                        global_die_x = s_col * die_cfg.reticle_cols + r_col
                        global_die_y = s_row * die_cfg.reticle_rows + (die_cfg.reticle_rows - 1 - r_row)

                        # Test die corners against usable wafer circle
                        d_half_w = die_cfg.width_mm / 2.0
                        d_half_h = die_cfg.height_mm / 2.0
                        corners = [
                            (die_x_mm - d_half_w, die_y_mm - d_half_h),
                            (die_x_mm + d_half_w, die_y_mm - d_half_h),
                            (die_x_mm + d_half_w, die_y_mm + d_half_h),
                            (die_x_mm - d_half_w, die_y_mm + d_half_h),
                        ]

                        inside_count = sum(1 for cx, cy in corners if math.sqrt(cx**2 + cy**2) <= r_usable)
                        center_dist = math.sqrt(die_x_mm**2 + die_y_mm**2)
                        angle_rad = math.atan2(die_y_mm, die_x_mm)
                        angle_deg = (math.degrees(angle_rad) + 360.0) % 360.0

                        status = "OUTSIDE"
                        is_yieldable = False

                        if inside_count == 4:
                            status = "FULL"
                            is_yieldable = True
                            gross_die_count += 1
                        elif inside_count > 0 or center_dist <= r_usable:
                            status = "PARTIAL"
                            partial_die_count += 1
                        else:
                            continue  # Completely outside usable area

                        # Determine die type from reticle matrix
                        die_type = "PRODUCT_DIE"
                        if r_row < len(die_cfg.die_type_matrix) and r_col < len(die_cfg.die_type_matrix[r_row]):
                            die_type = die_cfg.die_type_matrix[r_row][r_col]

                        # Simulate Defect / Binning according to pattern
                        norm_r = center_dist / r_usable
                        fail_prob = 0.04  # Baseline random failure rate

                        if defect_pattern == "edge_ring":
                            # Edge yield roll-off
                            if norm_r > 0.82:
                                fail_prob += 0.65 * ((norm_r - 0.82) / 0.18) ** 1.8
                        elif defect_pattern == "center_cluster":
                            if norm_r < 0.35:
                                fail_prob += 0.70 * (1.0 - (norm_r / 0.35)) ** 1.5
                        elif defect_pattern == "scratch":
                            # Distance to scratch line segment
                            x1, y1 = scratch_p1
                            x2, y2 = scratch_p2
                            dx = x2 - x1
                            dy = y2 - y1
                            l2 = dx*dx + dy*dy
                            if l2 > 0:
                                t = max(0, min(1, ((die_x_mm - x1)*dx + (die_y_mm - y1)*dy) / l2))
                                proj_x = x1 + t*dx
                                proj_y = y1 + t*dy
                                dist_to_scratch = math.sqrt((die_x_mm - proj_x)**2 + (die_y_mm - proj_y)**2)
                                if dist_to_scratch < 12.0:
                                    fail_prob += 0.85 * (1.0 - (dist_to_scratch / 12.0))
                        elif defect_pattern == "repeater":
                            # Systematic reticle defect in specific reticle cell
                            if r_row == repeater_r and r_col == repeater_c:
                                fail_prob = 0.95
                        elif defect_pattern == "donut":
                            # Mid-radius ring (e.g., thermal / CMP excursion)
                            if 0.45 <= norm_r <= 0.75:
                                mid_dist = abs(norm_r - 0.60) / 0.15
                                fail_prob += 0.60 * max(0.0, 1.0 - mid_dist)

                        # Random seeded evaluation
                        seed_val = (global_die_x * 73856093) ^ (global_die_y * 19349663) ^ int(norm_r * 1000)
                        rng = random.Random(seed_val)
                        is_fail = (rng.random() < fail_prob) if is_yieldable else True

                        if not is_yieldable:
                            bin_code = 99
                            bin_name = "EDGE_PARTIAL"
                            bin_quality = "NULL"
                            param_val = 0.0
                            leakage_ua = 999.0
                            test_freq = 0.0
                            defect_count = 0
                        elif not is_fail:
                            bin_code = 1
                            bin_name = "PASS_GOOD"
                            bin_quality = "PASS"
                            pass_die_count += 1
                            shot_pass += 1
                            # Realistic parametric distribution
                            param_val = round(92.0 + (1.0 - norm_r) * 7.5 + rng.gauss(0, 1.2), 2)
                            test_freq = round(3.4 + (1.0 - norm_r * 0.4) * 0.6 + rng.gauss(0, 0.08), 3)
                            leakage_ua = round(8.5 + norm_r * 4.2 + rng.gauss(0, 0.8), 2)
                            defect_count = 0 if rng.random() > 0.08 else 1
                        else:
                            # Fail bins (2: Short, 3: Open, 4: High Leakage, 5: Timing, 6: Reticle Repeater, 7: Visual Defect)
                            fail_die_count += 1
                            shot_fail += 1
                            bin_quality = "FAIL"
                            if defect_pattern == "repeater" and r_row == repeater_r and r_col == repeater_c:
                                bin_code = 6
                                bin_name = "FAIL_RETICLE_DEFECT"
                            elif norm_r > 0.85:
                                bin_code = 4
                                bin_name = "FAIL_EDGE_LEAKAGE"
                            elif rng.random() < 0.4:
                                bin_code = 2
                                bin_name = "FAIL_CORE_VOLTAGE"
                            elif rng.random() < 0.7:
                                bin_code = 5
                                bin_name = "FAIL_TIMING_MARGIN"
                            else:
                                bin_code = 7
                                bin_name = "FAIL_PARTICLE_DEFECT"
                            param_val = round(55.0 + rng.random() * 25.0, 2)
                            test_freq = round(2.1 + rng.random() * 0.9, 3)
                            leakage_ua = round(45.0 + rng.random() * 85.0, 2)
                            defect_count = rng.randint(1, 4)

                        die_uid = f"{wafer_cfg.wafer_id}-S{s_row:+02d}_{s_col:+02d}-R{r_row}_{r_col}"
                        die_dict = {
                            "die_uid": die_uid,
                            "global_x": global_die_x,
                            "global_y": global_die_y,
                            "center_x_mm": round(die_x_mm, 4),
                            "center_y_mm": round(die_y_mm, 4),
                            "width_mm": round(die_cfg.width_mm, 4),
                            "height_mm": round(die_cfg.height_mm, 4),
                            "shot_row": s_row,
                            "shot_col": s_col,
                            "reticle_row": r_row,
                            "reticle_col": r_col,
                            "die_type": die_type,
                            "status": status,
                            "is_yieldable": is_yieldable,
                            "bin_code": bin_code,
                            "bin_name": bin_name,
                            "bin_quality": bin_quality,
                            "parametric_val": param_val,
                            "test_freq_ghz": test_freq,
                            "leakage_ua": leakage_ua,
                            "defect_count": defect_count,
                            "radial_dist_mm": round(center_dist, 3),
                            "angle_deg": round(angle_deg, 2)
                        }
                        dies.append(die_dict)
                        shot_dies_list.append(die_dict)

                # Shot classification
                if shot_dies_list:
                    tot = len(shot_dies_list)
                    s_yield = (shot_pass / tot * 100.0) if tot > 0 else 0.0
                    shot_status = "FULL" if all(d["status"] == "FULL" for d in shot_dies_list) else "PARTIAL"
                    shots.append({
                        "shot_id": shot_id,
                        "shot_row": s_row,
                        "shot_col": s_col,
                        "center_x_mm": round(s_center_x, 4),
                        "center_y_mm": round(s_center_y, 4),
                        "width_mm": round(reticle_w, 4),
                        "height_mm": round(reticle_h, 4),
                        "status": shot_status,
                        "total_dies": tot,
                        "pass_dies": shot_pass,
                        "fail_dies": shot_fail,
                        "yield_pct": round(s_yield, 2)
                    })

        theoretical_gdpw = WaferEngine.calculate_gdpw_formula(
            wafer_cfg.diameter_mm, wafer_cfg.edge_exclusion_mm, die_cfg.width_mm, die_cfg.height_mm
        )
        actual_yield_pct = (pass_die_count / gross_die_count * 100.0) if gross_die_count > 0 else 0.0

        return {
            "metadata": {
                "wafer_id": wafer_cfg.wafer_id,
                "lot_id": wafer_cfg.lot_id,
                "product_id": wafer_cfg.product_id,
                "diameter_mm": wafer_cfg.diameter_mm,
                "edge_exclusion_mm": wafer_cfg.edge_exclusion_mm,
                "usable_radius_mm": round(r_usable, 3),
                "notch_angle_deg": wafer_cfg.notch_angle_deg,
                "center_offset_x_mm": wafer_cfg.center_offset_x_mm,
                "center_offset_y_mm": wafer_cfg.center_offset_y_mm,
                "theoretical_gdpw": theoretical_gdpw,
                "gross_die_count": gross_die_count,
                "pass_die_count": pass_die_count,
                "fail_die_count": fail_die_count,
                "partial_die_count": partial_die_count,
                "yield_pct": round(actual_yield_pct, 2),
                "reticle_field_w_mm": round(reticle_w, 4),
                "reticle_field_h_mm": round(reticle_h, 4),
                "reticle_rows": die_cfg.reticle_rows,
                "reticle_cols": die_cfg.reticle_cols,
                "shot_pitch_x_mm": round(pitch_x, 4),
                "shot_pitch_y_mm": round(pitch_y, 4),
                "total_shots": len(shots),
                "defect_pattern": defect_pattern
            },
            "dies": dies,
            "shots": shots
        }

    @staticmethod
    def optimize_shot_center_offset(wafer_cfg: WaferConfig, die_cfg: DieConfig, grid_steps: int = 24) -> Dict[str, Any]:
        """
        Production 2D grid search center-offset optimizer.
        Sweeps candidate (dx, dy) over one shot pitch to maximize gross good die count.
        """
        reticle_w = (die_cfg.reticle_cols * die_cfg.width_mm) + ((die_cfg.reticle_cols - 1) * die_cfg.scribe_x_mm)
        reticle_h = (die_cfg.reticle_rows * die_cfg.height_mm) + ((die_cfg.reticle_rows - 1) * die_cfg.scribe_y_mm)
        pitch_x = reticle_w + die_cfg.scribe_x_mm
        pitch_y = reticle_h + die_cfg.scribe_y_mm

        best_offset = (0.0, 0.0)
        best_gdpw = -1
        heatmap_results = []

        step_x = pitch_x / grid_steps
        step_y = pitch_y / grid_steps

        for i in range(grid_steps):
            dx = (i - grid_steps / 2.0) * step_x
            row_data = []
            for j in range(grid_steps):
                dy = (j - grid_steps / 2.0) * step_y
                test_cfg = WaferConfig(
                    diameter_mm=wafer_cfg.diameter_mm,
                    edge_exclusion_mm=wafer_cfg.edge_exclusion_mm,
                    notch_angle_deg=wafer_cfg.notch_angle_deg,
                    center_offset_x_mm=dx,
                    center_offset_y_mm=dy
                )
                res = WaferEngine.generate_wafer_layout(test_cfg, die_cfg, "random")
                gdpw = res["metadata"]["gross_die_count"]
                row_data.append({
                    "dx": round(dx, 3),
                    "dy": round(dy, 3),
                    "gdpw": gdpw
                })
                if gdpw > best_gdpw:
                    best_gdpw = gdpw
                    best_offset = (dx, dy)
            heatmap_results.append(row_data)

        return {
            "best_offset_x_mm": round(best_offset[0], 4),
            "best_offset_y_mm": round(best_offset[1], 4),
            "max_gross_die": best_gdpw,
            "baseline_gross_die": WaferEngine.generate_wafer_layout(wafer_cfg, die_cfg, "random")["metadata"]["gross_die_count"],
            "gain_dies": best_gdpw - WaferEngine.generate_wafer_layout(wafer_cfg, die_cfg, "random")["metadata"]["gross_die_count"],
            "heatmap": heatmap_results
        }

    @staticmethod
    def calculate_spatial_analytics(layout_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculates spatial autocorrelation (Moran's I), radial zone yield curve,
        angular sector yield, and reticle-local repeater signatures.
        """
        dies = layout_data["dies"]
        yieldable_dies = [d for d in dies if d["is_yieldable"]]
        if not yieldable_dies:
            return {}

        # 1. Radial Zone Yield Breakdown (10 concentric rings)
        r_max = layout_data["metadata"]["usable_radius_mm"]
        num_rings = 8
        ring_width = r_max / num_rings
        rings = [{"zone": f"Zone {i+1} ({int(i*ring_width)}-{int((i+1)*ring_width)}mm)", "radius_min": i*ring_width, "radius_max": (i+1)*ring_width, "total": 0, "pass": 0, "fail": 0, "yield_pct": 0.0, "mean_param": 0.0} for i in range(num_rings)]

        for d in yieldable_dies:
            dist = d["radial_dist_mm"]
            idx = min(num_rings - 1, int(dist / ring_width))
            rings[idx]["total"] += 1
            if d["bin_quality"] == "PASS":
                rings[idx]["pass"] += 1
            else:
                rings[idx]["fail"] += 1

        for r in rings:
            if r["total"] > 0:
                r["yield_pct"] = round((r["pass"] / r["total"]) * 100.0, 2)

        # 2. Angular Sector Yield (8 sectors: N, NE, E, SE, S, SW, W, NW)
        sector_labels = ["E (0°)", "NE (45°)", "N (90°)", "NW (135°)", "W (180°)", "SW (225°)", "S (270°)", "SE (315°)"]
        sectors = [{"sector": label, "angle_min": i * 45.0, "angle_max": (i + 1) * 45.0, "total": 0, "pass": 0, "fail": 0, "yield_pct": 0.0} for i, label in enumerate(sector_labels)]

        for d in yieldable_dies:
            ang = d["angle_deg"]
            idx = int(ang / 45.0) % 8
            sectors[idx]["total"] += 1
            if d["bin_quality"] == "PASS":
                sectors[idx]["pass"] += 1
            else:
                sectors[idx]["fail"] += 1

        for s in sectors:
            if s["total"] > 0:
                s["yield_pct"] = round((s["pass"] / s["total"]) * 100.0, 2)

        # 3. Reticle-Local Repeater Signature Matrix
        r_rows = layout_data["metadata"]["reticle_rows"]
        r_cols = layout_data["metadata"]["reticle_cols"]
        reticle_matrix = [[{"reticle_row": r, "reticle_col": c, "total": 0, "pass": 0, "fail": 0, "fail_rate_pct": 0.0} for c in range(r_cols)] for r in range(r_rows)]

        for d in yieldable_dies:
            rr = d["reticle_row"]
            rc = d["reticle_col"]
            if rr < r_rows and rc < r_cols:
                reticle_matrix[rr][rc]["total"] += 1
                if d["bin_quality"] == "PASS":
                    reticle_matrix[rr][rc]["pass"] += 1
                else:
                    reticle_matrix[rr][rc]["fail"] += 1

        for r in range(r_rows):
            for c in range(r_cols):
                tot = reticle_matrix[r][c]["total"]
                fails = reticle_matrix[r][c]["fail"]
                reticle_matrix[r][c]["fail_rate_pct"] = round((fails / tot * 100.0) if tot > 0 else 0.0, 2)

        # 4. Moran's I Spatial Autocorrelation for Failure Clustering
        # Sample subset for high performance
        sample_dies = yieldable_dies if len(yieldable_dies) <= 600 else random.sample(yieldable_dies, 600)
        n = len(sample_dies)
        vals = [1.0 if d["bin_quality"] == "FAIL" else 0.0 for d in sample_dies]
        mean_val = sum(vals) / n
        s0 = 0.0
        numerator = 0.0
        denominator = sum((v - mean_val) ** 2 for v in vals) + 1e-9

        # Bandwidth distance
        threshold_dist = 25.0  # mm
        for i in range(n):
            for j in range(i + 1, n):
                dx = sample_dies[i]["center_x_mm"] - sample_dies[j]["center_x_mm"]
                dy = sample_dies[i]["center_y_mm"] - sample_dies[j]["center_y_mm"]
                dist = math.sqrt(dx*dx + dy*dy)
                if 0 < dist <= threshold_dist:
                    w = 1.0 / dist
                    s0 += 2 * w
                    numerator += 2 * w * (vals[i] - mean_val) * (vals[j] - mean_val)

        moran_i = 0.0
        if s0 > 0 and denominator > 0:
            moran_i = (n / s0) * (numerator / denominator)

        clustering_level = "Random / Uniform"
        if moran_i > 0.35:
            clustering_level = "Severe Spatial Clustering (Scratch / Edge Ring)"
        elif moran_i > 0.15:
            clustering_level = "Moderate Clustering (Local Cluster)"
        elif moran_i < -0.1:
            clustering_level = "Dispersed / Checkerboard"

        return {
            "moran_i": round(moran_i, 4),
            "clustering_level": clustering_level,
            "radial_zones": rings,
            "angular_sectors": sectors,
            "reticle_repeater_matrix": reticle_matrix
        }

    @staticmethod
    def export_semi_e142_xml(layout_data: Dict[str, Any]) -> str:
        """Generates standard SEMI E142 Substrate Mapping XML."""
        meta = layout_data["metadata"]
        dies = layout_data["dies"]

        root = ET.Element("SubstrateMap", {
            "xmlns": "http://www.semi.org/standards/e142",
            "SchemaVersion": "1.0",
            "SubstrateId": str(meta["wafer_id"]),
            "LotId": str(meta["lot_id"]),
            "ProductId": str(meta["product_id"]),
            "SubstrateType": "Wafer300mm"
        })

        layout = ET.SubElement(root, "Layout", {
            "Diameter": f"{meta['diameter_mm']}mm",
            "EdgeExclusion": f"{meta['edge_exclusion_mm']}mm",
            "NotchOrientation": f"{meta['notch_angle_deg']}deg",
            "StepX": f"{meta['shot_pitch_x_mm']}mm",
            "StepY": f"{meta['shot_pitch_y_mm']}mm"
        })

        bin_def = ET.SubElement(root, "BinDefinitions")
        bins = [
            ("1", "PASS_GOOD", "Pass", "0"),
            ("2", "FAIL_CORE_VOLTAGE", "Fail", "1"),
            ("3", "FAIL_OPEN_SHORT", "Fail", "2"),
            ("4", "FAIL_EDGE_LEAKAGE", "Fail", "3"),
            ("5", "FAIL_TIMING_MARGIN", "Fail", "4"),
            ("6", "FAIL_RETICLE_DEFECT", "Fail", "5"),
            ("7", "FAIL_PARTICLE_DEFECT", "Fail", "6"),
            ("99", "EDGE_PARTIAL", "Null", "-1")
        ]
        for b_code, b_name, b_qual, b_rank in bins:
            ET.SubElement(bin_def, "Bin", {
                "BinCode": b_code,
                "BinName": b_name,
                "Quality": b_qual,
                "Rank": b_rank
            })

        die_records = ET.SubElement(root, "DieRecords", {"Count": str(len(dies))})
        for d in dies:
            ET.SubElement(die_records, "Die", {
                "UID": d["die_uid"],
                "X": str(d["global_x"]),
                "Y": str(d["global_y"]),
                "CenterX": str(d["center_x_mm"]),
                "CenterY": str(d["center_y_mm"]),
                "Shot": f"{d['shot_row']},{d['shot_col']}",
                "Reticle": f"{d['reticle_row']},{d['reticle_col']}",
                "Bin": str(d["bin_code"]),
                "Status": d["status"]
            })

        return ET.tostring(root, encoding="utf-8", xml_declaration=True).decode("utf-8")

    @staticmethod
    def export_semi_g85_map(layout_data: Dict[str, Any]) -> str:
        """Generates standard SEMI G85 Map Data format string."""
        meta = layout_data["metadata"]
        dies = layout_data["dies"]

        lines = [
            "# SEMI G85 Wafer Map Specification",
            f"WAFER_ID={meta['wafer_id']}",
            f"LOT_ID={meta['lot_id']}",
            f"PRODUCT_ID={meta['product_id']}",
            f"DIAMETER={meta['diameter_mm']}",
            f"NOTCH_ANGLE={meta['notch_angle_deg']}",
            f"EDGE_EXCLUSION={meta['edge_exclusion_mm']}",
            f"GROSS_DIE={meta['gross_die_count']}",
            f"PASS_DIE={meta['pass_die_count']}",
            f"YIELD_PCT={meta['yield_pct']}%",
            "[BIN_DEFINITIONS]",
            "01=PASS_GOOD",
            "02=FAIL_VOLTAGE",
            "03=FAIL_OPEN_SHORT",
            "04=FAIL_LEAKAGE",
            "05=FAIL_TIMING",
            "06=FAIL_RETICLE",
            "07=FAIL_DEFECT",
            "99=NULL_EDGE",
            "[DIE_ARRAY_CSV]"
        ]
        lines.append("GLOBAL_X,GLOBAL_Y,CENTER_X_MM,CENTER_Y_MM,SHOT_R,SHOT_C,RET_R,RET_C,BIN,STATUS")
        for d in dies:
            lines.append(f"{d['global_x']},{d['global_y']},{d['center_x_mm']},{d['center_y_mm']},{d['shot_row']},{d['shot_col']},{d['reticle_row']},{d['reticle_col']},{d['bin_code']:02d},{d['status']}")

        return "\n".join(lines)
