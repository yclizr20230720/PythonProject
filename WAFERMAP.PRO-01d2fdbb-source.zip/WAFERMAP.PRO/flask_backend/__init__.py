"""Deployable Flask application package for WAFERMAP.PRO."""
