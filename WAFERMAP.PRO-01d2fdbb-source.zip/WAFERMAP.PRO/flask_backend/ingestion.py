"""Validated CP, WAT, and KLA tabular-file parsing for WAFERMAP.PRO."""

from __future__ import annotations

import csv
import io
import math
import os
import re
from collections import Counter
from typing import Any, Iterable

from openpyxl import load_workbook


class IngestionValidationError(ValueError):
    """Raised when a source file cannot safely form a usable wafer-data overlay."""


SOURCE_TYPES = {"CP", "WAT", "KLA"}
MAX_ROWS = 150_000
MAX_COORDINATE_MM = 250.0
HEADER_ALIASES = {
    "lot_id": ("lotid", "lot", "lotno", "batch"),
    "wafer_id": ("waferid", "wafer", "waferno", "slot"),
    "product_id": ("productname", "product", "device", "partno", "partname"),
    "x_mm": ("pointxmm", "pointx", "coordx", "xmm", "xloc", "xcoord", "xpos"),
    "y_mm": ("pointymm", "pointy", "coordy", "ymm", "yloc", "ycoord", "ypos"),
    "die_x": ("diex", "diecol", "col", "xindex", "dielocx"),
    "die_y": ("diey", "dierow", "row", "yindex", "dielocy"),
    "bin_code": ("bincode", "bin", "softbin", "hardbin"),
    "bin_name": ("binname", "bintext", "binclass"),
    "bin_quality": ("binquality", "status", "resulttext"),
    "test_freq_ghz": ("freqghz", "frequencyghz", "frequency"),
    "leakage_ua": ("leakageua", "iddqua", "leakagecurrent"),
    "param_name": ("paramname", "parametername", "parameter", "param", "testname", "measname", "item"),
    "value": ("testvalue", "metrology", "measval", "value", "val", "result", "reading"),
    "unit": ("unit", "units", "dimension"),
    "spec_low": ("speclow", "lsl", "minlimit", "lowlimit"),
    "spec_target": ("spectarget", "target", "nominal"),
    "spec_high": ("spechigh", "usl", "maxlimit", "highlimit"),
    "site_id": ("siteid", "sitename", "pcmname", "pcm_site"),
    "defect_id": ("defectid", "defectno", "defectnumber"),
    "defect_class": ("defectclass", "class", "defecttype", "type"),
    "size_um": ("defectsizeum", "defectsize", "sizeum", "size", "diameter"),
    "layer": ("layer", "processlayer"),
    "cluster_id": ("clusterid", "cluster"),
}


def _normalise_header(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def _find_columns(headers: Iterable[str]) -> dict[str, str]:
    normalised = {_normalise_header(header): header for header in headers if str(header).strip()}
    mapping: dict[str, str] = {}
    for semantic, aliases in HEADER_ALIASES.items():
        for alias in aliases:
            if alias in normalised:
                mapping[semantic] = normalised[alias]
                break
    return mapping


def _text(value: Any, *, fallback: str, max_length: int = 128) -> str:
    result = str(value if value not in (None, "") else fallback).strip()
    if not result:
        result = fallback
    return result[:max_length]


def _number(row: dict[str, Any], mapping: dict[str, str], field: str, *, required: bool = False, default: float | None = None) -> float | None:
    key = mapping.get(field)
    raw = row.get(key) if key else None
    if raw in (None, ""):
        if required:
            raise IngestionValidationError(f"Missing '{field}' value.")
        return default
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise IngestionValidationError(f"'{field}' must be numeric.") from exc
    if not math.isfinite(value):
        raise IngestionValidationError(f"'{field}' must be finite.")
    return value


def _integer(row: dict[str, Any], mapping: dict[str, str], field: str, *, required: bool = False, default: int = 0) -> int:
    value = _number(row, mapping, field, required=required, default=float(default))
    assert value is not None
    if not value.is_integer():
        raise IngestionValidationError(f"'{field}' must be an integer.")
    return int(value)


def _csv_rows(content: bytes) -> list[dict[str, Any]]:
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise IngestionValidationError("CSV must use UTF-8 encoding.") from exc
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise IngestionValidationError("CSV file must include a header row.")
    return [dict(row) for row in reader if any(str(value).strip() for value in row.values())]


def _excel_rows(content: bytes) -> list[dict[str, Any]]:
    try:
        workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        worksheet = workbook.active
        values = worksheet.iter_rows(values_only=True)
        header_row = next(values, None)
        if not header_row:
            raise IngestionValidationError("Excel file must include a header row.")
        headers = [str(value or "").strip() for value in header_row]
        if not any(headers):
            raise IngestionValidationError("Excel file must include named columns.")
        return [dict(zip(headers, row, strict=False)) for row in values if any(value not in (None, "") for value in row)]
    except IngestionValidationError:
        raise
    except Exception as exc:
        raise IngestionValidationError("Excel file could not be read. Upload a valid .xlsx workbook.") from exc


def _read_rows(filename: str, content: bytes) -> tuple[list[dict[str, Any]], str]:
    extension = os.path.splitext(filename.lower())[1]
    if extension == ".csv":
        return _csv_rows(content), "CSV"
    if extension == ".xlsx":
        return _excel_rows(content), "EXCEL"
    raise IngestionValidationError("Only .csv and .xlsx source files are supported.")


def _coordinate(row: dict[str, Any], mapping: dict[str, str]) -> tuple[float, float, int, int]:
    x = _number(row, mapping, "x_mm", required=True)
    y = _number(row, mapping, "y_mm", required=True)
    assert x is not None and y is not None
    if abs(x) > MAX_COORDINATE_MM or abs(y) > MAX_COORDINATE_MM:
        raise IngestionValidationError("Coordinates must fall within ±250 mm.")
    return round(x, 4), round(y, 4), _integer(row, mapping, "die_x"), _integer(row, mapping, "die_y")


def parse_ingestion_file(source_type: str, filename: str, content: bytes) -> dict[str, Any]:
    if source_type not in SOURCE_TYPES:
        raise IngestionValidationError("source_type must be CP, WAT, or KLA.")
    rows, file_format = _read_rows(filename, content)
    if not rows:
        raise IngestionValidationError("Source file contains no data rows.")
    if len(rows) > MAX_ROWS:
        raise IngestionValidationError(f"Source file exceeds the {MAX_ROWS:,} row limit.")
    mapping = _find_columns(rows[0].keys())
    if "x_mm" not in mapping or "y_mm" not in mapping:
        raise IngestionValidationError("Source file requires Point_X_mm and Point_Y_mm coordinate columns.")
    if source_type == "CP" and "bin_code" not in mapping and "bin_quality" not in mapping:
        raise IngestionValidationError("CP source file requires BinCode or BinQuality.")
    if source_type == "WAT" and ("param_name" not in mapping or "value" not in mapping):
        raise IngestionValidationError("WAT source file requires parameter-name and test-value columns.")

    records: list[dict[str, Any]] = []
    errors = 0
    lot_id = "UNSPECIFIED-LOT"
    wafer_id = "UNSPECIFIED-WAFER"
    product_id = "UNSPECIFIED-PRODUCT"
    parameters: set[str] = set()
    values: list[float] = []
    pass_count = 0
    fail_count = 0
    repeater_count = 0
    for row_number, row in enumerate(rows, start=2):
        try:
            lot_id = _text(row.get(mapping.get("lot_id", "")), fallback=lot_id)
            wafer_id = _text(row.get(mapping.get("wafer_id", "")), fallback=wafer_id)
            product_id = _text(row.get(mapping.get("product_id", "")), fallback=product_id)
            x_mm, y_mm, die_x, die_y = _coordinate(row, mapping)
            if source_type == "CP":
                bin_code = _integer(row, mapping, "bin_code", default=1)
                raw_quality = _text(row.get(mapping.get("bin_quality", "")), fallback="")
                bin_quality = "PASS" if raw_quality.upper() == "PASS" or (not raw_quality and bin_code == 1) else "FAIL" if raw_quality.upper() == "FAIL" or bin_code != 1 else "NULL"
                bin_name = _text(row.get(mapping.get("bin_name", "")), fallback="PASS" if bin_quality == "PASS" else f"BIN_{bin_code}", max_length=256)
                parameter = _text(row.get(mapping.get("param_name", "")), fallback="CP_RESULT")
                value = _number(row, mapping, "value", default=None)
                if value is not None:
                    values.append(value)
                parameters.add(parameter)
                pass_count += int(bin_quality == "PASS")
                fail_count += int(bin_quality == "FAIL")
                records.append({"die_x": die_x, "die_y": die_y, "x_mm": x_mm, "y_mm": y_mm, "bin_code": bin_code, "bin_name": bin_name, "bin_quality": bin_quality, "param_name": parameter, "param_value": value, "param_unit": _text(row.get(mapping.get("unit", "")), fallback="", max_length=32), "test_freq_ghz": _number(row, mapping, "test_freq_ghz", default=None), "leakage_ua": _number(row, mapping, "leakage_ua", default=None)})
            elif source_type == "WAT":
                parameter = _text(row.get(mapping.get("param_name", "")), fallback="WAT_MEASUREMENT")
                value = _number(row, mapping, "value", required=True)
                assert value is not None
                spec_low = _number(row, mapping, "spec_low", default=None)
                spec_high = _number(row, mapping, "spec_high", default=None)
                raw_status = _text(row.get(mapping.get("bin_quality", "")), fallback="").upper()
                status = raw_status if raw_status in {"PASS", "WARN", "FAIL"} else "PASS" if (spec_low is None or value >= spec_low) and (spec_high is None or value <= spec_high) else "FAIL"
                parameters.add(parameter)
                values.append(value)
                pass_count += int(status == "PASS")
                fail_count += int(status == "FAIL")
                records.append({"site_id": _text(row.get(mapping.get("site_id", "")), fallback=f"SITE-{row_number}"), "die_x": die_x, "die_y": die_y, "x_mm": x_mm, "y_mm": y_mm, "param_name": parameter, "value": value, "unit": _text(row.get(mapping.get("unit", "")), fallback="UNSPECIFIED", max_length=32), "spec_low": spec_low, "spec_target": _number(row, mapping, "spec_target", default=None), "spec_high": spec_high, "status": status})
            else:
                defect_class = _text(row.get(mapping.get("defect_class", "")), fallback="UNCLASSIFIED").upper()
                cluster_id = _integer(row, mapping, "cluster_id", default=0)
                is_repeater = cluster_id == 999 or "REPEATER" in defect_class
                repeater_count += int(is_repeater)
                records.append({"defect_id": _text(row.get(mapping.get("defect_id", "")), fallback=f"DEF-{row_number}"), "die_x": die_x, "die_y": die_y, "x_mm": x_mm, "y_mm": y_mm, "size_um": max(0.01, _number(row, mapping, "size_um", default=0.1) or 0.1), "defect_class": defect_class, "layer": _text(row.get(mapping.get("layer", "")), fallback="", max_length=128), "cluster_id": cluster_id, "is_repeater": is_repeater})
        except IngestionValidationError:
            errors += 1
    if not records:
        raise IngestionValidationError("No valid records remain after schema and coordinate validation.")
    if errors > max(100, int(len(rows) * 0.05)):
        raise IngestionValidationError("Source file contains too many invalid rows; correct the schema or coordinate data before retrying.")
    mean = sum(values) / len(values) if values else 0.0
    variance = sum((value - mean) ** 2 for value in values) / len(values) if values else 0.0
    wafer_area_cm2 = math.pi * 14.7 ** 2
    summary = {"data_type": source_type, "lot_id": lot_id, "wafer_id": wafer_id, "product_name": product_id, "source_filename": filename, "file_format": file_format, "total_rows": len(rows), "valid_rows": len(records), "error_rows": errors, "parameter_names": sorted(parameters), "selected_parameter": sorted(parameters)[0] if parameters else "DEFAULT", "stats": {"gross_items": len(records), "pass_count": pass_count, "fail_count": fail_count, "yield_pct": round((pass_count / (pass_count + fail_count) * 100) if pass_count + fail_count else 0, 2), "mean_val": round(mean, 4), "min_val": round(min(values), 4) if values else 0, "max_val": round(max(values), 4) if values else 0, "std_dev": round(math.sqrt(variance), 4), "defect_count": len(records) if source_type == "KLA" else 0, "defect_density_per_cm2": round((len(records) / wafer_area_cm2) if source_type == "KLA" else 0, 4), "repeater_defect_count": repeater_count}, "detected_columns": mapping, "sample_rows": rows[:8]}
    return {"summary": summary, "records": records, "mapping": mapping}
