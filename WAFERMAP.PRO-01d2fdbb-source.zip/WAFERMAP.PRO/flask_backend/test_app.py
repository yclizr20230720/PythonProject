"""Flask API regression tests for WAFERMAP.PRO."""

from __future__ import annotations

import unittest
from io import BytesIO

from flask_backend.app import create_app
from flask_backend.ingestion import IngestionValidationError, parse_ingestion_file
from flask_backend.repository import WaferRepository


VALID_PAYLOAD = {
    "wafer_id": "TEST-W300-001",
    "lot_id": "LOT-TEST",
    "product_id": "PRODUCT-TEST",
    "diameter_mm": 300,
    "edge_exclusion_mm": 3,
    "notch_angle_deg": 270,
    "center_offset_x_mm": 0,
    "center_offset_y_mm": 0,
    "die_width_mm": 8.5,
    "die_height_mm": 10.2,
    "scribe_x_mm": 0.08,
    "scribe_y_mm": 0.08,
    "reticle_cols": 3,
    "reticle_rows": 2,
    "die_type_matrix": [["LOGIC_CORE", "LOGIC_CORE", "SRAM_CACHE"], ["LOGIC_CORE", "IO_PHY", "ANALOG_PLL"]],
    "defect_pattern": "random",
}


class FakeRepository:
    def __init__(self) -> None:
        self.sessions: list[dict] = []
        self.exports: list[dict] = []
        self.import_runs: list[dict] = []

    def save_analysis_session(self, payload, layout, spatial, *, view_mode, optimization=None):
        self.sessions.append({"payload": payload, "layout": layout, "spatial": spatial, "view_mode": view_mode})
        return {"wafer_configuration_id": 11, "reticle_layout_id": 12, "analysis_session_id": 13}

    def record_export(self, analysis_session_id, export_format, content):
        self.exports.append({"analysis_session_id": analysis_session_id, "format": export_format, "content": content})
        return 21

    def recent_sessions(self, limit):
        return [{"id": 13, "waferId": "TEST-W300-001"}][:limit]

    def start_import_run(self, source_type, filename, source_hash):
        self.import_runs.append({"id": 41, "source_type": source_type, "filename": filename, "source_hash": source_hash, "status": "PROCESSING"})
        return 41

    def finish_import_run(self, import_run_id, status, diagnostics):
        self.import_runs[-1].update({"id": import_run_id, "status": status, "diagnostics": diagnostics})

    def save_ingestion_dataset(self, source_type, parsed, storage, source_hash, byte_size, *, import_run_id):
        self.ingestion = {"source_type": source_type, "parsed": parsed, "storage": storage, "source_hash": source_hash, "byte_size": byte_size, "import_run_id": import_run_id}
        return {"dataset_id": 31, "import_run_id": import_run_id, "source_type": source_type, "summary": parsed["summary"], "storage_url": storage["url"]}

    def ingestion_overlay(self, dataset_id):
        if dataset_id != 31:
            return None
        return {"dataset": {"id": 31, "source_type": "CP", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "CP-PRODUCT", "summary": {}}, "columns": ["die_x", "die_y", "x_mm", "y_mm", "bin_code", "bin_quality"], "rows": [[0, 0, 0, 0, 1, "PASS"]]}

    def recent_ingestion_datasets(self, limit):
        return [{"id": 31, "sourceType": "CP", "waferId": "W300-CP-01"}][:limit]

    def ingestion_analysis(self, cp_dataset_id, *, wat_dataset_id=None, kla_dataset_id=None):
        if cp_dataset_id != 31:
            raise ValueError(f"Dataset #{cp_dataset_id} is not a persisted CP source.")
        if wat_dataset_id == 99 or kla_dataset_id == 99:
            raise ValueError("Selected datasets do not share the same lot, wafer identity.")
        return {
            "cp": {
                "dataset": {"id": 31, "source_type": "CP", "wafer_id": "W300-CP-01", "lot_id": "LOT-CP", "product_id": "CP-PRODUCT"},
                "total_dies": 2,
                "pass_dies": 1,
                "fail_dies": 1,
                "yield_pct": 50.0,
                "bins": [{"bin_code": 3, "bin_name": "BIN_3", "count": 1, "percent_of_fails": 100.0, "cumulative_percent": 100.0}],
                "parametrics": [{"param_name": "VTH", "param_unit": "V", "measured_rows": 2, "mean": 0.31, "std_dev": 0.02, "min": 0.29, "max": 0.33}],
                "spatial": {"coordinate_note": "Imported coordinates only.", "radial_zones": [{"zone": "Center 0–50 mm", "total_dies": 2, "pass_dies": 1, "fail_dies": 1, "yield_pct": 50.0}], "failure_components": {"component_count": 1, "cluster_count": 0, "clustered_failure_dies": 0, "isolated_failure_dies": 1, "top_clusters": []}},
                "telemetry": [{"name": "Test frequency", "unit": "GHz", "measured_rows": 0, "mean": None, "std_dev": None, "min": None, "max": None}, {"name": "Leakage", "unit": "µA", "measured_rows": 0, "mean": None, "std_dev": None, "min": None, "max": None}],
                "observed_edge_scenarios": [{"edge_exclusion_mm": 3.0, "included_dies": 2, "excluded_dies": 0, "pass_dies": 1, "fail_dies": 1, "yield_pct": 50.0}],
            },
            "wat": {"available": wat_dataset_id is not None, "dataset": None, "compatibility": {"status": "MATCHED" if wat_dataset_id else "NOT_LOADED", "message": None}, "total_measurements": 0, "fail_measurements": 0, "parameters": []},
            "kla": {"available": kla_dataset_id is not None, "dataset": None, "compatibility": {"status": "MATCHED" if kla_dataset_id else "NOT_LOADED", "message": None}, "total_defects": 0, "repeater_defects": 0, "correlations": []},
            "ocap": {"status": "REVIEW", "scope_note": "Observed source aggregates only.", "evidence": [{"category": "CP", "label": "Primary detractor", "value": "1 die", "detail": "BIN_3"}], "recommendations": ["Review the source-backed bin evidence."]},
        }

    def ingestion_dataset_catalog(self, *, source_types=None, lot_id=None, wafer_id=None, product_id=None, limit=50):
        self.catalog_request = {"source_types": source_types, "lot_id": lot_id, "wafer_id": wafer_id, "product_id": product_id, "limit": limit}
        return {
            "datasets": [{"id": 31, "sourceType": "CP", "waferId": "W300-CP-01", "lotId": "LOT-CP", "productId": "CP-PRODUCT", "originalFilename": "cp.csv", "validRows": 2, "errorRows": 0, "createdAt": None}],
            "criteria": {"source_types": ["CP", "WAT", "KLA"], "lot_ids": ["LOT-CP"], "wafer_ids": ["W300-CP-01"], "product_ids": ["CP-PRODUCT"]},
        }


class FakeStorage:
    def __init__(self) -> None:
        self.puts: list[dict] = []

    def put(self, filename, content, content_type):
        self.puts.append({"filename": filename, "content": content, "content_type": content_type})
        return {"key": "wafermap/ingestion/test_cp.csv", "url": "/manus-storage/wafermap/ingestion/test_cp.csv"}


class WaferMapApiTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.repository = FakeRepository()
        self.storage = FakeStorage()
        self.app = create_app({"TESTING": True, "WAFER_REPOSITORY": self.repository, "INGESTION_STORAGE": self.storage})
        self.client = self.app.test_client()

    def test_health_reports_persistence_availability(self) -> None:
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["status"], "ok")
        self.assertTrue(response.json["persistence_available"])

    def test_calculate_persists_only_when_requested(self) -> None:
        response = self.client.post("/api/wafer/calculate", json={**VALID_PAYLOAD, "persist": True, "view_mode": "shot_yield"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["persistence"]["analysis_session_id"], 13)
        self.assertEqual(self.repository.sessions[0]["view_mode"], "shot_yield")
        self.assertGreater(response.json["layout"]["metadata"]["gross_die_count"], 0)

    def test_calculate_rejects_invalid_reticle_matrix(self) -> None:
        response = self.client.post("/api/wafer/calculate", json={**VALID_PAYLOAD, "reticle_rows": 3})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json["error"], "validation_error")

    def test_g85_export_writes_audit_record(self) -> None:
        response = self.client.post("/api/wafer/export/semi-g85", json=VALID_PAYLOAD)
        self.assertEqual(response.status_code, 200)
        self.assertIn("text/plain", response.content_type)
        self.assertEqual(response.headers["X-Analysis-Session-Id"], "13")
        self.assertEqual(response.headers["X-Export-Record-Id"], "21")
        self.assertEqual(self.repository.exports[0]["format"], "semi_g85")

    def test_recent_sessions_returns_repository_metadata(self) -> None:
        response = self.client.get("/api/sessions/recent?limit=3")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["persistence_available"])
        self.assertEqual(response.json["sessions"][0]["id"], 13)

    def test_configuration_snapshot_separates_reticle_revision_data(self) -> None:
        snapshot = WaferRepository.configuration_snapshot(
            {**VALID_PAYLOAD, "persist": True, "view_mode": "shot_yield"}
        )
        self.assertNotIn("die_type_matrix", snapshot)
        self.assertNotIn("reticle_cols", snapshot)
        self.assertNotIn("reticle_rows", snapshot)
        self.assertNotIn("persist", snapshot)
        self.assertEqual(snapshot["diameter_mm"], 300)

    def test_json_lineage_comparison_detects_reticle_change(self) -> None:
        original = VALID_PAYLOAD["die_type_matrix"]
        changed = [["TEST_KEY", "LOGIC_CORE", "SRAM_CACHE"], ["LOGIC_CORE", "IO_PHY", "ANALOG_PLL"]]
        self.assertTrue(WaferRepository._matches_json(WaferRepository._json(original), original))
        self.assertFalse(WaferRepository._matches_json(WaferRepository._json(original), changed))

    def test_cp_parser_normalizes_die_bins_and_summary(self) -> None:
        parsed = parse_ingestion_file("CP", "cp.csv", b"LotID,WaferID,ProductName,DieX,DieY,Point_X_mm,Point_Y_mm,BinCode,BinQuality,Param_Name,Test_Value,Unit\nLOT-CP,W300-CP-01,CP-PRODUCT,0,0,0,0,1,PASS,VTH,0.35,V\nLOT-CP,W300-CP-01,CP-PRODUCT,1,0,8.5,0,3,FAIL,VTH,0.28,V\n")
        self.assertEqual(parsed["summary"]["valid_rows"], 2)
        self.assertEqual(parsed["summary"]["stats"]["pass_count"], 1)
        self.assertEqual(parsed["records"][1]["bin_quality"], "FAIL")

    def test_wat_and_kla_parser_supports_measurement_and_repeater_contracts(self) -> None:
        wat = parse_ingestion_file("WAT", "wat.csv", b"LotID,WaferID,ProductName,Site_Name,Point_X_mm,Point_Y_mm,DieX,DieY,Parameter_Name,Test_Value,Unit,Spec_Low,Spec_Target,Spec_High,Status\nLOT-W,W300-W-01,WAT-PRODUCT,PCM-01,0,0,0,0,NMOS_VTH,0.35,V,0.28,0.35,0.42,PASS\n")
        kla = parse_ingestion_file("KLA", "kla.csv", b"LotID,WaferID,ProductName,DefectID,Point_X_mm,Point_Y_mm,DieX,DieY,Defect_Class,Defect_Size_um,Layer,ClusterID\nLOT-K,W300-K-01,KLA-PRODUCT,DEF-1,2,3,0,0,RETICLE_REPEATER_MASK_DEFECT,1.2,M1,999\n")
        self.assertEqual(wat["records"][0]["status"], "PASS")
        self.assertTrue(kla["records"][0]["is_repeater"])
        self.assertEqual(kla["summary"]["stats"]["repeater_defect_count"], 1)

    def test_ingestion_upload_persists_normalized_data_and_source_file(self) -> None:
        response = self.client.post(
            "/api/ingestion/upload",
            data={"source_type": "CP", "product_id": "CP-PRODUCT", "file": (BytesIO(b"LotID,WaferID,ProductName,DieX,DieY,Point_X_mm,Point_Y_mm,BinCode,BinQuality\nLOT-CP,W300-CP-01,CP-PRODUCT,0,0,0,0,1,PASS\n"), "CP Wafer.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json["dataset"]["dataset_id"], 31)
        self.assertEqual(response.json["dataset"]["import_run_id"], 41)
        self.assertEqual(self.repository.ingestion["parsed"]["summary"]["wafer_id"], "W300-CP-01")
        self.assertEqual(self.storage.puts[0]["filename"], "CP Wafer.csv")
        self.assertEqual(self.repository.import_runs[0]["status"], "COMPLETED")

    def test_ingestion_rejects_invalid_coordinates_and_returns_overlay_data(self) -> None:
        with self.assertRaises(IngestionValidationError):
            parse_ingestion_file("KLA", "bad.csv", b"Point_X_mm,Point_Y_mm,DefectID\n999,0,DEF-1\n")
        response = self.client.get("/api/ingestion/datasets/31/overlay")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["dataset"]["source_type"], "CP")
        self.assertEqual(response.json["columns"][0], "die_x")
        self.assertEqual(self.client.get("/api/ingestion/recent?limit=2").json["datasets"][0]["id"], 31)

    def test_ingestion_analysis_returns_persisted_cp_metrics_and_validates_optional_dataset_ids(self) -> None:
        response = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=32&kla_dataset_id=33")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["cp"]["yield_pct"], 50.0)
        self.assertEqual(response.json["cp"]["bins"][0]["bin_code"], 3)
        self.assertEqual(response.json["cp"]["parametrics"][0]["param_name"], "VTH")
        self.assertEqual(response.json["cp"]["spatial"]["radial_zones"][0]["zone"], "Center 0–50 mm")
        self.assertEqual(response.json["ocap"]["status"], "REVIEW")
        invalid = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=not-a-number")
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(invalid.json["error"], "validation_error")

    def test_ingestion_analysis_rejects_cross_wafer_source_combinations(self) -> None:
        response = self.client.get("/api/ingestion/datasets/31/analysis?wat_dataset_id=99")
        self.assertEqual(response.status_code, 400)
        self.assertIn("same lot", response.json["message"])

    def test_ingestion_catalog_applies_allowlisted_criteria(self) -> None:
        response = self.client.get("/api/ingestion/catalog?source_types=CP,WAT&lot_id=LOT-CP&wafer_id=W300-CP-01&product_id=CP-PRODUCT&limit=7")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["persistence_available"])
        self.assertEqual(response.json["datasets"][0]["id"], 31)
        self.assertEqual(self.repository.catalog_request["source_types"], ["CP", "WAT"])
        self.assertEqual(self.repository.catalog_request["limit"], 7)
        invalid = self.client.get("/api/ingestion/catalog?source_types=CP,UNSUPPORTED")
        self.assertEqual(invalid.status_code, 400)

    def test_ingestion_rejects_an_excessively_invalid_source(self) -> None:
        invalid_rows = "\n".join(f"{300 + row},0,DEF-{row}" for row in range(101))
        with self.assertRaises(IngestionValidationError):
            parse_ingestion_file("KLA", "bad-many.csv", f"Point_X_mm,Point_Y_mm,DefectID\n0,0,GOOD\n{invalid_rows}\n".encode())

    def test_rejected_upload_is_retained_as_a_rejected_import_run(self) -> None:
        response = self.client.post(
            "/api/ingestion/upload",
            data={"source_type": "KLA", "file": (BytesIO(b"Point_X_mm,Point_Y_mm,DefectID\n999,0,DEF-1\n"), "bad-kla.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(self.repository.import_runs[0]["status"], "REJECTED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
