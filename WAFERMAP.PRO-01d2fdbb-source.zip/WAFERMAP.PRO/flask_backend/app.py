"""Flask API and same-origin SPA host for the deployable WAFERMAP.PRO website."""

from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
from typing import Any

from flask import Flask, Response, abort, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

try:
    from .engine import DieConfig, WaferConfig, WaferEngine
    from .ingestion import IngestionValidationError, parse_ingestion_file
    from .repository import PersistenceUnavailable, WaferRepository
    from .storage import ManagedStorage, StorageUnavailable
except ImportError:  # Supports local `python app.py` execution from the flask_backend directory.
    from engine import DieConfig, WaferConfig, WaferEngine
    from ingestion import IngestionValidationError, parse_ingestion_file
    from repository import PersistenceUnavailable, WaferRepository
    from storage import ManagedStorage, StorageUnavailable

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DIST_DIR = PROJECT_ROOT / "dist" / "public"
DEFAULT_DIE_TYPES = [["LOGIC_CORE", "LOGIC_CORE", "SRAM_CACHE"], ["LOGIC_CORE", "IO_PHY", "ANALOG_PLL"]]
VIEW_MODES = {"bin_category", "parametric_heatmap", "shot_yield", "defect_markers"}


class RequestValidationError(ValueError):
    """Raised when a request cannot safely form a wafer layout configuration."""


def _number(payload: dict[str, Any], key: str, default: float, *, minimum: float | None = None, maximum: float | None = None) -> float:
    try:
        value = float(payload.get(key, default))
    except (TypeError, ValueError) as exc:
        raise RequestValidationError(f"'{key}' must be numeric.") from exc
    if not math.isfinite(value):
        raise RequestValidationError(f"'{key}' must be finite.")
    if minimum is not None and value < minimum:
        raise RequestValidationError(f"'{key}' must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise RequestValidationError(f"'{key}' must be at most {maximum}.")
    return value


def _integer(payload: dict[str, Any], key: str, default: int, *, minimum: int, maximum: int) -> int:
    value = _number(payload, key, default, minimum=minimum, maximum=maximum)
    if not value.is_integer():
        raise RequestValidationError(f"'{key}' must be an integer.")
    return int(value)


def _text(payload: dict[str, Any], key: str, default: str, *, max_length: int) -> str:
    value = str(payload.get(key, default)).strip()
    if not value:
        raise RequestValidationError(f"'{key}' cannot be empty.")
    if len(value) > max_length:
        raise RequestValidationError(f"'{key}' must be {max_length} characters or fewer.")
    return value


def _read_payload() -> dict[str, Any]:
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise RequestValidationError("Request body must be a JSON object.")
    return payload


def _persist_requested(payload: dict[str, Any]) -> bool:
    value = payload.get("persist", False)
    if not isinstance(value, bool):
        raise RequestValidationError("'persist' must be a boolean.")
    return value


def _view_mode(payload: dict[str, Any]) -> str:
    value = _text(payload, "view_mode", "bin_category", max_length=32)
    if value not in VIEW_MODES:
        raise RequestValidationError("'view_mode' is not supported.")
    return value


def _optional_dataset_query_id(key: str) -> int | None:
    raw_value = request.args.get(key)
    if raw_value in (None, ""):
        return None
    try:
        value = int(raw_value)
    except ValueError as exc:
        raise RequestValidationError(f"'{key}' must be a positive integer.") from exc
    if value < 1:
        raise RequestValidationError(f"'{key}' must be a positive integer.")
    return value


def _catalog_text_query(key: str) -> str | None:
    value = request.args.get(key)
    if value in (None, ""):
        return None
    return _text({key: value}, key, "", max_length=128)


def _catalog_source_types() -> list[str]:
    raw_value = request.args.get("source_types", "")
    if not raw_value:
        return []
    values = [value.strip().upper() for value in raw_value.split(",") if value.strip()]
    if not values or any(value not in {"CP", "WAT", "KLA"} for value in values):
        raise RequestValidationError("'source_types' must contain only CP, WAT, or KLA.")
    return values


def _build_configs(payload: dict[str, Any]) -> tuple[WaferConfig, DieConfig, str]:
    die_type_matrix = payload.get("die_type_matrix", DEFAULT_DIE_TYPES)
    if not isinstance(die_type_matrix, list) or not die_type_matrix or not all(isinstance(row, list) and row for row in die_type_matrix):
        raise RequestValidationError("'die_type_matrix' must be a non-empty two-dimensional array.")
    reticle_cols = _integer(payload, "reticle_cols", 3, minimum=1, maximum=32)
    reticle_rows = _integer(payload, "reticle_rows", 2, minimum=1, maximum=32)
    if len(die_type_matrix) != reticle_rows or any(len(row) != reticle_cols for row in die_type_matrix):
        raise RequestValidationError("'die_type_matrix' dimensions must match 'reticle_rows' and 'reticle_cols'.")

    wafer_config = WaferConfig(
        diameter_mm=_number(payload, "diameter_mm", 300.0, minimum=25.0, maximum=450.0),
        edge_exclusion_mm=_number(payload, "edge_exclusion_mm", 3.0, minimum=0.0, maximum=25.0),
        notch_angle_deg=_number(payload, "notch_angle_deg", 270.0, minimum=0.0, maximum=360.0),
        center_offset_x_mm=_number(payload, "center_offset_x_mm", 0.0, minimum=-300.0, maximum=300.0),
        center_offset_y_mm=_number(payload, "center_offset_y_mm", 0.0, minimum=-300.0, maximum=300.0),
        wafer_id=_text(payload, "wafer_id", "W300-PROD-202608-01", max_length=128),
        lot_id=_text(payload, "lot_id", "LOT-7NM-A88", max_length=128),
        product_id=_text(payload, "product_id", "AP-ULTRA-X9", max_length=128),
    )
    if wafer_config.edge_exclusion_mm >= wafer_config.diameter_mm / 2:
        raise RequestValidationError("'edge_exclusion_mm' must be smaller than the wafer radius.")
    die_config = DieConfig(
        width_mm=_number(payload, "die_width_mm", 8.5, minimum=0.05, maximum=100.0),
        height_mm=_number(payload, "die_height_mm", 10.2, minimum=0.05, maximum=100.0),
        scribe_x_mm=_number(payload, "scribe_x_mm", 0.0, minimum=0.0, maximum=10.0),
        scribe_y_mm=_number(payload, "scribe_y_mm", 0.0, minimum=0.0, maximum=10.0),
        reticle_cols=reticle_cols,
        reticle_rows=reticle_rows,
        die_type_matrix=[[str(cell)[:64] for cell in row] for row in die_type_matrix],
    )
    return wafer_config, die_config, _text(payload, "defect_pattern", "random", max_length=64)


def create_app(test_config: dict[str, Any] | None = None) -> Flask:
    """Create a validated Flask API which also serves the React production build."""
    app = Flask(__name__)
    app.config.from_mapping(JSON_SORT_KEYS=False, MAX_CONTENT_LENGTH=20 * 1024 * 1024, FRONTEND_DIST=DIST_DIR)
    if test_config:
        app.config.update(test_config)
    repository = app.config.get("WAFER_REPOSITORY") or WaferRepository.from_environment()
    storage = app.config.get("INGESTION_STORAGE") or ManagedStorage.from_environment()

    @app.after_request
    def add_response_headers(response: Response) -> Response:
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "same-origin"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(RequestValidationError)
    def validation_error(error: RequestValidationError) -> tuple[Response, int]:
        return jsonify({"error": "validation_error", "message": str(error)}), 400

    @app.errorhandler(IngestionValidationError)
    def ingestion_validation_error(error: IngestionValidationError) -> tuple[Response, int]:
        return jsonify({"error": "ingestion_validation_error", "message": str(error)}), 400

    @app.errorhandler(StorageUnavailable)
    def storage_unavailable(error: StorageUnavailable) -> tuple[Response, int]:
        return jsonify({"error": "storage_unavailable", "message": str(error)}), 503

    @app.errorhandler(PersistenceUnavailable)
    def persistence_unavailable(error: PersistenceUnavailable) -> tuple[Response, int]:
        return jsonify({"error": "persistence_unavailable", "message": str(error)}), 503

    @app.errorhandler(413)
    def payload_too_large(_: Exception) -> tuple[Response, int]:
        return jsonify({"error": "payload_too_large", "message": "Maximum request size is 20 MB."}), 413

    @app.errorhandler(HTTPException)
    def http_error(error: HTTPException) -> Response | tuple[Response, int]:
        if request.path.startswith("/api/"):
            return jsonify({"error": error.name.lower().replace(" ", "_"), "message": error.description}), error.code
        return error

    @app.get("/api/health")
    def health() -> Response:
        return jsonify({"status": "ok", "service": "WaferMap Flask API", "frontend_build_available": Path(app.config["FRONTEND_DIST"]).is_dir(), "persistence_available": repository is not None})

    @app.get("/api/wafer/default")
    def default_wafer() -> Response:
        return jsonify(WaferEngine.generate_wafer_layout(WaferConfig(), DieConfig(), "random"))

    @app.post("/api/wafer/calculate")
    def calculate_wafer() -> Response:
        payload = _read_payload()
        wafer_config, die_config, defect_pattern = _build_configs(payload)
        layout = WaferEngine.generate_wafer_layout(wafer_config, die_config, defect_pattern)
        spatial = WaferEngine.calculate_spatial_analytics(layout)
        result: dict[str, Any] = {"layout": layout, "spatial": spatial}
        if _persist_requested(payload):
            if repository is None:
                raise PersistenceUnavailable("Persistence is not configured for this environment.")
            result["persistence"] = repository.save_analysis_session(payload, layout, spatial, view_mode=_view_mode(payload))
        return jsonify(result)

    @app.post("/api/wafer/optimize-shot")
    def optimize_shot() -> Response:
        payload = _read_payload()
        wafer_config, die_config, _ = _build_configs(payload)
        grid_steps = _integer(payload, "grid_steps", 20, minimum=4, maximum=100)
        return jsonify(WaferEngine.optimize_shot_center_offset(wafer_config, die_config, grid_steps))

    def export_response(export_format: str, mimetype: str) -> Response:
        payload = _read_payload()
        wafer_config, die_config, defect_pattern = _build_configs(payload)
        layout = WaferEngine.generate_wafer_layout(wafer_config, die_config, defect_pattern)
        spatial = WaferEngine.calculate_spatial_analytics(layout)
        content = WaferEngine.export_semi_e142_xml(layout) if export_format == "semi_e142" else WaferEngine.export_semi_g85_map(layout)
        response = Response(content, mimetype=mimetype)
        if repository is not None:
            session = repository.save_analysis_session(payload, layout, spatial, view_mode=_view_mode(payload))
            export_id = repository.record_export(session["analysis_session_id"], export_format, content)
            response.headers["X-Analysis-Session-Id"] = str(session["analysis_session_id"])
            response.headers["X-Export-Record-Id"] = str(export_id)
        return response

    @app.post("/api/wafer/export/semi-e142")
    def export_e142() -> Response:
        return export_response("semi_e142", "application/xml; charset=utf-8")

    @app.post("/api/wafer/export/semi-g85")
    def export_g85() -> Response:
        return export_response("semi_g85", "text/plain; charset=utf-8")

    @app.get("/api/sessions/recent")
    def recent_sessions() -> Response:
        if repository is None:
            return jsonify({"sessions": [], "persistence_available": False})
        limit = min(max(int(request.args.get("limit", "12")), 1), 50)
        return jsonify({"sessions": repository.recent_sessions(limit), "persistence_available": True})

    @app.post("/api/ingestion/upload")
    def upload_ingestion_file() -> Response:
        if repository is None:
            raise PersistenceUnavailable("Persistence is not configured for this environment.")
        if storage is None:
            raise StorageUnavailable("Managed source-file storage is not configured for this environment.")
        source_type = str(request.form.get("source_type", "")).strip().upper()
        source_file = request.files.get("file")
        if source_file is None or not source_file.filename:
            raise IngestionValidationError("Attach one CP, WAT, or KLA .csv/.xlsx source file.")
        filename = Path(source_file.filename).name
        content = source_file.read(app.config["MAX_CONTENT_LENGTH"] + 1)
        if len(content) > app.config["MAX_CONTENT_LENGTH"]:
            raise IngestionValidationError("Source file exceeds the 20 MB upload limit.")
        if not content:
            raise IngestionValidationError("Source file is empty.")
        source_hash = hashlib.sha256(content).hexdigest()
        import_run_id = repository.start_import_run(source_type, filename, source_hash)
        try:
            parsed = parse_ingestion_file(source_type, filename, content)
            product_override = str(request.form.get("product_id", "")).strip()
            if product_override:
                parsed["summary"]["product_name"] = _text({"product_id": product_override}, "product_id", product_override, max_length=128)
            content_type = "text/csv" if filename.lower().endswith(".csv") else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            stored = storage.put(filename, content, content_type)
            result = repository.save_ingestion_dataset(source_type, parsed, stored, source_hash, len(content), import_run_id=import_run_id)
            repository.finish_import_run(import_run_id, "COMPLETED", {"dataset_id": result["dataset_id"], "valid_rows": parsed["summary"]["valid_rows"], "error_rows": parsed["summary"]["error_rows"]})
            return jsonify({"dataset": result}), 201
        except (IngestionValidationError, StorageUnavailable, PersistenceUnavailable) as error:
            repository.finish_import_run(import_run_id, "REJECTED", {"error": str(error)[:512]})
            raise

    @app.get("/api/ingestion/datasets/<int:dataset_id>/overlay")
    def ingestion_overlay(dataset_id: int) -> Response:
        if repository is None:
            raise PersistenceUnavailable("Persistence is not configured for this environment.")
        overlay = repository.ingestion_overlay(dataset_id)
        if overlay is None:
            abort(404, description="Ingestion dataset was not found.")
        return jsonify(overlay)

    @app.get("/api/ingestion/datasets/<int:dataset_id>/analysis")
    def ingestion_analysis(dataset_id: int) -> Response:
        if repository is None:
            raise PersistenceUnavailable("Persistence is not configured for this environment.")
        try:
            result = repository.ingestion_analysis(
                dataset_id,
                wat_dataset_id=_optional_dataset_query_id("wat_dataset_id"),
                kla_dataset_id=_optional_dataset_query_id("kla_dataset_id"),
            )
        except ValueError as exc:
            raise RequestValidationError(str(exc)) from exc
        return jsonify(result)

    @app.get("/api/ingestion/recent")
    def recent_ingestion_datasets() -> Response:
        if repository is None:
            return jsonify({"datasets": [], "persistence_available": False})
        try:
            limit = min(max(int(request.args.get("limit", "12")), 1), 50)
        except ValueError as exc:
            raise RequestValidationError("'limit' must be an integer.") from exc
        return jsonify({"datasets": repository.recent_ingestion_datasets(limit), "persistence_available": True})

    @app.get("/api/ingestion/catalog")
    def ingestion_dataset_catalog() -> Response:
        if repository is None:
            return jsonify({"datasets": [], "criteria": {"source_types": [], "lot_ids": [], "wafer_ids": [], "product_ids": []}, "persistence_available": False})
        try:
            limit = min(max(int(request.args.get("limit", "50")), 1), 50)
        except ValueError as exc:
            raise RequestValidationError("'limit' must be an integer.") from exc
        catalog = repository.ingestion_dataset_catalog(
            source_types=_catalog_source_types(),
            lot_id=_catalog_text_query("lot_id"),
            wafer_id=_catalog_text_query("wafer_id"),
            product_id=_catalog_text_query("product_id"),
            limit=limit,
        )
        catalog["persistence_available"] = True
        return jsonify(catalog)

    @app.route("/", defaults={"asset_path": ""})
    @app.route("/<path:asset_path>")
    def serve_frontend(asset_path: str) -> Response | tuple[Response, int]:
        if asset_path.startswith("api/"):
            abort(404)
        frontend_dist = Path(app.config["FRONTEND_DIST"])
        if not frontend_dist.is_dir():
            return jsonify({"error": "frontend_not_built", "message": "Run 'pnpm run build' before starting the server."}), 503
        if asset_path and (frontend_dist / asset_path).is_file():
            return send_from_directory(frontend_dist, asset_path)
        return send_from_directory(frontend_dist, "index.html")

    return app


if __name__ == "__main__":
    host = os.environ.get("WAFERMAP_HOST", "127.0.0.1")
    port = int(os.environ.get("WAFERMAP_PORT", "5001"))
    create_app().run(host=host, port=port, debug=os.environ.get("WAFERMAP_DEBUG", "false").lower() == "true")
