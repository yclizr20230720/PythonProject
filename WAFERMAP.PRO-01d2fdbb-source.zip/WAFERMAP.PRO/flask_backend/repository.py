"""Small, dependency-light persistence layer for durable WaferMap audit records."""

from __future__ import annotations

import hashlib
import json
import math
import os
from collections import Counter
from contextlib import contextmanager
from typing import Any, Iterator
from urllib.parse import unquote, urlparse

import pymysql
from pymysql.cursors import DictCursor


class PersistenceUnavailable(RuntimeError):
    """Raised when a request explicitly requires persistence but no database is configured."""


class WaferRepository:
    """Persist immutable configuration, layout, reticle, and export audit snapshots."""

    def __init__(self, database_url: str):
        parsed = urlparse(database_url)
        if parsed.scheme not in {"mysql", "mysql+pymysql"} or not parsed.hostname or not parsed.path:
            raise ValueError("DATABASE_URL must be a complete MySQL connection URL.")
        self.connection_kwargs = {
            "host": parsed.hostname,
            "port": parsed.port or 3306,
            "user": unquote(parsed.username or ""),
            "password": unquote(parsed.password or ""),
            "database": parsed.path.lstrip("/"),
            "charset": "utf8mb4",
            "cursorclass": DictCursor,
            "connect_timeout": 5,
            "read_timeout": 90,
            "write_timeout": 90,
            "autocommit": False,
        }

    @classmethod
    def from_environment(cls) -> "WaferRepository | None":
        database_url = os.environ.get("DATABASE_URL", "").strip()
        return cls(database_url) if database_url else None

    @contextmanager
    def _connection(self) -> Iterator[pymysql.connections.Connection]:
        connection = pymysql.connect(**self.connection_kwargs)
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)

    @staticmethod
    def configuration_snapshot(request_payload: dict[str, Any]) -> dict[str, Any]:
        """Keep wafer/stepping settings separate from versioned reticle cell assignments."""
        reticle_keys = {"die_type_matrix", "reticle_cols", "reticle_rows", "persist", "view_mode"}
        return {key: value for key, value in request_payload.items() if key not in reticle_keys}

    @staticmethod
    def _matches_json(stored_value: Any, candidate: dict[str, Any] | list[list[str]]) -> bool:
        if isinstance(stored_value, str):
            try:
                stored_value = json.loads(stored_value)
            except json.JSONDecodeError:
                return False
        return stored_value == candidate

    def _find_or_create_configuration(self, cursor: Any, request_payload: dict[str, Any], metadata: dict[str, Any]) -> int:
        configuration = self.configuration_snapshot(request_payload)
        cursor.execute(
            """
            SELECT id, configuration
            FROM wafer_configurations
            WHERE waferId = %s AND lotId = %s AND productId = %s
            ORDER BY id DESC LIMIT 1
            """,
            (metadata["wafer_id"], metadata["lot_id"], metadata["product_id"]),
        )
        existing = cursor.fetchone()
        if existing and self._matches_json(existing["configuration"], configuration):
            return int(existing["id"])

        cursor.execute(
            """
            INSERT INTO wafer_configurations (ownerId, waferId, lotId, productId, configuration)
            VALUES (NULL, %s, %s, %s, %s)
            """,
            (metadata["wafer_id"], metadata["lot_id"], metadata["product_id"], self._json(configuration)),
        )
        return int(cursor.lastrowid)

    def _find_or_create_reticle_layout(self, cursor: Any, wafer_configuration_id: int, metadata: dict[str, Any], die_matrix: list[list[str]]) -> int:
        cursor.execute(
            """
            SELECT id, revision, columns, rows, dieTypeMatrix
            FROM reticle_layouts
            WHERE waferConfigurationId = %s
            ORDER BY revision DESC, id DESC LIMIT 1
            """,
            (wafer_configuration_id,),
        )
        existing = cursor.fetchone()
        matches_existing = bool(
            existing
            and int(existing["columns"]) == metadata["reticle_cols"]
            and int(existing["rows"]) == metadata["reticle_rows"]
            and self._matches_json(existing["dieTypeMatrix"], die_matrix)
        )
        if matches_existing:
            return int(existing["id"])

        revision = int(existing["revision"]) + 1 if existing else 1
        cursor.execute(
            """
            INSERT INTO reticle_layouts (waferConfigurationId, revision, columns, rows, dieTypeMatrix)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (wafer_configuration_id, revision, metadata["reticle_cols"], metadata["reticle_rows"], self._json(die_matrix)),
        )
        return int(cursor.lastrowid)

    def save_analysis_session(
        self,
        request_payload: dict[str, Any],
        layout: dict[str, Any],
        spatial: dict[str, Any] | None,
        *,
        view_mode: str,
        optimization: dict[str, Any] | None = None,
    ) -> dict[str, int]:
        """Create an immutable persisted session, retaining config and reticle revision context."""
        metadata = layout["metadata"]
        die_matrix = request_payload.get("die_type_matrix", [])
        with self._connection() as connection:
            with connection.cursor() as cursor:
                wafer_configuration_id = self._find_or_create_configuration(cursor, request_payload, metadata)
                reticle_layout_id = self._find_or_create_reticle_layout(
                    cursor, wafer_configuration_id, metadata, die_matrix
                )

                cursor.execute(
                    """
                    INSERT INTO analysis_sessions
                      (waferConfigurationId, reticleLayoutId, viewMode, defectPattern, layoutSnapshot, spatialSnapshot, optimizationSnapshot)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        wafer_configuration_id,
                        reticle_layout_id,
                        view_mode,
                        metadata["defect_pattern"],
                        self._json(layout),
                        self._json(spatial) if spatial is not None else None,
                        self._json(optimization) if optimization is not None else None,
                    ),
                )
                analysis_session_id = int(cursor.lastrowid)

        return {
            "wafer_configuration_id": wafer_configuration_id,
            "reticle_layout_id": reticle_layout_id,
            "analysis_session_id": analysis_session_id,
        }

    def record_export(self, analysis_session_id: int, export_format: str, content: str) -> int:
        """Store an audit record, not the potentially large exported artifact itself."""
        content_bytes = content.encode("utf-8")
        content_hash = hashlib.sha256(content_bytes).hexdigest()
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO export_records (analysisSessionId, format, contentHash, byteSize)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (analysis_session_id, export_format, content_hash, len(content_bytes)),
                )
                return int(cursor.lastrowid)

    def recent_sessions(self, limit: int = 12) -> list[dict[str, Any]]:
        """Return concise persisted-session metadata without shipping large snapshots to the browser."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT s.id, w.waferId, w.lotId, w.productId, s.viewMode, s.defectPattern, s.createdAt
                    FROM analysis_sessions AS s
                    INNER JOIN wafer_configurations AS w ON w.id = s.waferConfigurationId
                    ORDER BY s.createdAt DESC, s.id DESC
                    LIMIT %s
                    """,
                    (limit,),
                )
                return list(cursor.fetchall())

    def save_ingestion_dataset(self, source_type: str, parsed: dict[str, Any], storage: dict[str, str], source_hash: str, byte_size: int, *, import_run_id: int) -> dict[str, Any]:
        """Persist a source-file audit record and its normalized overlay points in bounded batches."""
        summary = parsed["summary"]
        records = parsed["records"]
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """INSERT INTO ingestion_datasets
                    (ownerId, importRunId, sourceType, waferId, lotId, productId, originalFilename, storageKey, storageUrl, sourceHash, byteSize, totalRows, validRows, errorRows, columnMapping, summary)
                    VALUES (NULL, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (import_run_id, source_type, summary["wafer_id"], summary["lot_id"], summary["product_name"], summary["source_filename"], storage["key"], storage["url"], source_hash, byte_size, summary["total_rows"], summary["valid_rows"], summary["error_rows"], self._json(parsed["mapping"]), self._json(summary)),
                )
                dataset_id = int(cursor.lastrowid)
                if source_type == "CP":
                    statement = """INSERT INTO cp_die_measurements (datasetId, dieX, dieY, xMm, yMm, binCode, binName, binQuality, paramName, paramValue, paramUnit, testFreqGhz, leakageUa) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item["bin_code"], item["bin_name"], item["bin_quality"], item["param_name"], item["param_value"], item["param_unit"], item["test_freq_ghz"], item["leakage_ua"]) for item in records]
                elif source_type == "WAT":
                    statement = """INSERT INTO wat_measurements (datasetId, siteId, dieX, dieY, xMm, yMm, paramName, value, unit, specLow, specTarget, specHigh, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["site_id"], item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item["param_name"], item["value"], item["unit"], item["spec_low"], item["spec_target"], item["spec_high"], item["status"]) for item in records]
                else:
                    statement = """INSERT INTO kla_defects (datasetId, defectId, dieX, dieY, xMm, yMm, sizeUm, defectClass, layer, clusterId, isRepeater) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                    values = [(dataset_id, item["defect_id"], item["die_x"], item["die_y"], item["x_mm"], item["y_mm"], item["size_um"], item["defect_class"], item["layer"], item["cluster_id"], item["is_repeater"]) for item in records]
                for start in range(0, len(values), 1000):
                    cursor.executemany(statement, values[start : start + 1000])
        return {"dataset_id": dataset_id, "import_run_id": import_run_id, "source_type": source_type, "summary": summary, "storage_url": storage["url"]}

    def start_import_run(self, source_type: str, filename: str, source_hash: str) -> int:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO import_runs (ownerId, sourceType, originalFilename, sourceHash, status) VALUES (NULL, %s, %s, %s, 'PROCESSING')",
                    (source_type, filename, source_hash),
                )
                return int(cursor.lastrowid)

    def finish_import_run(self, import_run_id: int, status: str, diagnostics: dict[str, Any]) -> None:
        if status not in {"COMPLETED", "REJECTED"}:
            raise ValueError("Import runs may only be completed or rejected.")
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE import_runs SET status = %s, diagnostics = %s, completedAt = NOW() WHERE id = %s",
                    (status, self._json(diagnostics), import_run_id),
                )

    def ingestion_overlay(self, dataset_id: int) -> dict[str, Any] | None:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id, sourceType, waferId, lotId, productId, summary FROM ingestion_datasets WHERE id = %s", (dataset_id,))
                dataset = cursor.fetchone()
                if not dataset:
                    return None
                source_type = dataset["sourceType"]
                if source_type == "CP":
                    cursor.execute("SELECT dieX, dieY, xMm, yMm, binCode, binQuality FROM cp_die_measurements WHERE datasetId = %s", (dataset_id,))
                    rows = cursor.fetchall()
                    columns = ["die_x", "die_y", "x_mm", "y_mm", "bin_code", "bin_quality"]
                    return {"dataset": {"id": dataset["id"], "source_type": source_type, "wafer_id": dataset["waferId"], "lot_id": dataset["lotId"], "product_id": dataset["productId"], "summary": json.loads(dataset["summary"]) if isinstance(dataset["summary"], str) else dataset["summary"]}, "columns": columns, "rows": [[row["dieX"], row["dieY"], row["xMm"], row["yMm"], row["binCode"], row["binQuality"]] for row in rows]}
                elif source_type == "WAT":
                    cursor.execute("SELECT siteId AS site_id, dieX AS die_x, dieY AS die_y, xMm AS x_mm, yMm AS y_mm, paramName AS param_name, value, unit, specLow AS spec_low, specTarget AS spec_target, specHigh AS spec_high, status FROM wat_measurements WHERE datasetId = %s", (dataset_id,))
                else:
                    cursor.execute("SELECT defectId AS defect_id, dieX AS die_x, dieY AS die_y, xMm AS x_mm, yMm AS y_mm, sizeUm AS size_um, defectClass AS defect_class, layer, clusterId AS cluster_id, isRepeater AS is_repeater FROM kla_defects WHERE datasetId = %s", (dataset_id,))
                summary = dataset["summary"]
                if isinstance(summary, str):
                    summary = json.loads(summary)
                return {"dataset": {"id": dataset["id"], "source_type": source_type, "wafer_id": dataset["waferId"], "lot_id": dataset["lotId"], "product_id": dataset["productId"], "summary": summary}, "records": list(cursor.fetchall())}

    @staticmethod
    def _dataset_reference(dataset: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": int(dataset["id"]),
            "source_type": dataset["sourceType"],
            "wafer_id": dataset["waferId"],
            "lot_id": dataset["lotId"],
            "product_id": dataset["productId"],
        }

    @staticmethod
    def _number_or_none(value: Any) -> float | None:
        return float(value) if value is not None else None

    @staticmethod
    def _dataset_for_source(cursor: Any, dataset_id: int, source_type: str) -> dict[str, Any]:
        cursor.execute(
            "SELECT id, sourceType, waferId, lotId, productId FROM ingestion_datasets WHERE id = %s AND sourceType = %s",
            (dataset_id, source_type),
        )
        dataset = cursor.fetchone()
        if not dataset:
            raise ValueError(f"Dataset #{dataset_id} is not a persisted {source_type} source.")
        return dataset

    @staticmethod
    def _matching_dataset_identity(primary: dict[str, Any], candidate: dict[str, Any]) -> tuple[bool, str | None]:
        mismatched_fields = [
            label
            for label, key in (("lot", "lotId"), ("wafer", "waferId"), ("product", "productId"))
            if primary.get(key) != candidate.get(key)
        ]
        if not mismatched_fields:
            return True, None
        return False, f"Selected datasets do not share the same {', '.join(mismatched_fields)} identity."

    def ingestion_analysis(self, cp_dataset_id: int, *, wat_dataset_id: int | None = None, kla_dataset_id: int | None = None) -> dict[str, Any]:
        """Aggregate existing normalized measurements without fabricating manufacturing data."""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cp_dataset = self._dataset_for_source(cursor, cp_dataset_id, "CP")
                cursor.execute(
                    """SELECT COUNT(*) AS total_dies,
                              SUM(CASE WHEN binQuality = 'PASS' THEN 1 ELSE 0 END) AS pass_dies,
                              SUM(CASE WHEN binQuality = 'FAIL' THEN 1 ELSE 0 END) AS fail_dies
                       FROM cp_die_measurements WHERE datasetId = %s""",
                    (cp_dataset_id,),
                )
                cp_totals = cursor.fetchone() or {}
                total_dies = int(cp_totals.get("total_dies") or 0)
                pass_dies = int(cp_totals.get("pass_dies") or 0)
                fail_dies = int(cp_totals.get("fail_dies") or 0)
                cursor.execute(
                    """SELECT binCode AS bin_code,
                              COALESCE(NULLIF(MAX(binName), ''), CONCAT('BIN_', binCode)) AS bin_name,
                              COUNT(*) AS count
                       FROM cp_die_measurements
                       WHERE datasetId = %s AND binQuality = 'FAIL'
                       GROUP BY binCode
                       ORDER BY count DESC, binCode ASC""",
                    (cp_dataset_id,),
                )
                running_percent = 0.0
                bins: list[dict[str, Any]] = []
                for row in cursor.fetchall():
                    count = int(row["count"])
                    percent = round((count / fail_dies * 100) if fail_dies else 0.0, 2)
                    running_percent = min(100.0, running_percent + percent)
                    bins.append(
                        {
                            "bin_code": int(row["bin_code"]),
                            "bin_name": row["bin_name"],
                            "count": count,
                            "percent_of_fails": percent,
                            "cumulative_percent": round(running_percent, 2),
                        }
                    )

                cursor.execute(
                    """SELECT paramName AS param_name, COALESCE(paramUnit, '') AS param_unit,
                              COUNT(*) AS measured_rows, AVG(paramValue) AS mean_value,
                              STDDEV_POP(paramValue) AS std_dev, MIN(paramValue) AS min_value,
                              MAX(paramValue) AS max_value
                       FROM cp_die_measurements
                       WHERE datasetId = %s AND paramValue IS NOT NULL
                       GROUP BY paramName, paramUnit
                       ORDER BY measured_rows DESC, param_name ASC, param_unit ASC
                       LIMIT 24""",
                    (cp_dataset_id,),
                )
                parametrics = [
                    {
                        "param_name": row["param_name"],
                        "param_unit": row["param_unit"],
                        "measured_rows": int(row["measured_rows"]),
                        "mean": round(self._number_or_none(row["mean_value"]), 6) if row["mean_value"] is not None else None,
                        "std_dev": round(self._number_or_none(row["std_dev"]), 6) if row["std_dev"] is not None else None,
                        "min": round(self._number_or_none(row["min_value"]), 6) if row["min_value"] is not None else None,
                        "max": round(self._number_or_none(row["max_value"]), 6) if row["max_value"] is not None else None,
                    }
                    for row in cursor.fetchall()
                ]

                # Coordinate-aware screening is deliberately computed from the imported
                # measurements only. It is not an ML classifier and does not infer a
                # fab tool or a causal mechanism from spatial proximity alone.
                radial_zone_order = ("Center 0–50 mm", "Middle 50–100 mm", "Edge 100–147 mm", "Outside 147 mm")
                radial_zones = {
                    label: {"zone": label, "total_dies": 0, "pass_dies": 0, "fail_dies": 0}
                    for label in radial_zone_order
                }
                scenario_edges = (0.0, 2.0, 3.0, 5.0, 7.0)
                scenarios = {
                    edge: {"edge_exclusion_mm": edge, "included_dies": 0, "pass_dies": 0, "fail_dies": 0}
                    for edge in scenario_edges
                }
                cursor.execute(
                    "SELECT xMm, yMm, binQuality FROM cp_die_measurements WHERE datasetId = %s",
                    (cp_dataset_id,),
                )
                for row in cursor.fetchall():
                    radius = math.hypot(float(row["xMm"]), float(row["yMm"]))
                    zone = "Center 0–50 mm" if radius < 50 else "Middle 50–100 mm" if radius < 100 else "Edge 100–147 mm" if radius <= 147 else "Outside 147 mm"
                    radial_zones[zone]["total_dies"] += 1
                    if row["binQuality"] == "PASS":
                        radial_zones[zone]["pass_dies"] += 1
                    elif row["binQuality"] == "FAIL":
                        radial_zones[zone]["fail_dies"] += 1
                    for edge, scenario in scenarios.items():
                        if radius <= 150.0 - edge:
                            scenario["included_dies"] += 1
                            if row["binQuality"] == "PASS":
                                scenario["pass_dies"] += 1
                            elif row["binQuality"] == "FAIL":
                                scenario["fail_dies"] += 1
                radial_zone_summary = [
                    {
                        **zone,
                        "yield_pct": round((zone["pass_dies"] / zone["total_dies"] * 100) if zone["total_dies"] else 0.0, 2),
                    }
                    for zone in (radial_zones[label] for label in radial_zone_order)
                ]
                observed_edge_scenarios = [
                    {
                        **scenario,
                        "excluded_dies": total_dies - scenario["included_dies"],
                        "yield_pct": round((scenario["pass_dies"] / scenario["included_dies"] * 100) if scenario["included_dies"] else 0.0, 2),
                    }
                    for scenario in (scenarios[edge] for edge in scenario_edges)
                ]

                cursor.execute(
                    """SELECT dieX, dieY, MAX(binCode) AS bin_code,
                              COALESCE(NULLIF(MAX(binName), ''), 'UNCLASSIFIED') AS bin_name
                       FROM cp_die_measurements
                       WHERE datasetId = %s AND binQuality = 'FAIL'
                       GROUP BY dieX, dieY""",
                    (cp_dataset_id,),
                )
                failed_coordinates = {
                    (int(row["dieX"]), int(row["dieY"])): {"bin_code": int(row["bin_code"]), "bin_name": row["bin_name"]}
                    for row in cursor.fetchall()
                }
                unvisited = set(failed_coordinates)
                cluster_rows: list[dict[str, Any]] = []
                isolated_failure_dies = 0
                component_count = 0
                while unvisited:
                    seed = unvisited.pop()
                    component = [seed]
                    stack = [seed]
                    while stack:
                        x, y = stack.pop()
                        for dx in (-1, 0, 1):
                            for dy in (-1, 0, 1):
                                if dx == 0 and dy == 0:
                                    continue
                                neighbor = (x + dx, y + dy)
                                if neighbor in unvisited:
                                    unvisited.remove(neighbor)
                                    stack.append(neighbor)
                                    component.append(neighbor)
                    component_count += 1
                    if len(component) < 2:
                        isolated_failure_dies += 1
                        continue
                    bins_in_component = Counter(failed_coordinates[key]["bin_code"] for key in component)
                    dominant_bin, dominant_count = bins_in_component.most_common(1)[0]
                    representative = next(value for key, value in failed_coordinates.items() if key in component and value["bin_code"] == dominant_bin)
                    xs = [key[0] for key in component]
                    ys = [key[1] for key in component]
                    cluster_rows.append(
                        {
                            "die_count": len(component),
                            "dominant_bin": dominant_bin,
                            "dominant_bin_name": representative["bin_name"],
                            "dominant_bin_count": dominant_count,
                            "die_x_min": min(xs),
                            "die_x_max": max(xs),
                            "die_y_min": min(ys),
                            "die_y_max": max(ys),
                        }
                    )
                cluster_rows.sort(key=lambda item: (-item["die_count"], item["dominant_bin"], item["die_x_min"], item["die_y_min"]))

                telemetry: list[dict[str, Any]] = []
                for column, label, unit in (("testFreqGhz", "Test frequency", "GHz"), ("leakageUa", "Leakage", "µA")):
                    cursor.execute(
                        f"""SELECT COUNT({column}) AS measured_rows, AVG({column}) AS mean_value,
                                    STDDEV_POP({column}) AS std_dev, MIN({column}) AS min_value, MAX({column}) AS max_value
                             FROM cp_die_measurements WHERE datasetId = %s AND {column} IS NOT NULL""",
                        (cp_dataset_id,),
                    )
                    telemetry_row = cursor.fetchone() or {}
                    measured_rows = int(telemetry_row.get("measured_rows") or 0)
                    telemetry.append(
                        {
                            "name": label,
                            "unit": unit,
                            "measured_rows": measured_rows,
                            "mean": round(self._number_or_none(telemetry_row["mean_value"]), 6) if telemetry_row.get("mean_value") is not None else None,
                            "std_dev": round(self._number_or_none(telemetry_row["std_dev"]), 6) if telemetry_row.get("std_dev") is not None else None,
                            "min": round(self._number_or_none(telemetry_row["min_value"]), 6) if telemetry_row.get("min_value") is not None else None,
                            "max": round(self._number_or_none(telemetry_row["max_value"]), 6) if telemetry_row.get("max_value") is not None else None,
                        }
                    )

                wat: dict[str, Any] = {"available": False, "dataset": None, "compatibility": {"status": "NOT_LOADED", "message": None}, "total_measurements": 0, "fail_measurements": 0, "parameters": []}
                if wat_dataset_id is not None:
                    wat_dataset = self._dataset_for_source(cursor, wat_dataset_id, "WAT")
                    matched, message = self._matching_dataset_identity(cp_dataset, wat_dataset)
                    if not matched:
                        raise ValueError(message or "Selected CP and WAT datasets are incompatible.")
                    cursor.execute(
                        """SELECT COUNT(*) AS total_measurements,
                                      SUM(CASE WHEN status = 'FAIL' THEN 1 ELSE 0 END) AS fail_measurements
                           FROM wat_measurements WHERE datasetId = %s""",
                        (wat_dataset_id,),
                    )
                    wat_totals = cursor.fetchone() or {}
                    cursor.execute(
                        """SELECT paramName AS param_name, unit, COUNT(*) AS count,
                                      AVG(value) AS mean_value, STDDEV_POP(value) AS std_dev,
                                      MIN(specLow) AS spec_low, MAX(specHigh) AS spec_high,
                                      SUM(CASE WHEN status = 'FAIL' THEN 1 ELSE 0 END) AS fail_count
                           FROM wat_measurements
                           WHERE datasetId = %s
                           GROUP BY paramName, unit
                           ORDER BY paramName ASC, unit ASC""",
                        (wat_dataset_id,),
                    )
                    parameters: list[dict[str, Any]] = []
                    for row in cursor.fetchall():
                        mean_value = self._number_or_none(row["mean_value"])
                        std_dev = self._number_or_none(row["std_dev"])
                        spec_low = self._number_or_none(row["spec_low"])
                        spec_high = self._number_or_none(row["spec_high"])
                        cp = cpk = None
                        if std_dev is not None and std_dev > 0 and spec_low is not None and spec_high is not None and spec_high > spec_low:
                            cp = round((spec_high - spec_low) / (6 * std_dev), 3)
                            cpu = (spec_high - mean_value) / (3 * std_dev) if mean_value is not None else None
                            cpl = (mean_value - spec_low) / (3 * std_dev) if mean_value is not None else None
                            if cpu is not None and cpl is not None:
                                cpk = round(min(cpu, cpl), 3)
                        parameters.append(
                            {
                                "param_name": row["param_name"],
                                "unit": row["unit"],
                                "count": int(row["count"]),
                                "mean": round(mean_value, 6) if mean_value is not None else None,
                                "std_dev": round(std_dev, 6) if std_dev is not None else None,
                                "spec_low": spec_low,
                                "spec_high": spec_high,
                                "cp": cp,
                                "cpk": cpk,
                                "fail_count": int(row["fail_count"] or 0),
                            }
                        )
                    wat = {
                        "available": True,
                        "dataset": self._dataset_reference(wat_dataset),
                        "compatibility": {"status": "MATCHED", "message": "Lot, wafer, and product identifiers match the active CP dataset."},
                        "total_measurements": int(wat_totals.get("total_measurements") or 0),
                        "fail_measurements": int(wat_totals.get("fail_measurements") or 0),
                        "parameters": parameters,
                    }

                kla: dict[str, Any] = {"available": False, "dataset": None, "compatibility": {"status": "NOT_LOADED", "message": None}, "total_defects": 0, "repeater_defects": 0, "correlations": []}
                if kla_dataset_id is not None:
                    kla_dataset = self._dataset_for_source(cursor, kla_dataset_id, "KLA")
                    matched, message = self._matching_dataset_identity(cp_dataset, kla_dataset)
                    if not matched:
                        raise ValueError(message or "Selected CP and KLA datasets are incompatible.")
                    cursor.execute(
                        """SELECT COUNT(*) AS total_defects,
                                      SUM(CASE WHEN isRepeater = 1 THEN 1 ELSE 0 END) AS repeater_defects
                           FROM kla_defects WHERE datasetId = %s""",
                        (kla_dataset_id,),
                    )
                    kla_totals = cursor.fetchone() or {}
                    cursor.execute(
                        """SELECT k.defectClass AS defect_class,
                                      COUNT(*) AS total_defects,
                                      COUNT(DISTINCT CONCAT(k.dieX, ':', k.dieY)) AS affected_dies,
                                      COUNT(DISTINCT CASE WHEN failed_cp.dieX IS NOT NULL THEN CONCAT(k.dieX, ':', k.dieY) END) AS killed_dies,
                                      SUM(CASE WHEN k.isRepeater = 1 THEN 1 ELSE 0 END) AS repeater_defects
                           FROM kla_defects AS k
                           LEFT JOIN (
                             SELECT DISTINCT dieX, dieY
                             FROM cp_die_measurements
                             WHERE datasetId = %s AND binQuality = 'FAIL'
                           ) AS failed_cp ON failed_cp.dieX = k.dieX AND failed_cp.dieY = k.dieY
                           WHERE k.datasetId = %s
                           GROUP BY k.defectClass
                           ORDER BY killed_dies DESC, total_defects DESC, defect_class ASC""",
                        (cp_dataset_id, kla_dataset_id),
                    )
                    correlations: list[dict[str, Any]] = []
                    for row in cursor.fetchall():
                        affected_dies = int(row["affected_dies"] or 0)
                        killed_dies = int(row["killed_dies"] or 0)
                        correlations.append(
                            {
                                "defect_class": row["defect_class"],
                                "total_defects": int(row["total_defects"]),
                                "affected_dies": affected_dies,
                                "killed_dies": killed_dies,
                                "kill_ratio_pct": round((killed_dies / affected_dies * 100) if affected_dies else 0.0, 2),
                                "repeater_defects": int(row["repeater_defects"] or 0),
                            }
                        )
                    kla = {
                        "available": True,
                        "dataset": self._dataset_reference(kla_dataset),
                        "compatibility": {"status": "MATCHED", "message": "Lot, wafer, and product identifiers match the active CP dataset."},
                        "total_defects": int(kla_totals.get("total_defects") or 0),
                        "repeater_defects": int(kla_totals.get("repeater_defects") or 0),
                        "correlations": correlations,
                    }

                primary_bin = bins[0] if bins else None
                clustered_failure_dies = sum(cluster["die_count"] for cluster in cluster_rows)
                evidence: list[dict[str, Any]] = []
                recommendations: list[str] = []
                if primary_bin is not None:
                    evidence.append({"category": "CP", "label": f"Primary detractor: bin {primary_bin['bin_code']}", "value": f"{primary_bin['count']:,} dies / {primary_bin['percent_of_fails']}% of failures", "detail": primary_bin["bin_name"]})
                    recommendations.append(f"Review the bin {primary_bin['bin_code']} disposition and the affected die coordinates before changing a test limit or process setting.")
                if clustered_failure_dies:
                    evidence.append({"category": "Spatial", "label": "Connected failure components", "value": f"{len(cluster_rows):,} multi-die components", "detail": f"{clustered_failure_dies:,} failed die coordinates are in components of two or more adjacent die sites."})
                    recommendations.append("Inspect the largest connected failure component against the wafer map; spatial adjacency is screening evidence, not a confirmed root cause.")
                if wat["available"]:
                    evidence.append({"category": "WAT", "label": "Imported WAT status", "value": f"{wat['fail_measurements']:,} out-of-spec measurements", "detail": "WAT limits and status are retained from the selected source."})
                    if wat["fail_measurements"]:
                        recommendations.append("Review WAT parameters marked FAIL alongside the CP fail-bin distribution before initiating an OCAP escalation.")
                if kla["available"] and kla["correlations"]:
                    top_correlation = kla["correlations"][0]
                    evidence.append({"category": "KLA", "label": f"Top coordinate overlap: {top_correlation['defect_class']}", "value": f"{top_correlation['kill_ratio_pct']}% kill ratio", "detail": f"{top_correlation['killed_dies']:,} failed CP coordinates overlap {top_correlation['affected_dies']:,} defect-affected dies."})
                    recommendations.append("Validate the highest KLA-to-CP coordinate overlap with image review and process traceability; overlap alone does not prove causation.")
                if not recommendations:
                    recommendations.append("No fail-bin excursion is present in the selected CP source. Retain the data lineage and continue normal monitoring.")
                ocap_status = "ATTENTION" if fail_dies and (fail_dies / total_dies * 100) >= 5 else "REVIEW" if fail_dies else "NOMINAL"

                return {
                    "cp": {
                        "dataset": self._dataset_reference(cp_dataset),
                        "total_dies": total_dies,
                        "pass_dies": pass_dies,
                        "fail_dies": fail_dies,
                        "yield_pct": round((pass_dies / total_dies * 100) if total_dies else 0.0, 2),
                        "bins": bins,
                        "parametrics": parametrics,
                        "spatial": {
                            "coordinate_note": "Radial zones and connected components use the imported x/y and die-coordinate frame. No ML classifier, reticle pitch inference, or physical cause is asserted.",
                            "radial_zones": radial_zone_summary,
                            "failure_components": {
                                "component_count": component_count,
                                "cluster_count": len(cluster_rows),
                                "clustered_failure_dies": clustered_failure_dies,
                                "isolated_failure_dies": isolated_failure_dies,
                                "top_clusters": cluster_rows[:12],
                            },
                        },
                        "telemetry": telemetry,
                        "observed_edge_scenarios": observed_edge_scenarios,
                    },
                    "wat": wat,
                    "kla": kla,
                    "ocap": {
                        "status": ocap_status,
                        "scope_note": "Decision-support triage generated from retained CP/WAT/KLA aggregates. It does not prescribe a process change or infer unavailable tool, tester, or time-series data.",
                        "evidence": evidence,
                        "recommendations": recommendations,
                    },
                }

    def recent_ingestion_datasets(self, limit: int = 12) -> list[dict[str, Any]]:
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id, sourceType, waferId, lotId, productId, originalFilename, validRows, errorRows, createdAt FROM ingestion_datasets ORDER BY createdAt DESC, id DESC LIMIT %s", (limit,))
                return list(cursor.fetchall())

    def ingestion_dataset_catalog(
        self,
        *,
        source_types: list[str] | None = None,
        lot_id: str | None = None,
        wafer_id: str | None = None,
        product_id: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return a bounded, allowlisted operational dataset catalog with facet values."""
        allowed_source_types = {"CP", "WAT", "KLA"}
        normalized_types = sorted({value for value in (source_types or []) if value in allowed_source_types})
        clauses: list[str] = []
        values: list[Any] = []
        if normalized_types:
            clauses.append("sourceType IN (" + ", ".join(["%s"] * len(normalized_types)) + ")")
            values.extend(normalized_types)
        for column, value in (("lotId", lot_id), ("waferId", wafer_id), ("productId", product_id)):
            if value:
                clauses.append(f"{column} = %s")
                values.append(value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self._connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT id, sourceType, waferId, lotId, productId, originalFilename, validRows, errorRows, createdAt FROM ingestion_datasets"
                    + where
                    + " ORDER BY createdAt DESC, id DESC LIMIT %s",
                    (*values, limit),
                )
                datasets = list(cursor.fetchall())
                cursor.execute(
                    """SELECT sourceType, lotId, waferId, productId
                       FROM ingestion_datasets
                       ORDER BY createdAt DESC, id DESC
                       LIMIT 500"""
                )
                facet_rows = cursor.fetchall()
        return {
            "datasets": datasets,
            "criteria": {
                "source_types": sorted({row["sourceType"] for row in facet_rows}),
                "lot_ids": sorted({row["lotId"] for row in facet_rows})[:100],
                "wafer_ids": sorted({row["waferId"] for row in facet_rows})[:100],
                "product_ids": sorted({row["productId"] for row in facet_rows})[:100],
            },
        }
