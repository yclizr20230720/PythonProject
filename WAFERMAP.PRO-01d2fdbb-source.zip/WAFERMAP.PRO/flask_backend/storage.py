"""Managed object-storage adapter for source-file retention in the Flask runtime."""

from __future__ import annotations

import json
import os
import re
import uuid
from typing import Any
from urllib.parse import quote
from urllib.request import Request, urlopen


class StorageUnavailable(RuntimeError):
    """Raised when an ingestion upload cannot be retained in managed object storage."""


class ManagedStorage:
    def __init__(self, forge_url: str, forge_key: str):
        self.forge_url = forge_url.rstrip("/")
        self.forge_key = forge_key

    @classmethod
    def from_environment(cls) -> "ManagedStorage | None":
        forge_url = os.environ.get("BUILT_IN_FORGE_API_URL", "").strip()
        forge_key = os.environ.get("BUILT_IN_FORGE_API_KEY", "").strip()
        return cls(forge_url, forge_key) if forge_url and forge_key else None

    def put(self, relative_key: str, content: bytes, content_type: str) -> dict[str, str]:
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", relative_key.rsplit("/", 1)[-1])[:160]
        object_key = f"wafermap/ingestion/{uuid.uuid4().hex}_{safe_name}"
        presign_url = f"{self.forge_url}/v1/storage/presign/put?path={quote(object_key)}"
        try:
            with urlopen(Request(presign_url, headers={"Authorization": f"Bearer {self.forge_key}"}), timeout=12) as response:
                payload: dict[str, Any] = json.loads(response.read().decode("utf-8"))
            upload_url = str(payload.get("url", ""))
            if not upload_url:
                raise StorageUnavailable("Managed storage returned an empty upload URL.")
            upload_request = Request(upload_url, data=content, method="PUT", headers={"Content-Type": content_type})
            with urlopen(upload_request, timeout=45) as response:
                if response.status < 200 or response.status >= 300:
                    raise StorageUnavailable(f"Managed storage rejected the source file ({response.status}).")
        except StorageUnavailable:
            raise
        except Exception as exc:  # pragma: no cover - network behavior differs by runtime
            raise StorageUnavailable("Unable to retain the source file in managed storage.") from exc
        return {"key": object_key, "url": f"/manus-storage/{object_key}"}
