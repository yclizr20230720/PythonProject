# WAFERMAP.PRO — Long-Term Operations Guide

## Deployment architecture

WAFERMAP.PRO is a single-origin production website. The React and Vite client is compiled into `dist/public`; the container then starts one Flask application through Waitress. Flask serves the static single-page application, retained wafer APIs, and durable persistence requests from the same HTTPS origin. This avoids the former Node-to-Python process bridge and eliminates browser cross-origin configuration.

| Layer | Production responsibility | Implementation |
|---|---|---|
| Presentation | Dark industrial control room, Canvas wafer map, controls and specialist panels | React 19, TypeScript, Vite, Tailwind |
| Rendering | Immediate interactive layout, pan, zoom, die selection and four viewing modes | Existing Canvas renderer plus client geometry fallback |
| Calculation API | Wafer layout, spatial analytics, shot optimization, E142 and G85 output | Flask application factory and retained Python engine |
| Persistence | Immutable saved analysis snapshots, reticle revisions and export audit records | Managed MySQL with `PyMySQL` repository layer |
| Runtime | Build frontend, serve the web app and listen on managed port | Custom Docker image, Python 3, Flask and Waitress |

## Durable data model

The initial migration creates four WaferMap-specific entities. `wafer_configurations` contains a saved geometry and production identifier snapshot. `reticle_layouts` preserves the die matrix used for a calculation. `analysis_sessions` stores the resulting layout and spatial snapshot along with the active visual mode and defect signature. `export_records` retains a SHA-256 hash and size for the emitted E142 or G85 document without duplicating potentially large file contents in the database.

Foreign keys tie the snapshots together and descending creation-time indexes support recent-session and export-audit queries. No layout is persisted during high-frequency parameter editing. A session is created only when the user selects **Save Session**, while an E142 or G85 export creates its associated audit record.

## Production environment

The managed platform supplies `DATABASE_URL` at runtime. The Dockerfile must remain in the project root because Python is required in production. It performs the complete Vite and server build inside the image, installs the pinned Flask dependencies, and starts Waitress against `${PORT}`. Do not commit `.env` files, credentials, database connection strings, or generated dependency folders.

| Service check | Expected response |
|---|---|
| `GET /api/health` | JSON with `status: "ok"`, `frontend_build_available: true`, and `persistence_available: true` |
| `POST /api/wafer/calculate` | Validated layout and spatial analysis; setting `persist: true` returns saved IDs |
| `POST /api/wafer/optimize-shot` | Best shot offset, gain and heatmap |
| `POST /api/wafer/export/semi-e142` | XML response with `X-Analysis-Session-Id` and `X-Export-Record-Id` |
| `POST /api/wafer/export/semi-g85` | Text response with matching audit headers |
| `GET /api/sessions/recent` | Concise saved-session metadata; never returns full layout snapshots |

## Performance behavior

The Canvas path remains the immediate, deterministic fallback for control movements. A debounced 180 ms request then validates the result against the Flask engine, and an abort signal supersedes obsolete requests. The Reticle Studio, Optimizer, Analytics, Export, and Die Inspector bundles load only after their user flow is opened. This keeps the initial critical JavaScript under the default large-chunk warning threshold while retaining all original controls and screen flows.

## Release procedure

Run `pnpm check`, `pnpm run build`, `pnpm test`, and `python3 -m unittest flask_backend.test_app` before every release. Inspect `GET /api/health` in the managed preview. After the project checkpoint has been created, use the **Publish** control in the website management interface to create the long-term HTTPS address. Select a custom domain there if `WAFERMAP.PRO` will be bound to an owned domain.

For local preview, the Vite development configuration forwards `/api/wafer` and `/api/sessions` to a local Flask process at port 5501. That proxy exists solely for development; the deployed container bypasses it because Flask already serves the browser and API on one origin.
