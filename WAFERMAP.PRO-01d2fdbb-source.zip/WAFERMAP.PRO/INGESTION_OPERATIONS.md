# CP, WAT & KLA Data Ingestion — Operator Guide

## Purpose

The **FAB Metrology & Defect Ingestion Studio** imports semiconductor test, metrology, and inspection data into the active WAFERMAP.PRO workspace. It preserves the control-room workflow: select the analysis perspective, choose the target product/reticle matrix, upload or load a supplied mock source, inspect validation results, then select **Ingest & Generate Wafer Map**.

| Perspective | Source purpose | Required fields | Wafer-map result |
|---|---|---|---|
| CP Wafer Sort | Die-level electrical test and hard/soft bin coverage | X/Y mm; `BinCode` or `BinQuality` | Imported bin codes replace the simulated bin color for matching die coordinates. |
| WAT Metrology | PCM / scribe-line parametric monitoring | X/Y mm; parameter name; test value | Color-coded site markers: PASS cyan, WARN amber, FAIL red. |
| KLA Defect Inspection | KLARF-compatible optical/e-beam defect information | X/Y mm | Defect markers; Cluster ID `999` and `REPEATER` classes are emphasized in amber. |

## Supported files and controls

The service accepts UTF-8 CSV and XLSX source files only. Names are sanitized before source-file retention; accepted MIME types are recorded, but the parser validates the contents rather than trusting the client-provided file name. A file is rejected if it is empty, exceeds **20 MB**, exceeds **150,000 rows**, has no X/Y coordinate columns, falls outside **±250 mm**, lacks source-specific required columns, or contains more than **5% invalid rows** (with a 100-row floor). The application returns structured JSON error codes for all rejected requests.

The CP, WAT, and KLA mock downloads use the source files supplied with the reference package. They are stored in managed object storage and follow exactly the same browser-to-API validation and persistence path as operator files.

## Field aliases and normalisation

The parser recognizes common aliases including `Point_X_mm`, `Point_Y_mm`, `DieX`, `DieY`, `BinCode`, `BinQuality`, `Parameter_Name`, `Test_Value`, `Site_Name`, `DefectID`, `Defect_Size_um`, and `ClusterID`. It normalizes each accepted record to physical millimetres and integer die coordinates; no browser-side coordinate inference is required. The import result reports detected source columns, valid/invalid counts, key statistics, and the first eight source rows for operator review.

## Persistence and lineage

Each accepted file creates an `import_runs` record in **PROCESSING** state before parsing begins. Its SHA-256 hash, source type, sanitized original filename, timestamp, final status, and concise diagnostics form an immutable operator audit trail. On success, the run becomes **COMPLETED** and links to an `ingestion_datasets` record; invalid schemas, coordinates, source files, or managed-storage failures are retained as **REJECTED** runs with a bounded diagnostic. Successful datasets retain the object key, user-visible storage URL, byte size, detected-column mapping, validation summary, and normalized records. CP rows are stored in `cp_die_measurements`, WAT rows in `wat_measurements`, and KLA rows in `kla_defects`. This design supports source traceability without storing large file payloads in MySQL.

| Dataset type | Optimized retrieval behavior |
|---|---|
| CP, including the 103,501-record reference mock | Compact columnar overlay response containing only coordinate and bin fields; avoids repeated bin-label strings. |
| WAT | Normalized site, parameter, value, specification, and status records. |
| KLA | Normalized defect, coordinate, size, class, layer, cluster, and repeater records. |

For high-density CP datasets, WAFERMAP.PRO uses a `Map` keyed by die coordinates and does not request a redundant full server-generated wafer layout. The reference 100k-die CP mock completed parsing, object retention, batch database writes, compact overlay retrieval, and browser handoff in the validated environment.

## Operator workflow

1. Select **Ingest Data** from the main toolbar.
2. Select **CP Wafer Sort**, **WAT Metrology**, or **KLA Defect Inspection**.
3. Select the matching target product. Use **HD-MICRO-100K** for the supplied high-density CP/WAT/KLA test scenario.
4. Drag a CSV/XLSX file into the drop zone, browse for a file, or select **Load & validate supplied mock**.
5. Review wafer/lot metadata, accepted and rejected rows, source metrics, and the sample table.
6. Select **Ingest & Generate Wafer Map**. The workspace resets safely and switches to the matching display mode.
7. Use **WAT** or **KLA** in the display switcher after those sources have been loaded. Use **Bin Map** to view CP bins.

## Validation record

The release suite verifies TypeScript type checking, six Vitest geometry and viewport assertions, thirteen Flask API tests, ultra-wide Canvas pan/zoom browser validation, production build, and a browser workflow that ingests the supplied **100k CP**, **WAT**, and **KLA** mock sources. The browser workflow also verifies the WAT and KLA mode controls after data handoff.
