"""
Mock KLA wafer defect inspection dataset (Klarity Defect / ADC-style export).
Per-defect records with wafer coordinates, in-die (reticle-relative)
coordinates, ADC classification, and killer-defect flagging.

Same LOT_ID / WAFER_ID keys as cp_die_level_testdata.csv and
wat_site_level_testdata.csv -> full CP <-> WAT <-> KLA yield-loss chain.

Embedded ground truth (physical, inspectable causes only -- parametric-only
excursions like TW2602.3 implant Vt shift and TW2606.7 IDDQ/tester drift
leave NO defect signature here, which is itself a useful negative control):

  TW2603.4  1 wafer has a mechanical handler SCRATCH (linear defect string)
            crossing the edge; rest of lot has elevated EDGE_CHIP/RESIDUE
            in the outer ring                          -> matches CP SB12
  TW2604.5  4 wafers show a CENTER cluster of CMP_DISHING / CMP_RESIDUE
            defects near wafer center                   -> matches CP SB41
  TW2605.6  SYSTEMATIC REPEATER: a PATTERN_BRIDGE defect recurs at the same
            in-die (reticle) X/Y position across nearly every die/wafer
                                                          -> matches CP SB61
  TW2601.2, TW2602.3, TW2606.7, TW2607.8  background particle density only
            (their yield loss is probe-card / implant / tester / retest --
            not a physical, inspectable defect)
"""
import numpy as np, pandas as pd, math
from datetime import datetime, timedelta

rng = np.random.default_rng(4242)

WAFER_D, EDGE_EXCL = 300.0, 3.0
DIE_W, DIE_H = 8.0, 8.4
RET_COLS, RET_ROWS = 3, 4
DIE_AREA_CM2 = (DIE_W*DIE_H)/100.0

# ---------- rebuild the same die grid used in the CP file ----------
nx = int(WAFER_D // DIE_W); ny = int(WAFER_D // DIE_H)
dies = []
for iy in range(ny):
    for ix in range(nx):
        cx = (ix - nx/2 + 0.5) * DIE_W
        cy = (iy - ny/2 + 0.5) * DIE_H
        r_corner = max(math.hypot(cx+sx*DIE_W/2, cy+sy*DIE_H/2)
                       for sx in (-1, 1) for sy in (-1, 1))
        if r_corner <= WAFER_D/2 - EDGE_EXCL:
            dies.append((ix, iy, cx, cy, math.hypot(cx, cy)))
dies.sort(key=lambda d: (d[1], d[0]))
DIE_DF = pd.DataFrame(dies, columns=["DIE_X","DIE_Y","CTR_X","CTR_Y","RADIUS_MM"])
DIE_DF["RADIUS_NORM"] = DIE_DF.RADIUS_MM/(WAFER_D/2)
DIE_DF["THETA_DEG"] = (np.degrees(np.arctan2(DIE_DF.CTR_Y, DIE_DF.CTR_X))+360) % 360
DIE_DF["ZONE"] = np.where(DIE_DF.RADIUS_NORM<.40,"CENTER",np.where(DIE_DF.RADIUS_NORM<.80,"MIDDLE","EDGE"))
DIE_DF["RADIAL_RING"] = np.clip((DIE_DF.RADIUS_NORM*5).astype(int)+1,1,5)
DIE_DF["RETICLE_COL"] = DIE_DF.DIE_X // RET_COLS
DIE_DF["RETICLE_ROW"] = DIE_DF.DIE_Y // RET_ROWS
DIE_DF["RETICLE_SHOT_ID"] = [f"S{c:02d}{r:02d}" for c,r in zip(DIE_DF.RETICLE_COL, DIE_DF.RETICLE_ROW)]
DIE_DF["IN_RET_X"] = DIE_DF.DIE_X % RET_COLS
DIE_DF["IN_RET_Y"] = DIE_DF.DIE_Y % RET_ROWS
GROSS = len(DIE_DF)

# ---------- ADC class table ----------
CLASSES = [
 (10,"PARTICLE_SMALL","Particle",     "BRIGHT", 0.55, False),
 (11,"PARTICLE_LARGE","Particle",     "BRIGHT", 0.06, True ),
 (20,"RESIDUE",       "Residue",      "BRIGHT", 0.10, False),
 (21,"ORGANIC_RESIDUE","Residue",     "BRIGHT", 0.05, False),
 (30,"SCRATCH",       "Mechanical",   "DARK",   0.02, True ),
 (31,"EDGE_CHIP",     "Mechanical",   "DARK",   0.05, False),
 (40,"PATTERN_BRIDGE","Pattern_Fail", "DARK",   0.03, True ),
 (41,"MISSING_PATTERN","Pattern_Fail","DARK",   0.02, True ),
 (42,"VOID",          "Pattern_Fail", "DARK",   0.02, True ),
 (50,"CMP_DISHING",   "CMP_Related",  "BRIGHT", 0.03, True ),
 (51,"CMP_RESIDUE",   "CMP_Related",  "BRIGHT", 0.03, False),
 (60,"DISCOLORATION", "Film",         "BRIGHT", 0.03, False),
 (61,"COP",           "Crystal",      "DARK",   0.02, False),
 (70,"UNKNOWN",       "Unclassified", "BRIGHT", 0.02, False),
]
CDF = pd.DataFrame(CLASSES, columns=["CLASS_CODE","CLASS_NAME","CLASS_GROUP","POLARITY","BASE_WEIGHT","KILLER_DEFAULT"])
# systematic/mechanical signature classes (scratch, pattern-fail, CMP) are injected
# explicitly per lot below and must NOT also leak in as random background defects
SIGNATURE_CODES = {30, 40, 41, 42, 50, 51}
BG_CDF = CDF[~CDF.CLASS_CODE.isin(SIGNATURE_CODES)].copy()
BG_CDF["BASE_WEIGHT"] = BG_CDF.BASE_WEIGHT/BG_CDF.BASE_WEIGHT.sum()

LOTS = [f"TW{2600+i:04d}.{i%9+1}" for i in range(8)]
TOOLS = ["KLA-2920","KLA-2925","KLA-3920"]
RECIPES = {"KLA-2920":"BF_M1_STD_R14","KLA-2925":"BF_M1_STD_R14","KLA-3920":"DF_CONT_HR_R08"}
LAYERS = ["POLY_GATE","CONT","M1","VIA1","M2"]

rows = []
t0 = datetime(2026, 7, 30, 7, 40, 0)

for li, lot in enumerate(LOTS):
    layer = LAYERS[li % len(LAYERS)]
    tool = TOOLS[li % 3]
    recipe = RECIPES[tool]
    scratch_w = rng.integers(1, 26) if lot == "TW2603.4"[:0]+lot else -1  # placeholder overwritten below
    is_scratch_lot = (lot == "TW2603.4")
    is_cmp_lot     = (lot == "TW2604.5")
    is_repeater_lot= (lot == "TW2605.6")
    scratch_w = rng.integers(1, 26) if is_scratch_lot else -1
    ctr_wafers = set(rng.choice(np.arange(1,26), 4, replace=False)) if is_cmp_lot else set()
    if is_repeater_lot:
        rep_rx, rep_ry = 1, 1     # in-reticle coordinate that repeats
    lot_haze = rng.uniform(0.85, 1.25)

    for w in range(1, 26):
        wafer_id = f"{lot}-{w:02d}"
        inspect_t = t0 + timedelta(days=li*2, minutes=int(w*33+rng.integers(0,7)))
        d = DIE_DF.copy()

        # ---------- background particle/residue defect field ----------
        bg_n = rng.poisson(GROSS*0.11*lot_haze)
        bg_idx = rng.integers(0, GROSS, bg_n)
        cls_idx = rng.choice(len(BG_CDF), size=bg_n, p=BG_CDF.BASE_WEIGHT.values)
        bg = d.iloc[bg_idx].reset_index(drop=True)
        bg["CLASS_CODE"] = BG_CDF.CLASS_CODE.values[cls_idx]
        # edge-biased for TW2603.4 outer ring (non-scratch-wafer residue/chip elevation)
        if is_scratch_lot:
            edge_extra_n = rng.poisson(30)
            edge_pool = d[d.ZONE=="EDGE"]
            if len(edge_pool) and edge_extra_n:
                extra = edge_pool.sample(edge_extra_n, replace=True, random_state=rng.integers(1e9))
                extra = extra.copy()
                extra["CLASS_CODE"] = rng.choice([20,21,31], size=len(extra), p=[.45,.25,.30])
                bg = pd.concat([bg, extra], ignore_index=True)

        sig_frames = [bg]

        # ---------- scratch signature (one wafer, linear defect string) ----------
        if is_scratch_lot and w == scratch_w:
            m, b = rng.uniform(-1.1,1.1), rng.uniform(-30,30)
            dist = np.abs(m*d.CTR_X - d.CTR_Y + b)/math.sqrt(m**2+1)
            hit = d[dist < 6.0]
            if len(hit):
                sc = hit.sample(min(len(hit), rng.integers(18,30)), random_state=rng.integers(1e9)).copy()
                sc["CLASS_CODE"] = 30
                sig_frames.append(sc)

        # ---------- CMP center-cluster signature ----------
        if is_cmp_lot and w in ctr_wafers:
            ctr_pool = d[d.RADIUS_NORM < 0.28]
            if len(ctr_pool):
                n_ctr = rng.integers(25,45)
                cc = ctr_pool.sample(min(len(ctr_pool),n_ctr), replace=len(ctr_pool)<n_ctr,
                                     random_state=rng.integers(1e9)).copy()
                cc["CLASS_CODE"] = rng.choice([50,51], size=len(cc), p=[.6,.4])
                sig_frames.append(cc)

        # ---------- systematic reticle repeater ----------
        if is_repeater_lot:
            rep_pool = d[(d.IN_RET_X==rep_rx)&(d.IN_RET_Y==rep_ry)]
            hit_rate = 0.85
            hit_mask = rng.random(len(rep_pool)) < hit_rate
            rp = rep_pool[hit_mask].copy()
            if len(rp):
                rp["CLASS_CODE"] = 40
                sig_frames.append(rp)

        wdf = pd.concat(sig_frames, ignore_index=True)
        wdf = wdf.merge(CDF[["CLASS_CODE","CLASS_NAME","CLASS_GROUP","POLARITY","KILLER_DEFAULT"]],
                        on="CLASS_CODE", how="left")
        n = len(wdf)
        # in-die (reticle-relative) micro-coordinates, um, for repeater/overlay analysis
        wdf["XINDIE_UM"] = np.round((wdf.IN_RET_X + rng.uniform(0.15,0.85,n))*DIE_W*1000/RET_COLS*0+
                                     (rng.uniform(0.05,0.95,n))*DIE_W*1000, 1)
        wdf["YINDIE_UM"] = np.round((rng.uniform(0.05,0.95,n))*DIE_H*1000, 1)
        wdf["XREL_UM"] = np.round(wdf.CTR_X*1000 + rng.uniform(-DIE_W*500,DIE_W*500,n)*0.9, 1)
        wdf["YREL_UM"] = np.round(wdf.CTR_Y*1000 + rng.uniform(-DIE_H*500,DIE_H*500,n)*0.9, 1)
        wdf["DEFECT_SIZE_UM"] = np.round(np.exp(rng.normal(-0.55,0.75,n)).clip(0.08,25), 3)
        wdf.loc[wdf.CLASS_CODE.isin([30,40,41,50]), "DEFECT_SIZE_UM"] *= rng.uniform(3,9,
                                    (wdf.CLASS_CODE.isin([30,40,41,50])).sum())
        wdf["DEFECT_AREA_UM2"] = np.round(math.pi*(wdf.DEFECT_SIZE_UM/2)**2, 3)
        wdf["ADC_CONFIDENCE_PCT"] = np.round(rng.uniform(62,99.5,n),1)
        wdf["DEFECT_SOURCE"] = np.where(wdf.ADC_CONFIDENCE_PCT>85, "ADC",
                                np.where(wdf.ADC_CONFIDENCE_PCT>70,"ADC_REVIEWED","SEM_MANUAL"))
        wdf["REVIEW_STATUS"] = np.where(wdf.DEFECT_SOURCE=="SEM_MANUAL","REVIEWED","AUTO")
        # killer flag: default by class, promoted to killer if it lands in active die area near center-weighted risk
        rand_kill = rng.random(n) < 0.04
        wdf["KILLER_FLAG"] = np.where(wdf.KILLER_DEFAULT | rand_kill, "Y", "N")
        wdf["SEM_IMAGE_ID"] = [f"SEM_{wafer_id}_{i:05d}.jpg" if src!="ADC" else ""
                               for i, src in zip(range(n), wdf.DEFECT_SOURCE)]
        tstamps = [inspect_t + timedelta(seconds=int(x)) for x in np.cumsum(rng.uniform(0.4,2.2,n))]
        wdf["DEFECT_ID"] = [f"{wafer_id}-D{i:05d}" for i in range(1,n+1)]
        wdf["LOT_ID"], wdf["WAFER_ID"], wdf["WAFER_NO"] = lot, wafer_id, w
        wdf["INSPECTION_TOOL"], wdf["INSPECTION_RECIPE"], wdf["LAYER"] = tool, recipe, layer
        wdf["INSPECTION_STEP"] = f"{layer}_INSP"
        wdf["SAMPLING_PLAN"] = "100PCT" if li % 3 else "EVERY_OTHER_DIE"
        wdf["INSPECTION_TIME"] = [t.strftime("%Y-%m-%d %H:%M:%S") for t in tstamps]
        wdf["WAFER_SIZE_MM"] = 300
        rows.append(wdf)

df = pd.concat(rows, ignore_index=True)
df = df.rename(columns={"CTR_X":"DIE_CENTER_X_MM","CTR_Y":"DIE_CENTER_Y_MM"})
df["RADIUS_MM"] = df.RADIUS_MM.round(3)
df["RADIUS_NORM"] = df.RADIUS_NORM.round(4)
df["THETA_DEG"] = df.THETA_DEG.round(2)

cols = ["DEFECT_ID","LOT_ID","WAFER_ID","WAFER_NO","INSPECTION_TOOL","INSPECTION_RECIPE",
        "INSPECTION_STEP","LAYER","SAMPLING_PLAN","INSPECTION_TIME","WAFER_SIZE_MM",
        "DIE_X","DIE_Y","DIE_CENTER_X_MM","DIE_CENTER_Y_MM","RADIUS_MM","RADIUS_NORM",
        "THETA_DEG","ZONE","RADIAL_RING","RETICLE_COL","RETICLE_ROW","RETICLE_SHOT_ID",
        "IN_RET_X","IN_RET_Y","XREL_UM","YREL_UM","XINDIE_UM","YINDIE_UM",
        "DEFECT_SIZE_UM","DEFECT_AREA_UM2","POLARITY","CLASS_CODE","CLASS_NAME","CLASS_GROUP",
        "DEFECT_SOURCE","ADC_CONFIDENCE_PCT","REVIEW_STATUS","KILLER_FLAG","SEM_IMAGE_ID"]
df = df[cols]
df.to_csv("/mnt/user-data/outputs/kla_defect_data.csv", index=False)

# ---------- wafer-level defect summary ----------
g = df.groupby(["LOT_ID","WAFER_ID","WAFER_NO","INSPECTION_TOOL","LAYER"], as_index=False)
summ = g.agg(TOTAL_DEFECTS=("DEFECT_ID","count"),
            KILLER_DEFECTS=("KILLER_FLAG", lambda s:(s=="Y").sum()),
            TOP_CLASS=("CLASS_NAME", lambda s: s.value_counts().idxmax()),
            MEAN_SIZE_UM=("DEFECT_SIZE_UM","mean"))
summ["DEFECT_DENSITY_PER_CM2"] = (summ.TOTAL_DEFECTS/(GROSS*DIE_AREA_CM2)).round(4)
summ["KILLER_DENSITY_PER_CM2"] = (summ.KILLER_DEFECTS/(GROSS*DIE_AREA_CM2)).round(4)
for cc,name in [(30,"SCRATCH_QTY"),(40,"PATTERN_BRIDGE_QTY"),(50,"CMP_DISHING_QTY"),(51,"CMP_RESIDUE_QTY")]:
    c = df[df.CLASS_CODE==cc].groupby("WAFER_ID").size()
    summ[name] = summ.WAFER_ID.map(c).fillna(0).astype(int)
summ.round(4).to_csv("/mnt/user-data/outputs/kla_wafer_defect_summary.csv", index=False)

# ---------- class / Pareto reference ----------
CDF.drop(columns=["BASE_WEIGHT"]).to_csv("/mnt/user-data/outputs/kla_defect_class_definition.csv", index=False)

print(len(df),"defect rows |",df.WAFER_ID.nunique(),"wafers")
print(df.groupby("LOT_ID").size().to_string())
print(df[df.KILLER_FLAG=="Y"].groupby("LOT_ID").size().to_string())
