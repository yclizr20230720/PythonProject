# WAT Yield Engineering Mock Data — Data Dictionary

## Overview

| Field | Value |
|---|---|
| **File** | `wat_yield_mock_data.csv` |
| **Grain** | One row per WAT/PCM site per wafer |
| **Total Records** | 435 WAT site records |
| **Lots** | 3 (L3501, L3502, L3503) |
| **Wafers** | 15 (5 per lot) |
| **WAT Sites per Wafer** | 29 (7x7 grid masked to circle) |
| **Wafer Size** | 300mm |
| **Edge Exclusion** | 5mm |
| **Columns** | 81 |

**Key difference from CP:** WAT tests Process Control Monitor (PCM) structures in scribe lines, not functional product dies. Typically 20-30 sampled sites per wafer (vs thousands of dies in CP). WAT focuses on process parametric measurements and wafer-level acceptance/release decisions.

---

## Column Definitions

### 1. Lot / Wafer Hierarchy

| Column | Type | Description |
|---|---|---|
| `lot_id` | String | Lot identifier (e.g., L3501) |
| `product_id` | String | Product name (e.g., PROD-7NM-ASIC-A) |
| `process_node` | String | Process technology node (7nm, 5nm, 12nm) |
| `fab` | String | Fabrication facility |
| `technology` | String | Technology platform code (N7, N5, N12) |
| `wafer_id` | String | Wafer identifier (e.g., L3501-W01) |
| `wafer_slot` | Integer | Wafer slot position in lot (1-5) |
| `route_step` | String | Manufacturing route step (WAT) |
| `wat_step` | String | WAT test step (WAT1) |
| `test_program` | String | WAT test program name |
| `test_program_rev` | String | Test program version |
| `operator_id` | String | Operator ID |

### 2. WAT / PCM Location

| Column | Type | Description |
|---|---|---|
| `wat_site_id` | String | Unique WAT site identifier |
| `pcm_site_name` | String | PCM site name (grid-based) |
| `test_key_id` | String | Test key/structure identifier |
| `test_structure_type` | String | PCM structure type — always `PCM_SITE_SUITE` (each row summarizes a full WAT test suite at one site) |
| `die_x` | Integer | Adjacent die column |
| `die_y` | Integer | Adjacent die row |
| `adjacent_die_id` | String | Nearest product die ID (for CP cross-reference) |
| `scribe_lane` | String | Scribe lane designation |
| `scribe_orientation` | String | HORIZONTAL or VERTICAL |
| `wafer_x_mm` | Float | Site X coordinate in mm |
| `wafer_y_mm` | Float | Site Y coordinate in mm |
| `radius_mm` | Float | Distance from wafer center in mm |
| `wafer_zone` | String | CENTER / MID / EDGE |
| `quadrant` | String | Wafer quadrant (Q1-Q4) |
| `reticle_x` | Integer | Reticle column |
| `reticle_y` | Integer | Reticle row |
| `edge_site_flag` | Integer | 1 = edge site, 0 = interior |

#### Test Structure Types

Each WAT site row represents a full PCM test suite (`PCM_SITE_SUITE`) containing measurements from multiple test structures (NMOS FET, PMOS FET, Van der Pauw, contact/via chains, MOSCAP, junction diode, ring oscillator, metal serpentine). The `test_structure_type` column is set to `PCM_SITE_SUITE` for all rows to indicate this is a composite site summary, not a single structure measurement.

| Structure | Description |
|---|---|
| `NMOS_FET` | NMOS transistor parametric test structure |
| `PMOS_FET` | PMOS transistor parametric test structure |
| `VAN_DER_PAUW` | Van der Pauw sheet resistance structure |
| `CONTACT_CHAIN` | Contact chain resistance structure |
| `VIA_CHAIN` | Via chain resistance structure |
| `MOSCAP` | MOS capacitor for oxide characterization |
| `JUNCTION_DIODE` | Junction diode for leakage/BV measurement |
| `RING_OSC` | Ring oscillator for speed characterization |
| `METAL_SERPENTINE` | Metal serpentine for linewidth/resistance |

### 3. Test Execution

| Column | Type | Description |
|---|---|---|
| `test_start_time` | DateTime | Test start timestamp |
| `tester_id` | String | Parametric tester ID |
| `prober_id` | String | Wafer prober ID |
| `probe_card_id` | String | WAT probe card ID |
| `chuck_temperature_c` | Float | Chuck temperature in °C |
| `test_time_sec` | Integer | Test duration in seconds |
| `retest_flag` | Integer | 1 = retested, 0 = first test |

### 4. Wafer Acceptance / Yield

| Column | Type | Description |
|---|---|---|
| `site_pass_fail` | String | PASS or FAIL (per site) |
| `spec_violation_count` | Integer | Number of parameters out of spec |
| `critical_violation_count` | Integer | Number of critical parameters out of spec |
| `wat_bin` | Integer | 1 = PASS, 2 = Critical FAIL, 3 = Non-critical FAIL |
| `wat_fail_category` | String | Failure category (see below) |
| `first_fail_parameter` | String | First parameter that failed spec |
| `wafer_acceptance_status` | String | Wafer-level: PASS / HOLD / REJECT |
| `param_outlier_flag` | Integer | 1 = parametric outlier detected |
| `process_excursion_pattern` | String | Process excursion annotation |

#### Wafer Acceptance Logic

| Status | Condition |
|---|---|
| **PASS** | Fail rate <= 15% AND critical violations < 2 |
| **HOLD** | Fail rate 15-30% OR critical violations 2-4 |
| **REJECT** | Fail rate > 30% OR critical violations >= 5 |

#### Fail Categories

| Category | Parameters |
|---|---|
| MOSFET | Vt, Idsat, Ioff, Gm, DIBL, Subthreshold Swing |
| Resistance/Via | Contact, Via, Via Chain, Sheet Resistance |
| Oxide/Reliability | EOT, Oxide Breakdown, Gate Leakage |
| Leakage | Junction Leakage, Ioff, Gate Leakage |
| Circuit | Ring Oscillator, IDDQ |
| Lithography | Linewidth, Overlay |

### 5. MOSFET Parametric Measurements (NMOS)

| Column | Unit | LSL | USL | Target | Description |
|---|---|---|---|---|---|
| `nmos_vt_lin_v` | V | 0.25 | 0.45 | 0.35 | NMOS threshold voltage (linear) |
| `nmos_vt_sat_v` | V | 0.30 | 0.50 | 0.40 | NMOS threshold voltage (saturation) |
| `nmos_idsat_ua_um` | µA/µm | 500 | 900 | 700 | NMOS saturation drive current |
| `nmos_ioff_na_um` | nA/µm | 0 | 100 | 20 | NMOS off-state leakage current |
| `nmos_igoff_na_um` | nA/µm | 0 | 50 | 10 | NMOS gate leakage (off-state) |
| `nmos_subthreshold_swing_mv_dec` | mV/dec | 60 | 100 | 80 | NMOS subthreshold swing |
| `nmos_dibl_mv_v` | mV/V | 30 | 120 | 70 | NMOS DIBL |
| `nmos_gm_us_um` | µS/µm | 500 | 1500 | 1000 | NMOS transconductance |

### 6. MOSFET Parametric Measurements (PMOS)

| Column | Unit | LSL | USL | Target | Description |
|---|---|---|---|---|---|
| `pmos_vt_lin_v` | V | -0.45 | -0.25 | -0.35 | PMOS threshold voltage (linear) |
| `pmos_vt_sat_v` | V | -0.50 | -0.30 | -0.40 | PMOS threshold voltage (saturation) |
| `pmos_idsat_ua_um` | µA/µm | 300 | 700 | 500 | PMOS saturation drive current |
| `pmos_ioff_na_um` | nA/µm | 0 | 100 | 20 | PMOS off-state leakage current |
| `pmos_igoff_na_um` | nA/µm | 0 | 50 | 10 | PMOS gate leakage (off-state) |
| `pmos_subthreshold_swing_mv_dec` | mV/dec | 60 | 110 | 85 | PMOS subthreshold swing |
| `pmos_dibl_mv_v` | mV/V | 30 | 130 | 80 | PMOS DIBL |
| `pmos_gm_us_um` | µS/µm | 400 | 1200 | 800 | PMOS transconductance |

### 7. Resistance / Interconnect Measurements

| Column | Unit | LSL | USL | Target | Description |
|---|---|---|---|---|---|
| `poly_rs_ohm_sq` | Ω/sq | 100 | 300 | 200 | Polysilicon sheet resistance |
| `nplus_rs_ohm_sq` | Ω/sq | 50 | 150 | 90 | N+ sheet resistance |
| `pplus_rs_ohm_sq` | Ω/sq | 60 | 180 | 110 | P+ sheet resistance |
| `metal1_rs_ohm_sq` | Ω/sq | 0.02 | 0.08 | 0.05 | Metal 1 sheet resistance |
| `metal2_rs_ohm_sq` | Ω/sq | 0.02 | 0.08 | 0.05 | Metal 2 sheet resistance |
| `contact_res_ohm` | Ω | 5 | 30 | 12 | Contact resistance |
| `via1_res_ohm` | Ω | 3 | 20 | 8 | Via 1 resistance |
| `via_chain_res_ohm` | Ω | 100 | 500 | 250 | Via chain resistance |

### 8. Oxide / Capacitor / Junction Measurements

| Column | Unit | LSL | USL | Target | Description |
|---|---|---|---|---|---|
| `moscap_eot_nm` | nm | 0.8 | 1.5 | 1.1 | MOSCAP equivalent oxide thickness |
| `oxide_vbd_v` | V | 4.0 | 10.0 | 7.0 | Oxide breakdown voltage |
| `gate_leak_na_cm2` | nA/cm² | 0 | 500 | 50 | Gate leakage current density |
| `junction_leak_na` | nA | 0 | 200 | 30 | Junction leakage current |
| `junction_bv_v` | V | 5.0 | 12.0 | 8.0 | Junction breakdown voltage |
| `mim_cap_density_ff_um2` | fF/µm² | 5.0 | 15.0 | 10.0 | MIM capacitor density |

### 9. Circuit / Process Monitor Measurements

| Column | Unit | LSL | USL | Target | Description |
|---|---|---|---|---|---|
| `ring_osc_freq_mhz` | MHz | 1500 | 3000 | 2200 | Ring oscillator frequency |
| `ring_osc_delay_ps_stage` | ps/stage | 5 | 20 | 10 | Ring oscillator delay per stage |
| `iddq_monitor_ua` | µA | 0.5 | 10.0 | 3.0 | IDDQ on monitor circuit |
| `linewidth_nm` | nm | 18 | 28 | 23 | Critical dimension linewidth |
| `overlay_x_nm` | nm | -10 | 10 | 0 | Overlay error X direction |
| `overlay_y_nm` | nm | -10 | 10 | 0 | Overlay error Y direction |

### 10. Derived Analysis Helpers

| Column | Type | Description |
|---|---|---|
| `process_excursion_pattern` | String | NONE / CENTER_SLOW / EDGE_LEAKAGE / CONTACT_VIA_HIGH / OVERLAY_SHIFT / OXIDE_WEAK |
| `param_outlier_flag` | Integer | 1 = parametric outlier detected (>70% of half-spec range from target) |

---

## Built-in Process Excursion Patterns

The mock data includes 5 realistic process excursion patterns for analysis practice:

| Pattern | Location | Effect | Expected Impact |
|---|---|---|---|
| **Center Slow** | L3501-W02 | Lower drive current & ring oscillator freq at wafer center (5 center sites affected) | Center sites show reduced Idsat, Fmax |
| **Oxide Weak** | L3501-W05 | Lower oxide breakdown voltage, higher gate leakage | Wafer placed on HOLD; elevated gate_leak, lower Vbd |
| **Contact/Via High** | L3502-W01 | Elevated contact, via1, and via chain resistance | Wafer REJECTED; 79% site failure rate |
| **Overlay Shift** | L3502-W03 | Linewidth and overlay shift causing Vt/Idsat shift | Elevated overlay_x/y, linewidth |
| **Edge Leakage** | L3503-W05 | Elevated NMOS/PMOS Ioff and junction leakage at edge sites | Wafer REJECTED; edge sites fail Ioff/junction_leak specs |

---

## CP vs WAT Comparison

| Aspect | CP Testing | WAT Testing |
|---|---|---|
| **Test Target** | Functional product dies | PCM/test structures in scribe lines |
| **Sites per Wafer** | ~2,000-3,000 | ~20-30 |
| **Test Type** | Functional + parametric | Process parametric only |
| **Key Parameters** | Continuity, IDDQ, Fmax, SRAM | Vt, Idsat, Ioff, Rs, EOT, Ring Osc |
| **Decision** | Die binning (pass/fail) | Wafer acceptance (pass/hold/reject) |
| **When** | After sort | After fab, before sort |

---

## Suggested Analysis Tasks

1. **Wafer Map Visualization** — Plot `wafer_x_mm` vs `wafer_y_mm` colored by `site_pass_fail` or key parameters
2. **Process Capability (Cp/Cpk)** — Calculate Cp and Cpk for each parametric measurement
3. **Wafer Acceptance Summary** — Wafer-level pass/hold/reject distribution by lot
4. **Spec Violation Pareto** — Bar chart of spec violations by parameter
5. **Zone Yield Comparison** — CENTER vs MID vs EDGE pass rate
6. **Excursion Pattern Detection** — Identify CENTER_SLOW, EDGE_LEAKAGE, OXIDE_WEAK patterns
7. **Lot-to-Lot Trend** — Track Vt, Idsat, Rs drift across lots
8. **Correlation Analysis** — Correlation between Vt and Idsat, Ioff and junction_leak
9. **Outlier Detection** — Identify param_outlier_flag sites and investigate
10. **CP-WAT Cross-Reference** — Use `adjacent_die_id` to correlate WAT parametric shifts with CP die yield. Note: the WAT and CP mock files use different lot/wafer IDs, so direct join analysis requires creating paired datasets with matching IDs.
