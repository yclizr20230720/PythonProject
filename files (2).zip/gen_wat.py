"""
Mock WAT / PCM (Wafer Acceptance Test) dataset generator.
Scribe-line TEG structures, 17-site sampling plan, 300mm.

Same LOT_ID / WAFER_ID keys as cp_die_level_testdata.csv -> WAT-to-CP-yield
correlation works out of the box.

Embedded ground truth:
  TW2602.3  implant tool IMP-B03 -> VTLIN/VTSAT_N high, IDSAT_N low   (= CP SB31 param fail lot)
  TW2606.7  gate-ox chamber DIFF-A02 after wafer 12 -> IOFF_N high, BVOX low (= CP SB21 IDDQ lot)
  TW2603.4  BEOL edge: RS_M1 / RC_VIA1 strong edge gradient          (= CP edge loss lot)
  TW2604.5  CMP dishing center: RS_M2 low + RC_VIA2 high at center   (= CP center cluster lot)
  TW2601.2 / TW2605.6  clean WAT -> failure is test-side / mask-side, NOT process
"""
import numpy as np, pandas as pd, math
from datetime import datetime, timedelta

rng = np.random.default_rng(717)
R = 150.0

# ---------- 17-site sampling plan (classic center + 4 rings) ----------
plan = [("C01", 0.0, 0.0)]
for r, names, ang0 in [(45, "N E S W", 90), (90, "NE SE SW NW", 45),
                       (120, "N2 E2 S2 W2", 90), (140, "NE2 SE2 SW2 NW2", 45)]:
    for k, nm in enumerate(names.split()):
        a = math.radians(ang0 - 90*k)
        plan.append((nm + f"_{r}", round(r*math.cos(a), 3), round(r*math.sin(a), 3)))
SITE = pd.DataFrame(plan, columns=["SITE_NAME", "SITE_X_MM", "SITE_Y_MM"])
SITE.insert(0, "SITE_ID", np.arange(1, len(SITE)+1))
SITE["RADIUS_MM"] = np.hypot(SITE.SITE_X_MM, SITE.SITE_Y_MM).round(3)
SITE["RADIUS_NORM"] = (SITE.RADIUS_MM/R).round(4)
SITE["THETA_DEG"] = ((np.degrees(np.arctan2(SITE.SITE_Y_MM, SITE.SITE_X_MM))+360) % 360).round(2)
SITE["ZONE"] = np.where(SITE.RADIUS_NORM < .40, "CENTER",
                 np.where(SITE.RADIUS_NORM < .80, "MIDDLE", "EDGE"))
SITE["RADIAL_RING"] = np.clip((SITE.RADIUS_NORM*5).astype(int)+1, 1, 5)
# map each TEG site to the die grid used in the CP file (8.0 x 8.4 mm die)
DW, DH, NX, NY = 8.0, 8.4, 37, 35
SITE["DIE_X"] = np.floor(SITE.SITE_X_MM/DW + NX/2).astype(int)
SITE["DIE_Y"] = np.floor(SITE.SITE_Y_MM/DH + NY/2).astype(int)
SITE["RETICLE_COL"] = SITE.DIE_X//3
SITE["RETICLE_ROW"] = SITE.DIE_Y//4
SITE["RETICLE_SHOT_ID"] = [f"S{c:02d}{r:02d}" for c, r in zip(SITE.RETICLE_COL, SITE.RETICLE_ROW)]
SITE["SCRIBE_ORIENT"] = np.where(SITE.SITE_ID % 2 == 0, "H_SCRIBE", "V_SCRIBE")
SITE["TEG_ID"] = [f"TEG-{i:02d}" for i in SITE.SITE_ID]

# ---------- parameter dictionary: name, unit, target, lo, hi, module, group, structure ----------
P = [
 ("VTLIN_NMOS",  "V",    0.415,  0.375,  0.455, "FEOL", "DEVICE_VT",  "NMOS_W10L0P03"),
 ("VTSAT_NMOS",  "V",    0.362,  0.322,  0.402, "FEOL", "DEVICE_VT",  "NMOS_W10L0P03"),
 ("VTLIN_PMOS",  "V",   -0.402, -0.442, -0.362, "FEOL", "DEVICE_VT",  "PMOS_W10L0P03"),
 ("VTSAT_PMOS",  "V",   -0.351, -0.391, -0.311, "FEOL", "DEVICE_VT",  "PMOS_W10L0P03"),
 ("IDSAT_NMOS",  "uA/um",  880,    790,    970, "FEOL", "DEVICE_DRIVE","NMOS_W10L0P03"),
 ("IDSAT_PMOS",  "uA/um",  415,    360,    470, "FEOL", "DEVICE_DRIVE","PMOS_W10L0P03"),
 ("IOFF_NMOS",   "pA/um",   35,      1,    120, "FEOL", "DEVICE_LEAK","NMOS_W10L0P03"),
 ("IOFF_PMOS",   "pA/um",   28,      1,    100, "FEOL", "DEVICE_LEAK","PMOS_W10L0P03"),
 ("GM_MAX_NMOS", "mS/um", 1.42,   1.18,   1.66, "FEOL", "DEVICE_DRIVE","NMOS_W10L0P03"),
 ("SS_NMOS",     "mV/dec",  88,     72,    104, "FEOL", "DEVICE_VT",  "NMOS_W10L0P03"),
 ("DIBL_NMOS",   "mV/V",    92,     55,    135, "FEOL", "DEVICE_VT",  "NMOS_SHORT_L0P028"),
 ("TOX_INV",     "nm",    1.85,   1.68,   2.02, "FEOL", "GATE_OXIDE", "MOSCAP_50X50"),
 ("CAP_GATE",    "fF/um2",18.60,  17.10,  20.10,"FEOL", "GATE_OXIDE", "MOSCAP_50X50"),
 ("BVOX",        "V",     6.80,   5.40, 999.00, "FEOL", "GATE_OXIDE", "MOSCAP_50X50"),
 ("POLY_CD",     "nm",    31.0,   27.5,   34.5, "FEOL", "CD_PROFILE", "CD_BAR_ISO"),
 ("RS_POLY",     "ohm/sq",  9.8,    8.2,   11.4, "FEOL", "SHEET_RES",  "VDP_POLY"),
 ("RS_NPLUS",    "ohm/sq", 62.0,   52.0,   72.0, "FEOL","SHEET_RES",  "VDP_NPLUS_SD"),
 ("RS_PPLUS",    "ohm/sq",118.0,  100.0,  136.0, "FEOL","SHEET_RES",  "VDP_PPLUS_SD"),
 ("RS_NWELL",    "ohm/sq",760.0,  640.0,  880.0, "FEOL","SHEET_RES",  "VDP_NWELL"),
 ("RC_CONT_N",   "ohm",   12.50,   8.50,  16.50, "MEOL","CONTACT_RES","CONT_CHAIN_10K"),
 ("RC_CONT_P",   "ohm",   17.20,  12.00,  22.40, "MEOL","CONTACT_RES","CONT_CHAIN_10K"),
 ("RS_M1",       "ohm/sq",0.098,  0.082,  0.114, "BEOL","SHEET_RES",  "VDP_M1"),
 ("RS_M2",       "ohm/sq",0.082,  0.068,  0.096, "BEOL","SHEET_RES",  "VDP_M2"),
 ("RC_VIA1",     "ohm",    3.60,   2.40,   4.80, "BEOL","VIA_RES",    "VIA1_CHAIN_20K"),
 ("RC_VIA2",     "ohm",    3.25,   2.10,   4.40, "BEOL","VIA_RES",    "VIA2_CHAIN_20K"),
 ("M1_COMB_LEAK","pA",     2.50,   0.00,  50.00, "BEOL","BEOL_ISO",   "COMB_M1_0P045"),
 ("M1_SERP_RES", "ohm",  1850.0, 1600.0, 2100.0, "BEOL","BEOL_ISO",   "SERP_M1_5MM"),
 ("CAP_MIM",     "fF/um2", 2.05,   1.85,   2.25, "BEOL","BEOL_CAP",   "MIMCAP_100X100"),
 ("RO_FREQ",     "MHz",  1290.0, 1150.0, 1430.0, "TEG", "RING_OSC",   "RO_51STAGE_FO1"),
 ("RO_IDD",      "uA",    82.00,  60.00, 104.00, "TEG", "RING_OSC",   "RO_51STAGE_FO1"),
 ("SRAM_ICELL",  "uA",    14.80,  11.50,  18.10, "TEG", "SRAM_BITCELL","SRAM_6T_0P127"),
 ("DIODE_VF",    "V",     0.658,  0.610,  0.706, "TEG", "JUNCTION",   "DIODE_NP_20X20"),
 ("JUNC_LEAK_N", "pA/um2", 8.50,   0.00,  60.00, "TEG", "JUNCTION",   "DIODE_NP_20X20"),
 ("ESD_BV_NPN",  "V",     9.40,   8.20,  10.80, "TEG", "ESD",        "GGNMOS_W100"),
]
PDF = pd.DataFrame(P, columns=["PARAM_NAME","UNIT","TARGET","SPEC_LOW","SPEC_HIGH",
                               "MODULE","PARAM_GROUP","TEST_STRUCTURE"])
PDF.insert(0, "PARAM_ID", [f"W{1000+i*5}" for i in range(len(PDF))])
PDF["USL_MINUS_LSL"] = (PDF.SPEC_HIGH - PDF.SPEC_LOW).round(4)
PDF["CRITICALITY"] = np.where(PDF.PARAM_GROUP.isin(["DEVICE_VT","DEVICE_DRIVE","GATE_OXIDE"]),
                              "KEY", "MONITOR")

LOTS = [f"TW{2600+i:04d}.{i%9+1}" for i in range(8)]
IMP = ["IMP-A01","IMP-A02","IMP-B01","IMP-B02"]
LITHO = ["SCN-01","SCN-02","SCN-03"]
ETCH = ["ETC-11","ETC-12","ETC-13","ETC-14"]
CMPT = ["CMP-01","CMP-02","CMP-03"]
DIFF = ["DIFF-A01","DIFF-A03","DIFF-B01"]
WAT_TST = ["WAT-PA01","WAT-PA02","WAT-PB01"]

rows = []
t0 = datetime(2026, 7, 28, 9, 0, 0)
n = len(SITE)
rn = SITE.RADIUS_NORM.values
for li, lot in enumerate(LOTS):
    bad_imp  = (li == 2)          # TW2602.3 implant excursion
    bad_ox   = (li == 6)          # TW2606.7 gate-ox chamber
    beol_edge= (li == 3)          # TW2603.4 BEOL edge gradient
    cmp_ctr  = (li == 4)          # TW2604.5 CMP center dishing
    for w in range(1, 26):
        meas = t0 + timedelta(days=li*2, hours=int(w*0.6), minutes=int(rng.integers(0, 40)))
        imp = "IMP-B03" if bad_imp else IMP[(li+w) % 4]
        dif = "DIFF-A02" if (bad_ox and w > 12) else DIFF[(li+w) % 3]
        cmp_tool = "CMP-04" if (cmp_ctr and w % 2 == 0) else CMPT[(li+w) % 3]
        eq = dict(IMPLANT_TOOL=imp, LITHO_TOOL=LITHO[(li+w) % 3], ETCH_TOOL=ETCH[(li+2*w) % 4],
                  CMP_TOOL=cmp_tool, DIFFUSION_TOOL=dif,
                  WAT_TESTER=WAT_TST[(li+w) % 3])
        wf = rng.normal(0, 1)                       # wafer-level random effect
        edge_k = 2.4 if beol_edge else 1.0
        ctr_k  = 1.0 if not (cmp_ctr and w % 2 == 0) else 3.2

        vt_shift = (0.026 if bad_imp else 0.0) + 0.0035*wf
        v = {}
        v["VTLIN_NMOS"] = 0.415 + vt_shift + 0.016*rn**2 + rng.normal(0, .0042, n)
        v["VTSAT_NMOS"] = v["VTLIN_NMOS"] - 0.053 + rng.normal(0, .0025, n)
        v["VTLIN_PMOS"] = -(0.402 + vt_shift*0.55 + 0.014*rn**2) + rng.normal(0, .0045, n)
        v["VTSAT_PMOS"] = v["VTLIN_PMOS"] + 0.051 + rng.normal(0, .0026, n)
        v["IDSAT_NMOS"] = 880 - (vt_shift*2600) - 42*rn**2 + rng.normal(0, 13, n)
        v["IDSAT_PMOS"] = 415 - (vt_shift*1150) - 20*rn**2 + rng.normal(0, 8, n)
        ox_bad = (1.0 if (bad_ox and w > 12) else 0.0)
        v["IOFF_NMOS"] = np.exp(rng.normal(np.log(35) - vt_shift*9 + 1.15*ox_bad + .35*rn**2, .32, n))
        v["IOFF_PMOS"] = np.exp(rng.normal(np.log(28) - vt_shift*7 + 0.85*ox_bad + .30*rn**2, .30, n))
        v["GM_MAX_NMOS"] = 1.42 - vt_shift*3.6 - .07*rn**2 + rng.normal(0, .028, n)
        v["SS_NMOS"] = 88 + 7*ox_bad + 3.5*rn**2 + rng.normal(0, 2.4, n)
        v["DIBL_NMOS"] = 92 - vt_shift*380 + 11*rn**2 + rng.normal(0, 6.5, n)
        v["TOX_INV"] = 1.85 - .055*ox_bad + .035*rn**2 + rng.normal(0, .022, n)
        v["CAP_GATE"] = 18.6 + .42*ox_bad - .30*rn**2 + rng.normal(0, .17, n)
        v["BVOX"] = 6.8 - 1.15*ox_bad - .30*rn**2 + rng.normal(0, .22, n)
        v["POLY_CD"] = 31.0 + vt_shift*22 + .9*rn**2 + rng.normal(0, .55, n) + wf*.25
        v["RS_POLY"] = 9.8 + .35*rn**2 + rng.normal(0, .22, n) + wf*.12
        v["RS_NPLUS"] = 62 + (7.5 if bad_imp else 0) + 2.2*rn**2 + rng.normal(0, 1.7, n)
        v["RS_PPLUS"] = 118 + 4.5*rn**2 + rng.normal(0, 3.4, n) + wf*2
        v["RS_NWELL"] = 760 + (34 if bad_imp else 0) + 22*rn**2 + rng.normal(0, 17, n)
        v["RC_CONT_N"] = 12.5 + 1.1*rn**2 + rng.normal(0, .55, n)
        v["RC_CONT_P"] = 17.2 + 1.6*rn**2 + rng.normal(0, .78, n)
        v["RS_M1"] = .098 + edge_k*.0068*rn**3 + rng.normal(0, .0026, n)
        v["RS_M2"] = .082 - .004*ctr_k*np.clip(.45-rn, 0, None) + .004*rn**3 + rng.normal(0, .0022, n)
        v["RC_VIA1"] = 3.60 + edge_k*.42*rn**3 + rng.normal(0, .14, n)
        v["RC_VIA2"] = 3.25 + .30*ctr_k*np.clip(.45-rn, 0, None) + .22*rn**3 + rng.normal(0, .13, n)
        v["M1_COMB_LEAK"] = np.exp(rng.normal(np.log(2.5) + 1.1*edge_k*rn**3, .55, n))
        v["M1_SERP_RES"] = 1850 + edge_k*95*rn**3 + rng.normal(0, 42, n)
        v["CAP_MIM"] = 2.05 - .03*rn**2 + rng.normal(0, .028, n)
        v["RO_FREQ"] = 1290 - vt_shift*3400 - 55*rn**2 + rng.normal(0, 19, n)
        v["RO_IDD"] = 82 + (v["IOFF_NMOS"]-35)*.11 - vt_shift*140 + rng.normal(0, 3.2, n)
        v["SRAM_ICELL"] = 14.8 - vt_shift*52 - .8*rn**2 + rng.normal(0, .45, n)
        v["DIODE_VF"] = .658 + .004*rn**2 + rng.normal(0, .0065, n)
        v["JUNC_LEAK_N"] = np.exp(rng.normal(np.log(8.5) + .7*ox_bad + .4*rn**2, .45, n))
        v["ESD_BV_NPN"] = 9.4 - vt_shift*9 + rng.normal(0, .26, n)

        blk = pd.concat([SITE.assign(PARAM_NAME=k, VALUE=np.round(val, 5)) for k, val in v.items()],
                        ignore_index=True)
        blk.insert(0, "LOT_ID", lot)
        blk.insert(1, "WAFER_ID", f"{lot}-{w:02d}")
        blk.insert(2, "WAFER_NO", w)
        for c, val in eq.items():
            blk[c] = val
        blk["MEAS_TIME"] = meas.strftime("%Y-%m-%d %H:%M:%S")
        rows.append(blk)

df = pd.concat(rows, ignore_index=True)
df = df.merge(PDF, on="PARAM_NAME", how="left")
df["OOS_FLAG"] = np.where((df.VALUE < df.SPEC_LOW) | (df.VALUE > df.SPEC_HIGH), "OOS", "PASS")
df["SPEC_MARGIN_PCT"] = np.where(
    df.VALUE >= df.TARGET,
    (df.SPEC_HIGH - df.VALUE)/(df.SPEC_HIGH - df.TARGET).replace(0, np.nan)*100,
    (df.VALUE - df.SPEC_LOW)/(df.TARGET - df.SPEC_LOW).replace(0, np.nan)*100).round(2)

cols = ["LOT_ID","WAFER_ID","WAFER_NO","MEAS_TIME","WAT_TESTER","IMPLANT_TOOL","LITHO_TOOL",
        "ETCH_TOOL","CMP_TOOL","DIFFUSION_TOOL","SITE_ID","SITE_NAME","SITE_X_MM","SITE_Y_MM",
        "RADIUS_MM","RADIUS_NORM","THETA_DEG","ZONE","RADIAL_RING","DIE_X","DIE_Y",
        "RETICLE_COL","RETICLE_ROW","RETICLE_SHOT_ID","SCRIBE_ORIENT","TEG_ID","TEST_STRUCTURE",
        "PARAM_ID","PARAM_NAME","PARAM_GROUP","MODULE","CRITICALITY","UNIT","VALUE","TARGET",
        "SPEC_LOW","SPEC_HIGH","SPEC_MARGIN_PCT","OOS_FLAG"]
df = df[cols]
df.to_csv("/mnt/user-data/outputs/wat_site_level_testdata.csv", index=False)

wide = df.pivot_table(index=["LOT_ID","WAFER_ID","WAFER_NO","SITE_ID","SITE_NAME","SITE_X_MM",
                            "SITE_Y_MM","RADIUS_MM","ZONE","DIE_X","DIE_Y","IMPLANT_TOOL",
                            "DIFFUSION_TOOL","CMP_TOOL","WAT_TESTER"],
                      columns="PARAM_NAME", values="VALUE").reset_index()
wide.to_csv("/mnt/user-data/outputs/wat_site_level_wide.csv", index=False)

# wafer-level median summary (the usual WAT-to-yield join grain)
med = df.pivot_table(index=["LOT_ID","WAFER_ID","WAFER_NO","IMPLANT_TOOL","DIFFUSION_TOOL",
                            "CMP_TOOL","LITHO_TOOL","ETCH_TOOL","WAT_TESTER"],
                     columns="PARAM_NAME", values="VALUE", aggfunc="median").reset_index()
oos = df[df.OOS_FLAG == "OOS"].groupby("WAFER_ID").size()
med.insert(9, "OOS_SITE_PARAM_QTY", med.WAFER_ID.map(oos).fillna(0).astype(int))
med.round(5).to_csv("/mnt/user-data/outputs/wat_wafer_median_summary.csv", index=False)
PDF.to_csv("/mnt/user-data/outputs/wat_param_spec_definition.csv", index=False)

print(len(df), "rows |", df.WAFER_ID.nunique(), "wafers |", df.PARAM_NAME.nunique(), "params")
print(df[df.OOS_FLAG=="OOS"].groupby(["LOT_ID","PARAM_NAME"]).size().nlargest(12).to_string())
