# CP Yield Engineering Mock Data — Data Dictionary

## Overview

| Field | Value |
|---|---|
| **File** | `cp_yield_mock_data.csv` |
| **Grain** | One row per die per CP test step |
| **Total Records** | ~39,400 die records |
| **Lots** | 3 (L2401, L2402, L2403) |
| **Wafers** | 15 (5 per lot) |
| **Wafer Size** | 300mm |
| **Die Size** | 5mm × 5mm |
| **Probe Card** | 8-site |
| **Columns** | 54 |

---

## Column Definitions

### 1. Lot / Wafer Hierarchy

| Column | Type | Description |
|---|---|---|
| `lot_id` | String | Lot identifier (e.g., L2401) |
| `product_id` | String | Product name (e.g., PROD-7NM-ASIC-A) |
| `process_node` | String | Process technology node (7nm, 5nm, 12nm) |
| `fab` | String | Fabrication facility |
| `wafer_id` | String | Wafer identifier (e.g., L2401-W01) |
| `wafer_slot` | Integer | Wafer slot position in lot (1-5) |
| `cp_step` | String | CP test step (CP1, CP2, etc.) |
| `test_program` | String | Test program name |
| `test_program_rev` | String | Test program version |
| `operator_id` | String | Operator ID |

### 2. Die and Location Information

| Column | Type | Description |
|---|---|---|
| `die_id` | String | Unique die identifier |
| `die_x` | Integer | Die column on wafer (1-indexed) |
| `die_y` | Integer | Die row on wafer (1-indexed) |
| `wafer_x_mm` | Float | Die center X coordinate in mm |
| `wafer_y_mm` | Float | Die center Y coordinate in mm |
| `radius_mm` | Float | Distance from wafer center in mm |
| `reticle_x` | Integer | Reticle column (2 dies per reticle) |
| `reticle_y` | Integer | Reticle row |
| `die_in_reticle_x` | Integer | Die position within reticle (1-2) |
| `die_in_reticle_y` | Integer | Die position within reticle (1-2) |
| `quadrant` | String | Wafer quadrant (Q1-Q4) |
| `edge_die_flag` | Integer | 1 = edge die, 0 = interior |
| `scribe_line_flag` | Integer | 1 = die on scribe line boundary |
| `wafer_zone` | String | CENTER / MID / EDGE |

### 3. Test Execution

| Column | Type | Description |
|---|---|---|
| `test_start_time` | DateTime | Test start timestamp |
| `tester_id` | String | ATE tester ID |
| `prober_id` | String | Prober ID |
| `probe_card_id` | String | Probe card ID |
| `site_id` | String | Test site (S1-S8) |
| `touchdown_id` | Integer | Touchdown sequence number |
| `test_temperature_c` | Float | Test temperature in °C |
| `test_time_ms` | Integer | Test duration in ms |
| `retest_flag` | Integer | 1 = retested, 0 = first test |

### 4. Yield / Binning

| Column | Type | Description |
|---|---|---|
| `pass_fail` | String | PASS or FAIL |
| `hard_bin` | Integer | Hard bin code (1-8) |
| `soft_bin` | Integer | Soft bin code (same as hard bin) |
| `bin_description` | String | Bin description text |
| `fail_category` | String | Failure category |
| `first_fail_test` | String | Name of first failing test |
| `sort_yield_impact_flag` | String | Y = impacts sort yield |

#### Bin Code Reference

| Bin | Description | Fail Category | Typical Spec |
|---|---|---|---|
| 1 | PASS | None | All tests within spec |
| 2 | CONTINUITY_FAIL | Continuity | Open/Short detection |
| 3 | IDDQ_FAIL | Current | Quiescent current < 10 µA |
| 4 | LEAKAGE_FAIL | Leakage | Leakage current < 100 nA |
| 5 | SRAM_MBIST_FAIL | Memory | SRAM MBIST 0 fail bits |
| 6 | SCAN_FAIL | Logic | Scan chain 0 failures |
| 7 | FMAX_FAIL | Speed | Frequency > 1800 MHz |
| 8 | ANALOG_PARAM_FAIL | Analog | ADC/DAC within spec |

### 5. Parametric Test Measurements

| Column | Unit | Spec Limit | Description |
|---|---|---|---|
| `continuity_ohm` | Ω | < 50 | Continuity resistance |
| `vdd_v` | V | 0.90 ± 0.05 | Supply voltage measurement |
| `iddq_ua` | µA | < 10 | Quiescent supply current |
| `ileak_na` | nA | < 100 | Leakage current |
| `standby_current_ua` | µA | < 50 | Standby mode current |
| `fmax_mhz` | MHz | > 1800 | Maximum operating frequency |
| `pll_lock_ms` | ms | < 5 | PLL lock time |
| `sram_mbist_fail_bits` | count | 0 | SRAM MBIST failed bit count |
| `scan_fail_count` | count | 0 | Scan chain failure count |
| `adc_gain_error_lsb` | LSB | < 10 | ADC gain error |
| `dac_inl_lsb` | LSB | < 5 | DAC integral non-linearity |
| `timing_margin_ps` | ps | > 200 | Timing margin |

### 6. Derived Analysis Helpers

| Column | Type | Description |
|---|---|---|
| `spatial_defect_pattern` | String | NONE / CENTER_CLUSTER / EDGE_RING / SCRATCH / SITE_PATTERN |
| `param_outlier_flag` | Integer | 1 = parametric outlier detected |

---

## Built-in Defect Patterns

The mock data includes realistic spatial defect patterns for analysis practice:

| Pattern | Location | Description |
|---|---|---|
| **Center Cluster** | L2401-W02 | SRAM MBIST failures concentrated at wafer center |
| **Diagonal Scratch** | L2402-W03 | Continuity & Scan failures along diagonal |
| **Edge Ring** | L2403-W04 | Elevated leakage/analog failures at wafer edge |
| **Site Pattern** | L2402-W01 (S3), L2403-W02 (S6) | Probe card site-specific IDDQ/continuity failures |

---

## Suggested Analysis Tasks

1. **Wafer Map Visualization** — Plot `die_x` vs `die_y` colored by `hard_bin` for each wafer
2. **Bin Pareto Chart** — Bar chart of bin counts sorted descending
3. **Yield Trend** — Yield by lot and wafer over time
4. **Site Yield Comparison** — Yield distribution across `site_id`
5. **Parametric Distribution** — Histogram of `iddq_ua`, `fmax_mhz`, etc. with spec limits
6. **Spatial Defect Detection** — Identify CENTER_CLUSTER, SCRATCH, EDGE_RING patterns
7. **Probe Card Correlation** — Yield by `probe_card_id` and `site_id`
8. **Reticle Analysis** — Yield by `reticle_x`, `reticle_y` position
9. **Correlation Analysis** — Correlation between parametric values and bin outcomes
10. **Wafer Zone Yield** — CENTER vs MID vs EDGE yield comparison
