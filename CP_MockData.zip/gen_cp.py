"""
Mock Circuit Probe (CP / wafer sort) die-level dataset generator.
Produces STDF-like die records with wafer map coordinates, reticle coords,
multi-site probing, hard/soft bins and parametric test values.

Embedded, defect-signature ground truth (for RCA exercises):
  L01  baseline
  L02  probe-card site-3 contact degradation  -> SB11 continuity, site-repeating
  L03  Vt shift / implant excursion            -> SB31 parametric, lot-wide
  L04  edge ring loss + 1 scratch wafer        -> SB12, radial + streak
  L05  center cluster (CMP dishing) on 4 wfrs  -> SB41 scan fail, center zone
  L06  reticle-field repeating die (shot pos)  -> SB61 BIST, reticle X=1,Y=2
  L07  IDDQ leakage drift by tester TST-04     -> SB21, tester-correlated
  L08  baseline, second probe pass (retest)
"""
import numpy as np, pandas as pd, math
from datetime import datetime, timedelta

rng = np.random.default_rng(20260920)

WAFER_D, EDGE_EXCL = 300.0, 3.0
DIE_W, DIE_H = 8.0, 8.4
RET_COLS, RET_ROWS = 3, 4          # die per reticle shot

# ---------- wafer map ----------
nx = int(WAFER_D // DIE_W); ny = int(WAFER_D // DIE_H)
dies = []
for iy in range(ny):
    for ix in range(nx):
        cx = (ix - nx/2 + 0.5) * DIE_W
        cy = (iy - ny/2 + 0.5) * DIE_H
        # all 4 corners must be inside the usable radius
        r_corner = max(math.hypot(cx+sx*DIE_W/2, cy+sy*DIE_H/2)
                       for sx in (-1, 1) for sy in (-1, 1))
        if r_corner <= WAFER_D/2 - EDGE_EXCL:
            dies.append((ix, iy, cx, cy, math.hypot(cx, cy)))
dies.sort(key=lambda d: (d[1], d[0]))
GROSS = len(dies)

die_x  = np.array([d[0] for d in dies]); die_y = np.array([d[1] for d in dies])
ctr_x  = np.array([d[2] for d in dies]); ctr_y = np.array([d[3] for d in dies])
radius = np.array([d[4] for d in dies])
r_norm = radius / (WAFER_D/2)
theta  = (np.degrees(np.arctan2(ctr_y, ctr_x)) + 360) % 360
zone   = np.where(r_norm < 0.40, "CENTER", np.where(r_norm < 0.80, "MIDDLE", "EDGE"))
ring   = np.clip((r_norm*5).astype(int)+1, 1, 5)
ret_c, ret_r = die_x // RET_COLS, die_y // RET_ROWS
in_ret_x, in_ret_y = die_x % RET_COLS, die_y % RET_ROWS
site = ((die_x % 2) + 2*(die_y % 2) + 1)          # 4-site parallel prober
seq  = np.arange(1, GROSS+1)

LOTS = [f"L{ i:02d}" for i in range(1, 9)]
LOT_ID = {l: f"TW{2600+i:04d}.{i%9+1}" for i, l in enumerate(LOTS)}
TESTERS = ["TST-01", "TST-02", "TST-03", "TST-04"]
PROBERS = ["PRB-A1", "PRB-A2", "PRB-B1", "PRB-B2"]
PCARDS  = ["PC-4S-0071", "PC-4S-0088", "PC-4S-0102"]

SOFT = {  1: ("PASS_NOMINAL",     1, "P"),
          2: ("PASS_FAST_BIN",    1, "P"),
          3: ("PASS_SLOW_BIN",    1, "P"),
         11: ("CONTINUITY_OPEN",  2, "F"),
         12: ("CONTINUITY_SHORT", 2, "F"),
         21: ("IDDQ_LEAKAGE",     3, "F"),
         31: ("PARAM_VT_DC",      4, "F"),
         41: ("SCAN_FUNCTIONAL",  5, "F"),
         51: ("FMAX_SPEED",       6, "F"),
         61: ("MBIST_MEMORY",     7, "F"),
         99: ("EDGE_NOTEST",      8, "F")}

rows = []
t0 = datetime(2026, 8, 3, 6, 12, 0)

for li, lot in enumerate(LOTS):
    lot_vt   = rng.normal(0, 0.004) + (0.0255 if lot == "L03" else 0.0)
    lot_idd  = rng.normal(0, 0.6)
    tester   = TESTERS[li % 4] if lot != "L07" else "TST-04"
    pcard    = PCARDS[li % 3]
    scratch_w = rng.integers(1, 26) if lot == "L04" else -1
    ctr_wafers = set(rng.choice(np.arange(1, 26), 4, replace=False)) if lot == "L05" else set()
    for w in range(1, 26):
        wstart = t0 + timedelta(days=li*2, minutes=int(w*47 + rng.integers(0, 9)))
        prober = PROBERS[(li + w) % 4]
        temp   = 25 if (li + w) % 5 else 85
        wvt    = lot_vt + rng.normal(0, 0.0035)
        widd   = lot_idd + rng.normal(0, 0.35) + (0.9 if lot == "L07" and w > 12 else 0)
        pcard_wear = min(1.0, (w-1)/24)                      # touchdown count proxy
        edge_k = 1.9 if lot == "L04" else rng.uniform(0.5, 1.0)
        # scratch geometry (linear streak across the wafer)
        sc_m, sc_b = rng.uniform(-1.2, 1.2), rng.uniform(-40, 40)

        # ---- per-die parametrics ----
        n = GROSS
        vt_n = 0.412 + wvt + 0.021*r_norm**2 + rng.normal(0, 0.0055, n)
        vt_p = -(0.398 + wvt*0.8 + 0.019*r_norm**2) + rng.normal(0, 0.0058, n)
        iddq = np.exp(rng.normal(1.05 + widd*0.26 + 0.30*r_norm**2, 0.34, n))   # uA
        ron  = 118 + 46*r_norm**2 + rng.normal(0, 5.5, n) + (wvt*180)
        fmax = 1285 - 92*r_norm**2 - (wvt*1400) + rng.normal(0, 28, n)
        vmin = 0.742 + 0.030*r_norm**2 + (wvt*0.55) + rng.normal(0, 0.011, n)
        cres = 0.92 + 0.15*pcard_wear + rng.normal(0, 0.07, n)                  # ohm
        icc  = 41.5 + 4.2*r_norm + rng.normal(0, 1.6, n)                        # mA
        ttime = rng.normal(2350, 140, n) + 500*(temp == 85)

        soft = np.full(n, 0, dtype=int)
        # ---- defect signatures -> failure probabilities ----
        p_open  = 0.004 + 0.012*pcard_wear
        if lot == "L02":
            p_open = p_open + np.where(site == 3, 0.055 + 0.22*pcard_wear, 0)
        cres = cres + (np.where(site == 3, 0.55*pcard_wear, 0) if lot == "L02" else 0)

        p_short = 0.003 + edge_k*np.clip(r_norm-0.86, 0, None)**1.5*9.0
        if lot == "L04" and w == scratch_w:
            dist = np.abs(sc_m*ctr_x - ctr_y + sc_b)/math.sqrt(sc_m**2+1)
            p_short = p_short + np.where(dist < 7.0, 0.72, 0)
        p_scan = 0.006 + 0.010*r_norm
        if lot == "L05" and w in ctr_wafers:
            p_scan = p_scan + np.where(r_norm < 0.30, 0.34, 0)
        p_bist = 0.005
        if lot == "L06":
            p_bist = p_bist + np.where((in_ret_x == 1) & (in_ret_y == 2), 0.46, 0)

        u = rng.random(n)
        soft = np.where((u < p_open), 11, soft)
        soft = np.where((soft == 0) & (rng.random(n) < p_short), 12, soft)
        soft = np.where((soft == 0) & (iddq > 7.5), 21, soft)
        soft = np.where((soft == 0) & ((vt_n > 0.452) | (vt_n < 0.372) | (ron > 205)), 31, soft)
        soft = np.where((soft == 0) & (rng.random(n) < p_scan), 41, soft)
        soft = np.where((soft == 0) & (fmax < 1150), 51, soft)
        soft = np.where((soft == 0) & (rng.random(n) < p_bist), 61, soft)
        passing = soft == 0
        soft = np.where(passing & (fmax > 1330), 2, soft)
        soft = np.where(passing & (fmax <= 1330) & (fmax >= 1215), 1, soft)
        soft = np.where(soft == 0, 3, soft)
        fail = soft > 10
        # failed die stop early on the failing test -> shorter test time
        ttime = np.where(fail, ttime*rng.uniform(0.35, 0.70, n), ttime)

        hard = np.array([SOFT[s][1] for s in soft])
        bnm  = [SOFT[s][0] for s in soft]
        pf   = ["F" if f else "P" for f in fail]

        tstamps = [wstart + timedelta(milliseconds=int(x))
                   for x in np.cumsum(ttime/4 + 180)]
        rows.append(pd.DataFrame({
            "LOT_ID": LOT_ID[lot], "WAFER_ID": f"{LOT_ID[lot]}-{w:02d}", "WAFER_NO": w,
            "SLOT_NO": w, "PRODUCT_ID": "TQ7420-A", "DEVICE_ID": "SOC_NX28_REVB",
            "TECHNOLOGY": "N28HPC", "MASK_SET": "MS-TQ7420-R3", "FAB_ID": "FAB12A",
            "TEST_FLOOR": "SORT-2", "TEST_PROGRAM": "TQ7420_CP1_v3.4",
            "TEST_STAGE": "CP1", "PROBE_PASS": 2 if lot == "L08" else 1,
            "RETEST_FLAG": "Y" if lot == "L08" else "N",
            "TESTER_ID": tester, "PROBER_ID": prober, "PROBE_CARD_ID": pcard,
            "TEST_SITE": site, "PROBE_TEMP_C": temp,
            "TOUCHDOWN_COUNT": int(w*GROSS/4),
            "TEST_START_TIME": [t.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] for t in tstamps],
            "DIE_SEQ": seq, "DIE_X": die_x, "DIE_Y": die_y,
            "DIE_CENTER_X_MM": np.round(ctr_x, 3), "DIE_CENTER_Y_MM": np.round(ctr_y, 3),
            "RADIUS_MM": np.round(radius, 3), "RADIUS_NORM": np.round(r_norm, 4),
            "THETA_DEG": np.round(theta, 2), "ZONE": zone, "RADIAL_RING": ring,
            "RETICLE_COL": ret_c, "RETICLE_ROW": ret_r,
            "RETICLE_SHOT_ID": [f"S{c:02d}{r:02d}" for c, r in zip(ret_c, ret_r)],
            "DIE_IN_RETICLE_X": in_ret_x, "DIE_IN_RETICLE_Y": in_ret_y,
            "WAFER_SIZE_MM": 300, "NOTCH": "DOWN", "EDGE_EXCLUSION_MM": EDGE_EXCL,
            "HARD_BIN": hard, "SOFT_BIN": soft, "BIN_NAME": bnm, "PASS_FAIL": pf,
            "TEST_TIME_MS": np.round(ttime, 1),
            "VTH_NMOS_V": np.round(vt_n, 5), "VTH_PMOS_V": np.round(vt_p, 5),
            "IDDQ_UA": np.round(iddq, 4), "RON_OHM": np.round(ron, 3),
            "FMAX_MHZ": np.round(fmax, 1), "VDD_MIN_V": np.round(vmin, 4),
            "CONT_RES_OHM": np.round(cres, 4), "ICC_ACTIVE_MA": np.round(icc, 3),
        }))

df = pd.concat(rows, ignore_index=True)
df.to_csv("/mnt/user-data/outputs/cp_die_level_testdata.csv", index=False)

# ---------- wafer summary ----------
g = df.groupby(["LOT_ID", "WAFER_ID", "WAFER_NO", "TESTER_ID", "PROBER_ID",
                "PROBE_CARD_ID", "PROBE_TEMP_C", "PROBE_PASS"], as_index=False)
summ = g.agg(GROSS_DIE=("DIE_SEQ", "count"),
             PASS_DIE=("PASS_FAIL", lambda s: (s == "P").sum()),
             AVG_IDDQ_UA=("IDDQ_UA", "mean"), MED_VTH_NMOS_V=("VTH_NMOS_V", "median"),
             MED_FMAX_MHZ=("FMAX_MHZ", "median"), TEST_START=("TEST_START_TIME", "min"))
summ["YIELD_PCT"] = (summ.PASS_DIE/summ.GROSS_DIE*100).round(2)
for sb in [11, 12, 21, 31, 41, 51, 61]:
    c = df[df.SOFT_BIN == sb].groupby("WAFER_ID").size()
    summ[f"SB{sb}_QTY"] = summ.WAFER_ID.map(c).fillna(0).astype(int)
summ.round(4).to_csv("/mnt/user-data/outputs/cp_wafer_summary.csv", index=False)

# ---------- bin / test limit definitions ----------
lim = {"VTH_NMOS_V": (0.372, 0.452, "V"), "VTH_PMOS_V": (-0.452, -0.342, "V"),
       "IDDQ_UA": (0, 7.5, "uA"), "RON_OHM": (60, 205, "ohm"),
       "FMAX_MHZ": (1150, 9999, "MHz"), "VDD_MIN_V": (0.60, 0.86, "V"),
       "CONT_RES_OHM": (0.30, 1.60, "ohm"), "ICC_ACTIVE_MA": (20, 60, "mA")}
bd = pd.DataFrame([{"SOFT_BIN": s, "BIN_NAME": v[0], "HARD_BIN": v[1],
                    "PASS_FAIL": v[2],
                    "BIN_CATEGORY": {1: "GOOD", 2: "CONTINUITY", 3: "LEAKAGE",
                                     4: "PARAMETRIC", 5: "FUNCTIONAL", 6: "SPEED",
                                     7: "MEMORY", 8: "NON_TEST"}[v[1]]}
                   for s, v in SOFT.items()])
td = pd.DataFrame([{"TEST_NUM": 1000+i*10, "TEST_NAME": k, "UNIT": v[2],
                    "LOW_LIMIT": v[0], "HIGH_LIMIT": v[1],
                    "FAIL_SOFT_BIN": {"VTH_NMOS_V": 31, "VTH_PMOS_V": 31, "IDDQ_UA": 21,
                                      "RON_OHM": 31, "FMAX_MHZ": 51, "VDD_MIN_V": 31,
                                      "CONT_RES_OHM": 11, "ICC_ACTIVE_MA": 21}[k]}
                   for i, (k, v) in enumerate(lim.items())])
bd.to_csv("/mnt/user-data/outputs/cp_bin_definition.csv", index=False)
td.to_csv("/mnt/user-data/outputs/cp_test_limits.csv", index=False)

print("rows", len(df), "gross die/wafer", GROSS, "wafers", df.WAFER_ID.nunique())
print(summ.groupby("LOT_ID").YIELD_PCT.mean().round(2).to_string())
print(df.SOFT_BIN.value_counts().sort_index().to_string())
